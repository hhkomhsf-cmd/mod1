var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};

// data/node_modules/@bedrock-oss/bedrock-boost/dist/index.mjs
import { Direction } from "@minecraft/server";
import { system, world } from "@minecraft/server";
import { system as system2 } from "@minecraft/server";
import { BlockPermutation, world as world2 } from "@minecraft/server";
import { world as world3 } from "@minecraft/server";
import { Player } from "@minecraft/server";
import { system as system3 } from "@minecraft/server";
import { system as system4 } from "@minecraft/server";
import {
  system as system5,
  world as world4
} from "@minecraft/server";
import { Player as Player2, system as system6, world as world5 } from "@minecraft/server";
import {
  InputPermissionCategory
} from "@minecraft/server";
import { system as system7 } from "@minecraft/server";
import { Direction as Direction2 } from "@minecraft/server";
import { StructureSaveMode, world as world6 } from "@minecraft/server";
import { EntityEquippableComponent, EquipmentSlot, ItemDurabilityComponent, ItemEnchantableComponent } from "@minecraft/server";
var _a;
var ChatColor = (_a = class {
  /**
   * Class ChatColor Constructor.
   * @param code - The color code as a string.
   * @param color - The color code as a hexadecimal number. Can be undefined.
   */
  constructor(code, color) {
    __publicField(this, "r");
    __publicField(this, "g");
    __publicField(this, "b");
    this.code = code;
    this.color = color;
    if (color) {
      this.r = color >> 16 & 255;
      this.g = color >> 8 & 255;
      this.b = color & 255;
    }
  }
  /**
   * Returns the string representation of the ChatColor instance,
   * which includes the PREFIX followed by the color code.
   * @returns A string representing the ChatColor instance
   */
  toString() {
    return _a.PREFIX + this.code;
  }
  /**
   * Returns the color code of the ChatColor instance.
   * @returns The color code of this ChatColor instance.
   */
  toRGB() {
    return this.color;
  }
  /**
   * Returns the hexadecimal string representation of the color code
   * @returns {string | undefined} The hexadecimal representation of the color.
   */
  toHex() {
    return this.color?.toString(16);
  }
  /**
   * Retrieve the value of the red component.
   *
   * @returns {number | undefined} The value of the red component, or undefined if it is not set.
   */
  getRed() {
    return this.r;
  }
  /**
   * Retrieves the green value of the current color.
   *
   * @returns {number | undefined} The green value of the color, or undefined if it is not set.
   */
  getGreen() {
    return this.g;
  }
  /**
   * Retrieves the blue value of a color.
   *
   * @returns The blue value of the color.
   * @type {number | undefined}
   */
  getBlue() {
    return this.b;
  }
  /**
   * Retrieves the format code associated with the chat color.
   *
   * @returns {string} The format code of the chat color.
   */
  getCode() {
    return this.code;
  }
  /**
   * Removes color codes from the specified string
   * @param str - The string from which color codes will be removed.
   * @returns The string cleared from color codes.
   */
  static stripColor(str) {
    return str.replace(/§[0-9a-u]/g, "");
  }
  /**
   * Finds the closest ChatColor code for the given RGB values
   * @param r - Red part of the color.
   * @param g - Green part of the color.
   * @param b - Blue part of the color.
   * @returns The closest ChatColor for the given RGB values.
   */
  static findClosestColor(r, g, b) {
    let minDistance = Number.MAX_VALUE;
    let closestColor = _a.WHITE;
    for (const color of _a.ALL_COLORS) {
      if (color.r && color.g && color.b) {
        const distance = Math.sqrt(Math.pow(color.r - r, 2) + Math.pow(color.g - g, 2) + Math.pow(color.b - b, 2));
        if (distance < minDistance) {
          minDistance = distance;
          closestColor = color;
        }
      }
    }
    return closestColor;
  }
}, /**
 * Black color code. (0)
 */
__publicField(_a, "BLACK", new _a("0", 0)), /**
 * Dark blue color code. (1)
 */
__publicField(_a, "DARK_BLUE", new _a("1", 170)), /**
 * Dark green color code. (2)
 */
__publicField(_a, "DARK_GREEN", new _a("2", 43520)), /**
 * Dark aqua color code. (3)
 */
__publicField(_a, "DARK_AQUA", new _a("3", 43690)), /**
 * Dark red color code. (4)
 */
__publicField(_a, "DARK_RED", new _a("4", 11141120)), /**
 * Dark purple color code. (5)
 */
__publicField(_a, "DARK_PURPLE", new _a("5", 11141290)), /**
 * Gold color code. (6)
 */
__publicField(_a, "GOLD", new _a("6", 16755200)), /**
 * Gray color code. (7)
 */
__publicField(_a, "GRAY", new _a("7", 11184810)), /**
 * Dark gray color code. (8)
 */
__publicField(_a, "DARK_GRAY", new _a("8", 5592405)), /**
 * Blue color code. (9)
 */
__publicField(_a, "BLUE", new _a("9", 5592575)), /**
 * Green color code. (a)
 */
__publicField(_a, "GREEN", new _a("a", 5635925)), /**
 * Aqua color code. (b)
 */
__publicField(_a, "AQUA", new _a("b", 5636095)), /**
 * Red color code. (c)
 */
__publicField(_a, "RED", new _a("c", 16733525)), /**
 * Light purple color code. (d)
 */
__publicField(_a, "LIGHT_PURPLE", new _a("d", 16733695)), /**
 * Yellow color code. (e)
 */
__publicField(_a, "YELLOW", new _a("e", 16777045)), /**
 * White color code. (f)
 */
__publicField(_a, "WHITE", new _a("f", 16777215)), /**
 * MineCoin gold color code. (g)
 */
__publicField(_a, "MINECOIN_GOLD", new _a("g", 14603781)), /**
 * Material quartz color code. (h)
 */
__publicField(_a, "MATERIAL_QUARTZ", new _a("h", 14931153)), /**
 * Material iron color code. (i)
 */
__publicField(_a, "MATERIAL_IRON", new _a("i", 13552330)), /**
 * Material netherite color code. (j)
 */
__publicField(_a, "MATERIAL_NETHERITE", new _a("j", 4471355)), /**
 * Material redstone color code. (m)
 */
__publicField(_a, "MATERIAL_REDSTONE", new _a("m", 9901575)), /**
 * Material copper color code. (n)
 */
__publicField(_a, "MATERIAL_COPPER", new _a("n", 11823181)), /**
 * Material gold color code. (p)
 */
__publicField(_a, "MATERIAL_GOLD", new _a("p", 14594349)), /**
 * Material emerald color code. (q)
 */
__publicField(_a, "MATERIAL_EMERALD", new _a("q", 1155126)), /**
 * Material diamond color code. (s)
 */
__publicField(_a, "MATERIAL_DIAMOND", new _a("s", 2931368)), /**
 * Material lapis color code. (t)
 */
__publicField(_a, "MATERIAL_LAPIS", new _a("t", 2181499)), /**
 * Material amethyst color code. (u)
 */
__publicField(_a, "MATERIAL_AMETHYST", new _a("u", 10116294)), /**
 * Obfuscated color code. (k)
 */
__publicField(_a, "OBFUSCATED", new _a("k")), /**
 * Bold color code. (l)
 */
__publicField(_a, "BOLD", new _a("l")), /**
 * Italic color code. (o)
 */
__publicField(_a, "ITALIC", new _a("o")), /**
 * Reset color code. (r)
 */
__publicField(_a, "RESET", new _a("r")), /**
 * All available color codes.
 */
__publicField(_a, "VALUES", [
  _a.BLACK,
  _a.DARK_BLUE,
  _a.DARK_GREEN,
  _a.DARK_AQUA,
  _a.DARK_RED,
  _a.DARK_PURPLE,
  _a.GOLD,
  _a.GRAY,
  _a.DARK_GRAY,
  _a.BLUE,
  _a.GREEN,
  _a.AQUA,
  _a.RED,
  _a.LIGHT_PURPLE,
  _a.YELLOW,
  _a.WHITE,
  _a.MINECOIN_GOLD,
  _a.MATERIAL_QUARTZ,
  _a.MATERIAL_IRON,
  _a.MATERIAL_NETHERITE,
  _a.MATERIAL_REDSTONE,
  _a.MATERIAL_COPPER,
  _a.MATERIAL_GOLD,
  _a.MATERIAL_EMERALD,
  _a.MATERIAL_DIAMOND,
  _a.MATERIAL_LAPIS,
  _a.MATERIAL_AMETHYST,
  _a.OBFUSCATED,
  _a.BOLD,
  _a.ITALIC,
  _a.RESET
]), /**
 * All available color codes excluding the formatting codes.
 */
__publicField(_a, "ALL_COLORS", [
  _a.BLACK,
  _a.DARK_BLUE,
  _a.DARK_GREEN,
  _a.DARK_AQUA,
  _a.DARK_RED,
  _a.DARK_PURPLE,
  _a.GOLD,
  _a.GRAY,
  _a.DARK_GRAY,
  _a.BLUE,
  _a.GREEN,
  _a.AQUA,
  _a.RED,
  _a.LIGHT_PURPLE,
  _a.YELLOW,
  _a.WHITE,
  _a.MINECOIN_GOLD,
  _a.MATERIAL_QUARTZ,
  _a.MATERIAL_IRON,
  _a.MATERIAL_NETHERITE,
  _a.MATERIAL_REDSTONE,
  _a.MATERIAL_COPPER,
  _a.MATERIAL_GOLD,
  _a.MATERIAL_EMERALD,
  _a.MATERIAL_DIAMOND,
  _a.MATERIAL_LAPIS,
  _a.MATERIAL_AMETHYST
]), /**
 * PREFIX is the section sign (§) used in Minecraft color codes.
 */
__publicField(_a, "PREFIX", "\xA7"), _a);
var _a2;
var ColorJSON = (_a2 = class {
  constructor() {
    // Tokens
    __publicField(this, "OpenObject", "{");
    __publicField(this, "CloseObject", "}");
    __publicField(this, "OpenArray", "[");
    __publicField(this, "CloseArray", "]");
    __publicField(this, "Comma", ",");
    __publicField(this, "KeyValueSeparator", ":");
    __publicField(this, "StringDelimiter", '"');
    __publicField(this, "KeyDelimiter", "");
    __publicField(this, "Indent", "  ");
    __publicField(this, "NewLine", "\n");
    __publicField(this, "Space", " ");
    // Threshold for inline representation
    __publicField(this, "InlineThreshold", 60);
    // Maximum depth to which objects will be traversed
    __publicField(this, "MaxDepth", 1);
    // Whether to include class names
    __publicField(this, "IncludeClassNames", true);
    // Values
    __publicField(this, "FunctionValue", "\u0192");
    __publicField(this, "NullValue", "null");
    __publicField(this, "UndefinedValue", "undefined");
    __publicField(this, "TrueValue", "true");
    __publicField(this, "FalseValue", "false");
    __publicField(this, "CycleValue", "[...cycle...]");
    __publicField(this, "TruncatedObjectValue", "{...}");
    // Colors
    __publicField(this, "OpenCloseObjectColor", ChatColor.YELLOW);
    __publicField(this, "OpenCloseArrayColor", ChatColor.AQUA);
    __publicField(this, "NumberColor", ChatColor.DARK_AQUA);
    __publicField(this, "StringColor", ChatColor.DARK_GREEN);
    __publicField(this, "BooleanColor", ChatColor.GOLD);
    __publicField(this, "NullColor", ChatColor.GOLD);
    __publicField(this, "KeyColor", ChatColor.GRAY);
    __publicField(this, "EscapeColor", ChatColor.GOLD);
    __publicField(this, "FunctionColor", ChatColor.GRAY);
    __publicField(this, "ClassColor", ChatColor.GRAY);
    __publicField(this, "ClassStyle", ChatColor.BOLD);
    __publicField(this, "CycleColor", ChatColor.DARK_RED);
  }
  static createPlain() {
    const plain = new _a2();
    plain.OpenCloseObjectColor = "";
    plain.OpenCloseArrayColor = "";
    plain.NumberColor = "";
    plain.StringColor = "";
    plain.BooleanColor = "";
    plain.NullColor = "";
    plain.KeyColor = "";
    plain.EscapeColor = "";
    plain.FunctionColor = "";
    plain.ClassColor = "";
    plain.ClassStyle = "";
    plain.CycleColor = "";
    return plain;
  }
  /**
   * Transforms a value into a chat-friendly, colored JSON representation.
   * @param value - The value to transform.
   */
  stringify(value) {
    return this.stringifyValue(value, {
      indentLevel: 0,
      visited: /* @__PURE__ */ new WeakSet()
    });
  }
  /**
   * Transforms a string into a JSON representation.
   * @param value - The string to transform.
   */
  stringifyString(value) {
    return this.StringColor + this.StringDelimiter + this.escapeString(value) + this.StringDelimiter + ChatColor.RESET;
  }
  /**
   * Transforms a number into a JSON representation.
   * @param value - The number to transform.
   */
  stringifyNumber(value) {
    return this.NumberColor + value.toString() + ChatColor.RESET;
  }
  /**
   * Transforms a boolean into a JSON representation.
   * @param value - The boolean to transform.
   */
  stringifyBoolean(value) {
    return this.BooleanColor + (value ? this.TrueValue : this.FalseValue) + ChatColor.RESET;
  }
  /**
   * Transforms a function into a JSON representation.
   * @param value - The function to transform.
   */
  // eslint-disable-next-line @typescript-eslint/ban-types
  stringifyFunction(value) {
    return this.FunctionColor + this.FunctionValue + ChatColor.RESET;
  }
  /**
   * Returns a null JSON representation.
   */
  stringifyNull() {
    return this.NullColor + this.NullValue + ChatColor.RESET;
  }
  /**
   * Returns an undefined JSON representation.
   */
  stringifyUndefined() {
    return this.NullColor + this.UndefinedValue + ChatColor.RESET;
  }
  /**
   * Returns a cycle JSON representation.
   */
  stringifyCycle() {
    return this.CycleColor + this.CycleValue + ChatColor.RESET;
  }
  /**
   * Transforms an array into a JSON representation.
   * @param value - The array to transform.
   * @param indentLevel - The indentation level for pretty-printing.
   */
  stringifyArray(value, ctx) {
    const indentSpace = this.Indent.repeat(ctx.indentLevel);
    if (value.length === 0) {
      return this.OpenCloseArrayColor + this.OpenArray + this.CloseArray + ChatColor.RESET;
    }
    let result = this.OpenCloseArrayColor + this.OpenArray + ChatColor.RESET + this.NewLine;
    let compactResult = this.OpenCloseArrayColor + this.OpenArray + ChatColor.RESET;
    value.forEach((item, index) => {
      result += indentSpace + this.Indent + this.stringifyValue(item, this.indent(ctx));
      result += index < value.length - 1 ? this.Comma + this.NewLine : this.NewLine;
      compactResult += this.stringifyValue(item, this.indent(ctx));
      compactResult += index < value.length - 1 ? this.Comma + this.Space : "";
    });
    result += indentSpace + this.OpenCloseArrayColor + this.CloseArray + ChatColor.RESET;
    compactResult += this.OpenCloseArrayColor + this.CloseArray + ChatColor.RESET;
    if (compactResult.length < this.InlineThreshold) {
      return compactResult;
    }
    return result;
  }
  /**
   * Transforms an object into a truncated JSON representation.
   * @param value - The object to transform.
   * @param className - Class Name of the object.
   * @param indentLevel - The indentation level for pretty-printing.
   */
  stringifyTruncatedObject(value, className, ctx) {
    return (this.IncludeClassNames ? this.ClassColor + "" + this.ClassStyle + className + ChatColor.RESET + this.Space : "") + this.TruncatedObjectValue;
  }
  /**
   * Transforms an object into a JSON representation.
   * @param value - The object to transform.
   * @param className - Class Name of the object.
   * @param entries - Entries of the object to transform.
   * @param indentLevel - The indentation level for pretty-printing.
   */
  stringifyObject(value, className, entries, ctx) {
    const indentSpace = this.Indent.repeat(ctx.indentLevel);
    const prefix = this.IncludeClassNames && className !== "Object" ? this.ClassColor + "" + this.ClassStyle + className + ChatColor.RESET + this.Space : "";
    if (entries.length === 0) {
      return prefix + this.OpenCloseObjectColor + this.OpenObject + this.CloseObject + ChatColor.RESET;
    }
    let result = prefix + this.OpenCloseObjectColor + this.OpenObject + ChatColor.RESET + this.NewLine;
    let compactResult = prefix + this.OpenCloseObjectColor + this.OpenObject + ChatColor.RESET;
    entries.forEach(([key, val], index) => {
      const compactVal = this.stringifyValue(val, this.indent(ctx));
      result += indentSpace + this.Indent + this.KeyColor + this.KeyDelimiter + key + this.KeyDelimiter + ChatColor.RESET + this.KeyValueSeparator + this.Space + compactVal;
      result += index < entries.length - 1 ? this.Comma + this.NewLine : this.NewLine;
      compactResult += this.KeyColor + key + ChatColor.RESET + this.KeyValueSeparator + this.Space + compactVal;
      compactResult += index < entries.length - 1 ? this.Comma + this.Space : "";
    });
    result += indentSpace + this.OpenCloseObjectColor + this.CloseObject + ChatColor.RESET;
    compactResult += this.OpenCloseObjectColor + this.CloseObject + ChatColor.RESET;
    if (compactResult.length < this.InlineThreshold) {
      return compactResult;
    }
    return result;
  }
  shouldTruncateObject(value, className, ctx) {
    return !(className === "Object" || ctx.indentLevel <= this.MaxDepth || this.MaxDepth <= 0);
  }
  /**
   * Transforms a value of any type into a JSON representation. This function is not meant to be overridden.
   * @param value - The value to transform.
   * @param indentLevel - The indentation level for pretty-printing.
   */
  stringifyValue(value, ctx) {
    if (value === null)
      return this.stringifyNull();
    if (value === void 0)
      return this.stringifyUndefined();
    if (typeof value === "number")
      return this.stringifyNumber(value);
    if (typeof value === "string")
      return this.stringifyString(value);
    if (typeof value === "boolean")
      return this.stringifyBoolean(value);
    if (typeof value === "function")
      return this.stringifyFunction(value);
    if (this.isCycle(value, ctx)) {
      return this.stringifyCycle();
    }
    this.markCycle(value, ctx);
    if (Array.isArray(value)) {
      const result = this.stringifyArray(value, ctx.indentLevel ? this.indent(ctx) : ctx);
      this.clearCycle(value, ctx);
      return result;
    }
    if (typeof value === "object") {
      const name = value.constructor.name;
      if (!this.shouldTruncateObject(value, name, ctx)) {
        const keySet = /* @__PURE__ */ new Set();
        let prototype = Object.getPrototypeOf(value);
        let keys = Object.keys(prototype);
        while (keys.length > 0) {
          keys.forEach((key) => keySet.add(key));
          prototype = Object.getPrototypeOf(prototype);
          keys = Object.keys(prototype);
        }
        Object.keys(value).forEach((key) => keySet.add(key));
        keySet.delete("__cycleDetection__");
        const allKeys = [...keySet].sort();
        const entries = allKeys.map((key) => {
          try {
            return [key, value[key] ?? void 0];
          } catch (e) {
            return [key, void 0];
          }
        }).filter(([, val]) => typeof val !== "function" && val !== void 0);
        const result = this.stringifyObject(value, name, entries, ctx);
        this.clearCycle(value, ctx);
        return result;
      } else {
        const result = this.stringifyTruncatedObject(value, name, ctx);
        this.clearCycle(value, ctx);
        return result;
      }
    }
    this.clearCycle(value, ctx);
    return ChatColor.RESET + value.toString();
  }
  /**
   * Escapes a string for JSON.
   * @param str - The string to escape.
   */
  escapeString(str) {
    return str.replace(/\\/g, this.EscapeColor + "\\\\" + this.StringColor).replace(/"/g, this.EscapeColor + '\\"' + this.StringColor).replace(/\n/g, this.EscapeColor + "\\n" + this.StringColor).replace(/\r/g, this.EscapeColor + "\\r" + this.StringColor).replace(/\t/g, this.EscapeColor + "\\t" + this.StringColor);
  }
  markCycle(value, ctx) {
    ctx.visited.add(value);
  }
  isCycle(value, ctx) {
    return ctx.visited.has(value);
  }
  clearCycle(value, ctx) {
    ctx.visited.delete(value);
  }
  indent(ctx) {
    return { ...ctx, indentLevel: ctx.indentLevel + 1 };
  }
}, /**
 * The default ColorJSON instance
 */
__publicField(_a2, "DEFAULT", new _a2()), /**
 * A ColorJSON instance that does not colorize anything.
 */
__publicField(_a2, "PLAIN", _a2.createPlain()), _a2);
var sourceMapping = void 0;
try {
  sourceMapping = globalSourceMapping;
} catch (e) {
}
var _a3;
var LogLevel = (_a3 = class {
  /**
   * The constructor for each log level.
   *
   * @param {number} level - The numerical level for this logger.
   * @param {string} name - The string name for this logger.
   * @param {ChatColor} color - The color to use for this logger. Defaults to `ChatColor.RESET`.
   */
  constructor(level, name, color = ChatColor.RESET) {
    this.level = level;
    this.name = name;
    this.color = color;
  }
  /**
   * Return the logging level as a string.
   *
   * @returns {string} The string representation of the logging level.
   */
  toString() {
    return this.color + this.name.toUpperCase() + ChatColor.RESET;
  }
  /**
   * Parse a string to get the corresponding `LogLevel`.
   *
   * @param {string} str - The string to parse.
   * @returns {LogLevel} The corresponding `LogLevel`, or `undefined` if none was found.
   */
  static parse(str) {
    str = str.toLowerCase();
    for (const level of _a3.values) {
      if (level.name === str)
        return level;
    }
    const num = parseInt(str);
    if (!isNaN(num)) {
      for (const level of _a3.values) {
        if (level.level === num)
          return level;
      }
    }
    return void 0;
  }
}, __publicField(_a3, "All", new _a3(-2, "all")), __publicField(_a3, "Trace", new _a3(-2, "trace", ChatColor.DARK_AQUA)), __publicField(_a3, "Debug", new _a3(-1, "debug", ChatColor.AQUA)), __publicField(_a3, "Info", new _a3(0, "info", ChatColor.GREEN)), __publicField(_a3, "Warn", new _a3(1, "warn", ChatColor.GOLD)), __publicField(_a3, "Error", new _a3(2, "error", ChatColor.RED)), __publicField(_a3, "Fatal", new _a3(3, "fatal", ChatColor.DARK_RED)), __publicField(_a3, "Off", new _a3(100, "off")), /**
 * The list of all available log levels.
 */
__publicField(_a3, "values", [
  _a3.All,
  _a3.Trace,
  _a3.Debug,
  _a3.Info,
  _a3.Warn,
  _a3.Error,
  _a3.Fatal,
  _a3.Off
]), _a3);
function starMatch(pattern, str) {
  if (pattern === "*")
    return true;
  if (pattern.includes("*")) {
    if (pattern.startsWith("*")) {
      return str.endsWith(pattern.substring(1));
    }
    if (pattern.endsWith("*")) {
      return str.startsWith(pattern.substring(0, pattern.length - 1));
    }
    const regex = new RegExp(pattern.replace(/\*/g, ".*"));
    return regex.test(str);
  }
  return pattern === str;
}
var loggingSettings = {
  level: LogLevel.Info,
  filter: ["*"],
  outputTags: false,
  formatFunction: (level, logger, message, tags = void 0) => {
    const _tags = tags !== void 0 ? `\xA77${tags.map((tag) => `[${tag}]`).join("")}\xA7r` : "";
    return `[${level}][${ChatColor.MATERIAL_EMERALD}${logger.name}${ChatColor.RESET}]${_tags} ${message}`;
  },
  messagesJoinFunction: (messages) => {
    return messages.join(" ");
  },
  jsonFormatter: ColorJSON.DEFAULT,
  outputConfig: {
    [LogLevel.Trace.level]: [
      0,
      1
      /* ConsoleInfo */
    ],
    [LogLevel.Debug.level]: [
      0,
      1
      /* ConsoleInfo */
    ],
    [LogLevel.Info.level]: [
      0,
      1
      /* ConsoleInfo */
    ],
    [LogLevel.Warn.level]: [
      0,
      1,
      2
      /* ConsoleWarn */
    ],
    [LogLevel.Error.level]: [
      0,
      1,
      3
      /* ConsoleError */
    ],
    [LogLevel.Fatal.level]: [
      0,
      1,
      3
      /* ConsoleError */
    ]
  }
};
var _a4;
var Logger = (_a4 = class {
  /**
   * Construct a new Logger
   *
   * @param {string} name - The name of the Logger.
   * @param {string[]} tags - The tags for the logger as strings.
   */
  constructor(name, tags = []) {
    this.name = name;
    this.tags = tags;
  }
  /**
   *  Initialize logger class
   */
  static init() {
    LOGGING: {
      if (_a4.initialized)
        return;
      _a4.initialized = true;
      system.afterEvents.scriptEventReceive.subscribe((ev) => {
        if (ev.id === "logging:level" || ev.id === "log:level") {
          if (!ev.message) {
            loggingSettings.level = LogLevel.Info;
            world.sendMessage(
              `${ChatColor.AQUA}Logging level set to ${ChatColor.BOLD}${loggingSettings.level}`
            );
          } else {
            const level = LogLevel.parse(ev.message);
            if (level) {
              loggingSettings.level = level;
              world.sendMessage(
                `${ChatColor.AQUA}Logging level set to ${ChatColor.BOLD}${loggingSettings.level}`
              );
            } else {
              world.sendMessage(
                `${ChatColor.DARK_RED}Invalid logging level: ${ev.message}`
              );
            }
          }
        } else if (ev.id === "logging:filter" || ev.id === "log:filter") {
          if (!ev.message) {
            loggingSettings.filter = ["*"];
          } else {
            loggingSettings.filter = ev.message.split(",");
          }
          world.sendMessage(
            `${ChatColor.AQUA}Logging filter set to ${ChatColor.BOLD}${loggingSettings.filter.join(", ")}`
          );
        }
      });
    }
  }
  /**
   * @param {LogLevel} level - The level to set.
   */
  static setLevel(level) {
    loggingSettings.level = level;
  }
  /**
   * Filter the loggers by the given tags. Tags can use the `*` wildcard.
   * @param {'*' | string[]} filter - The filter to set.
   */
  static setFilter(filter) {
    loggingSettings.filter = filter;
  }
  /**
   * Set the format function for the logger.
   * @param {function} func - The function to set.
   */
  static setFormatFunction(func) {
    loggingSettings.formatFunction = func;
  }
  /**
   * Set the function, that joins multiple messages into one for the logger.
   * @param {function} func - The function to set.
   */
  static setMessagesJoinFunction(func) {
    loggingSettings.messagesJoinFunction = func;
  }
  /**
   * Set the tag visibility for the logger. When true, tags will be printed in the log. Disabled by default.
   * @param visible
   */
  static setTagsOutputVisibility(visible) {
    loggingSettings.outputTags = visible;
  }
  /**
   * Set the JSON formatter for the logger.
   * @param {ColorJSON} formatter - The json formatter to set.
   */
  static setJsonFormatter(formatter) {
    loggingSettings.jsonFormatter = formatter;
  }
  /**
   * Get the output configuration for the logger.
   * @returns {OutputConfig} The output configuration.
   */
  static getOutputConfig() {
    return loggingSettings.outputConfig;
  }
  /**
   * Returns a new Logger.
   *
   * @param {string} name - The name of the Logger.
   * @param {string[]} tags - The tags for the Logger as strings.
   *
   * @returns {Logger} A new Logger.
   */
  static getLogger(name, ...tags) {
    LOGGING: {
      if (!_a4.initialized) {
        _a4.init();
      }
    }
    return new _a4(name, tags);
  }
  /**
   * Log messages with the level set.
   *
   * @param {LogLevel} level - The LogLevel to log the messages at.
   * @param {array} message - An array of the messages to log.
   */
  log(level, ...message) {
    LOGGING: {
      if (level.level < loggingSettings.level.level)
        return;
      if (loggingSettings.filter.length === 0 || this.tags.length === 0) {
        this.logRaw(level, ...message);
        return;
      }
      for (const filter of loggingSettings.filter) {
        if (filter.startsWith("!")) {
          if (starMatch(filter.substring(1), this.name) || this.tags.some((tag) => starMatch(filter.substring(1), tag))) {
            return;
          }
        }
        if (starMatch(filter, this.name) || this.tags.some((tag) => starMatch(filter, tag))) {
          this.logRaw(level, ...message);
          return;
        }
      }
    }
  }
  stringifyError(x) {
    let stack = x.stack ?? "";
    if (sourceMapping) {
      const stackLineRegex = /\(([^)]+\.js):(\d+)(?::(\d+))?\)/;
      stack = stack.split("\n").map((line) => {
        const match = stackLineRegex.exec(line);
        if (match) {
          const filePath = match[1];
          const lineNumber = parseInt(match[2], 10) - sourceMapping.metadata.offset;
          if (filePath.includes(sourceMapping.metadata.filePath)) {
            const mappingEntry = globalSourceMapping[lineNumber];
            if (mappingEntry) {
              const replacement = `(${mappingEntry.source}:${mappingEntry.originalLine})`;
              return line.replace(stackLineRegex, replacement);
            }
          }
        }
        return line;
      }).join("\n");
    }
    return `${ChatColor.DARK_RED}${ChatColor.BOLD}${x.message}
${ChatColor.RESET}${ChatColor.GRAY}${ChatColor.ITALIC}${stack}${ChatColor.RESET}`;
  }
  /**
   * Internal function to log messages with the level set, that bypasses the filters.
   *
   * @param {LogLevel} level - The LogLevel to log the messages at.
   * @param {array} message - An array of the messages to log.
   */
  logRaw(level, ...message) {
    LOGGING: {
      const msgs = message.map((x) => {
        if (x === void 0) {
          return ChatColor.GOLD + "undefined" + ChatColor.RESET;
        }
        if (x === null) {
          return ChatColor.GOLD + "null" + ChatColor.RESET;
        }
        if (x && x instanceof Error) {
          return this.stringifyError(x);
        }
        if (typeof x === "object" || Array.isArray(x)) {
          return loggingSettings.jsonFormatter.stringify(x) + ChatColor.RESET;
        }
        return x.toString() + ChatColor.RESET;
      });
      const formatted = loggingSettings.formatFunction(
        level,
        this,
        loggingSettings.messagesJoinFunction(msgs),
        loggingSettings.outputTags ? this.tags : void 0
      );
      const outputs = loggingSettings.outputConfig[level.level] || [
        0,
        1
        /* ConsoleInfo */
      ];
      if (outputs.includes(
        0
        /* Chat */
      )) {
        try {
          world.sendMessage(formatted);
        } catch (_) {
          system.run(() => {
            world.sendMessage(formatted);
          });
        }
      }
      if (outputs.includes(
        1
        /* ConsoleInfo */
      )) {
        if (console.originalLog) {
          console.originalLog(ChatColor.stripColor(formatted));
        } else {
          console.log(ChatColor.stripColor(formatted));
        }
      }
      if (outputs.includes(
        2
        /* ConsoleWarn */
      )) {
        console.warn(formatted);
      }
      if (outputs.includes(
        3
        /* ConsoleError */
      )) {
        console.error(formatted);
      }
    }
  }
  /**
   * Logs a trace message.
   *
   * @param {...unknown} message - The message(s) to be logged.
   */
  trace(...message) {
    LOGGING:
      this.log(LogLevel.Trace, ...message);
  }
  /**
   * Logs debug message.
   *
   * @param {...unknown[]} message - The message(s) to be logged.
   */
  debug(...message) {
    LOGGING:
      this.log(LogLevel.Debug, ...message);
  }
  /**
   * Logs an informational message.
   *
   * @param {...unknown[]} message - The message(s) to be logged.
   */
  info(...message) {
    LOGGING:
      this.log(LogLevel.Info, ...message);
  }
  /**
   * Logs a warning message.
   *
   * @param {...unknown[]} message - The warning message or messages to be logged.
   */
  warn(...message) {
    LOGGING:
      this.log(LogLevel.Warn, ...message);
  }
  /**
   * Logs an error message.
   *
   * @param {...unknown[]} message - The error message(s) to log.
   */
  error(...message) {
    LOGGING:
      this.log(LogLevel.Error, ...message);
  }
  /**
   * Logs a fatal error.
   *
   * @param {unknown[]} message - The error message to log.
   */
  fatal(...message) {
    LOGGING:
      this.log(LogLevel.Fatal, ...message);
  }
}, __publicField(_a4, "initialized", false), _a4);
var _a5;
var Vec3 = (_a5 = class {
  constructor(x, y, z) {
    __publicField(this, "x");
    __publicField(this, "y");
    __publicField(this, "z");
    if (x === Direction.Down) {
      this.x = 0;
      this.y = -1;
      this.z = 0;
    } else if (x === Direction.Up) {
      this.x = 0;
      this.y = 1;
      this.z = 0;
    } else if (x === Direction.North) {
      this.x = 0;
      this.y = 0;
      this.z = -1;
    } else if (x === Direction.South) {
      this.x = 0;
      this.y = 0;
      this.z = 1;
    } else if (x === Direction.East) {
      this.x = 1;
      this.y = 0;
      this.z = 0;
    } else if (x === Direction.West) {
      this.x = -1;
      this.y = 0;
      this.z = 0;
    } else if (typeof x === "number") {
      this.x = x;
      this.y = y;
      this.z = z;
    } else if (Array.isArray(x)) {
      this.x = x[0];
      this.y = x[1];
      this.z = x[2];
    } else if (x instanceof _a5) {
      this.x = x.x;
      this.y = x.y;
      this.z = x.z;
    } else {
      if (!x || !x.x && x.x !== 0 || !x.y && x.y !== 0 || !x.z && x.z !== 0) {
        _a5.log.error(new Error("Invalid vector"), x);
        throw new Error("Invalid vector");
      }
      this.x = x.x;
      this.y = x.y;
      this.z = x.z;
    }
  }
  static from(x, y, z) {
    if (x instanceof _a5)
      return x;
    if (typeof x === "number" && y !== void 0 && z !== void 0) {
      return new _a5(x, y, z);
    }
    if (Array.isArray(x)) {
      return new _a5(x);
    }
    if (x === Direction.Down)
      return _a5.Down;
    if (x === Direction.Up)
      return _a5.Up;
    if (x === Direction.North)
      return _a5.North;
    if (x === Direction.South)
      return _a5.South;
    if (x === Direction.East)
      return _a5.East;
    if (x === Direction.West)
      return _a5.West;
    if (!x || !x.x && x.x !== 0 || !x.y && x.y !== 0 || !x.z && x.z !== 0) {
      _a5.log.error(new Error("Invalid arguments"), x, y, z);
      throw new Error("Invalid arguments");
    }
    return new _a5(
      x.x,
      x.y,
      x.z
    );
  }
  static _from(x, y, z) {
    if (x instanceof _a5)
      return x;
    if (typeof x === "number" && y !== void 0 && z !== void 0) {
      return new _a5(x, y, z);
    }
    if (Array.isArray(x)) {
      return new _a5(x);
    }
    if (x === Direction.Down)
      return _a5.Down;
    if (x === Direction.Up)
      return _a5.Up;
    if (x === Direction.North)
      return _a5.North;
    if (x === Direction.South)
      return _a5.South;
    if (x === Direction.East)
      return _a5.East;
    if (x === Direction.West)
      return _a5.West;
    if (!x || !x.x && x.x !== 0 || !x.y && x.y !== 0 || !x.z && x.z !== 0) {
      _a5.log.error(new Error("Invalid arguments"), x, y, z);
      throw new Error("Invalid arguments");
    }
    return new _a5(
      x.x,
      x.y,
      x.z
    );
  }
  /**
   * Creates a copy of the current vector.
   *
   * @returns A new vector with the same values as the current vector.
   */
  copy() {
    return new _a5(this.x, this.y, this.z);
  }
  static fromYawPitch(yawOrRotation, pitch) {
    let yaw;
    if (typeof yawOrRotation === "number") {
      yaw = yawOrRotation;
      pitch = pitch;
    } else {
      yaw = yawOrRotation.y;
      pitch = yawOrRotation.x;
    }
    const psi = yaw * (Math.PI / 180);
    const theta = pitch * (Math.PI / 180);
    const x = Math.cos(theta) * Math.sin(psi);
    const y = Math.sin(theta);
    const z = Math.cos(theta) * Math.cos(psi);
    return new _a5(x, y, z);
  }
  static fromRotation(yawOrRotation, pitch) {
    let yaw;
    if (typeof yawOrRotation === "number") {
      yaw = yawOrRotation;
      pitch = pitch;
    } else {
      yaw = yawOrRotation.y;
      pitch = yawOrRotation.x;
    }
    const psi = yaw * (Math.PI / 180);
    const theta = pitch * (Math.PI / 180);
    const x = -Math.cos(theta) * Math.sin(psi);
    const y = -Math.sin(theta);
    const z = Math.cos(theta) * Math.cos(psi);
    return new _a5(x, y, z);
  }
  /**
   * Converts the normal vector to yaw and pitch values.
   *
   * @returns A Vector2 containing the yaw and pitch values.
   * @deprecated Use toRotation() instead. This method returns inverted values and will be removed in the future.
   */
  toYawPitch() {
    if (this.isZero()) {
      _a5.log.error(
        new Error("Cannot convert zero-length vector to direction")
      );
      throw new Error("Cannot convert zero-length vector to direction");
    }
    const direction = this.normalize();
    const yaw = Math.atan2(direction.x, direction.z) * (180 / Math.PI);
    const pitch = Math.asin(direction.y) * (180 / Math.PI);
    return {
      x: pitch,
      y: yaw
    };
  }
  /**
   * Converts the normal vector to yaw and pitch values.
   *
   * @returns A Vector2 containing the yaw and pitch values.
   */
  toRotation() {
    if (this.isZero()) {
      _a5.log.error(
        new Error("Cannot convert zero-length vector to direction")
      );
      throw new Error("Cannot convert zero-length vector to direction");
    }
    const direction = this.normalize();
    const yaw = -Math.atan2(direction.x, direction.z) * (180 / Math.PI);
    const pitch = Math.asin(-direction.y) * (180 / Math.PI);
    return {
      x: pitch,
      y: yaw
    };
  }
  add(x, y, z) {
    const v = _a5._from(x, y, z);
    return _a5.from(v.x + this.x, v.y + this.y, v.z + this.z);
  }
  subtract(x, y, z) {
    const v = _a5._from(x, y, z);
    return _a5.from(this.x - v.x, this.y - v.y, this.z - v.z);
  }
  multiply(x, y, z) {
    if (typeof x === "number" && y === void 0 && z === void 0) {
      return _a5.from(this.x * x, this.y * x, this.z * x);
    }
    const v = _a5._from(x, y, z);
    return _a5.from(v.x * this.x, v.y * this.y, v.z * this.z);
  }
  /**
   * Scales the current vector by a scalar.
   *
   * @param scalar - The scalar to scale the vector by.
   * @returns The updated vector after scaling.
   */
  scale(scalar) {
    return _a5.from(this.x * scalar, this.y * scalar, this.z * scalar);
  }
  divide(x, y, z) {
    if (typeof x === "number" && y === void 0 && z === void 0) {
      if (x === 0)
        throw new Error("Cannot divide by zero");
      return _a5.from(this.x / x, this.y / x, this.z / x);
    }
    const v = _a5._from(x, y, z);
    if (v.x === 0 || v.y === 0 || v.z === 0)
      throw new Error("Cannot divide by zero");
    return _a5.from(this.x / v.x, this.y / v.y, this.z / v.z);
  }
  /**
   * Normalizes the vector to have a length (magnitude) of 1.
   * Normalized vectors are often used as a direction vectors.
   *
   * @returns The normalized vector.
   */
  normalize() {
    if (this.isZero()) {
      _a5.log.error(new Error("Cannot normalize zero-length vector"));
      throw new Error("Cannot normalize zero-length vector");
    }
    const len = this.length();
    return _a5.from(this.x / len, this.y / len, this.z / len);
  }
  /**
   * Computes the length (magnitude) of the vector.
   *
   * @returns The length of the vector.
   */
  length() {
    return Math.hypot(this.x, this.y, this.z);
  }
  /**
   * Computes the squared length of the vector.
   * This is faster than computing the actual length and can be useful for comparison purposes.
   *
   * @returns The squared length of the vector.
   */
  lengthSquared() {
    return this.x * this.x + this.y * this.y + this.z * this.z;
  }
  cross(x, y, z) {
    const v = _a5._from(x, y, z);
    return _a5.from(
      this.y * v.z - this.z * v.y,
      this.z * v.x - this.x * v.z,
      this.x * v.y - this.y * v.x
    );
  }
  distance(x, y, z) {
    const v = _a5._from(x, y, z);
    return this.subtract(v).length();
  }
  distanceSquared(x, y, z) {
    const v = _a5._from(x, y, z);
    return this.subtract(v).lengthSquared();
  }
  /**
   * Computes the linear interpolation between the current vector and another vector, when t is in the range [0, 1].
   * Computes the extrapolation when t is outside this range.
   *
   * @param v - The other vector.
   * @param t - The interpolation factor.
   * @returns A new vector after performing the lerp operation.
   */
  lerp(v, t) {
    if (!v || !t)
      return _a5.from(this);
    if (t === 1)
      return _a5.from(v);
    if (t === 0)
      return _a5.from(this);
    return _a5.from(
      this.x + (v.x - this.x) * t,
      this.y + (v.y - this.y) * t,
      this.z + (v.z - this.z) * t
    );
  }
  /**
   * Computes the spherical linear interpolation between the current vector and another vector, when t is in the range [0, 1].
   * Computes the extrapolation when t is outside this range.
   *
   * @param v - The other vector.
   * @param t - The interpolation factor.
   * @returns A new vector after performing the slerp operation.
   */
  slerp(v, t) {
    if (!v || !t)
      return _a5.from(this);
    if (t === 1)
      return _a5.from(v);
    if (t === 0)
      return _a5.from(this);
    const dot = this.dot(v);
    const theta = Math.acos(dot) * t;
    const relative = _a5.from(v).subtract(this.multiply(dot)).normalize();
    return this.multiply(Math.cos(theta)).add(
      relative.multiply(Math.sin(theta))
    );
  }
  dot(x, y, z) {
    const v = _a5._from(x, y, z);
    return this.x * v.x + this.y * v.y + this.z * v.z;
  }
  angleBetween(x, y, z) {
    const v = _a5._from(x, y, z);
    const dotProduct = this.dot(v);
    const lenSq1 = this.lengthSquared();
    if (lenSq1 === 0) {
      return 0;
    }
    const lenSq2 = v.lengthSquared();
    if (lenSq2 === 0) {
      return 0;
    }
    const denom = Math.sqrt(lenSq1 * lenSq2);
    const cosAngle = Math.min(1, Math.max(-1, dotProduct / denom));
    return Math.acos(cosAngle);
  }
  projectOnto(x, y, z) {
    const v = _a5._from(x, y, z);
    if (v.isZero()) {
      return _a5.Zero;
    }
    const denom = v.dot(v);
    if (denom === 0) {
      return _a5.Zero;
    }
    const scale = this.dot(v) / denom;
    return _a5.from(v.x * scale, v.y * scale, v.z * scale);
  }
  reflect(x, y, z) {
    const normal = _a5._from(x, y, z);
    const proj = this.projectOnto(normal);
    return this.subtract(proj.multiply(2));
  }
  /**
   * Rotates the current normalized vector by a given angle around a given axis.
   *
   * @param axis - The axis of rotation.
   * @param angle - The angle of rotation in degrees.
   * @returns The rotated vector.
   */
  rotate(axis, angle) {
    const halfAngle = angle * Math.PI / 180 / 2;
    const w = Math.cos(halfAngle);
    const x = axis.x * Math.sin(halfAngle);
    const y = axis.y * Math.sin(halfAngle);
    const z = axis.z * Math.sin(halfAngle);
    const v = this;
    const qv_x = w * w * v.x + 2 * y * w * v.z - 2 * z * w * v.y + x * x * v.x + 2 * y * x * v.y + 2 * z * x * v.z - z * z * v.x - y * y * v.x;
    const qv_y = 2 * x * y * v.x + y * y * v.y + 2 * z * y * v.z + 2 * w * z * v.x - z * z * v.y + w * w * v.y - 2 * x * w * v.z - x * x * v.y;
    const qv_z = 2 * x * z * v.x + 2 * y * z * v.y + z * z * v.z - 2 * w * y * v.x - y * y * v.z + 2 * w * x * v.y - x * x * v.z + w * w * v.z;
    return new _a5(qv_x, qv_y, qv_z);
  }
  /**
   * Updates the X, Y, and Z components of the vector.
   *
   * @param x - The function to use to update the X value.
   * @param y - The function to use to update the Y value.
   * @param z - The function to use to update the Z value.
   * @returns The updated vector with the new values.
   */
  update(x, y, z) {
    if (!x) {
      x = (value) => value;
    }
    if (!y) {
      y = (value) => value;
    }
    if (!z) {
      z = (value) => value;
    }
    return new _a5(x(this.x), y(this.y), z(this.z));
  }
  setX(value) {
    if (typeof value === "number") {
      return new _a5(value, this.y, this.z);
    }
    return new _a5(value(this.x), this.y, this.z);
  }
  setY(value) {
    if (typeof value === "number") {
      return new _a5(this.x, value, this.z);
    }
    return new _a5(this.x, value(this.y), this.z);
  }
  setZ(value) {
    if (typeof value === "number") {
      return new _a5(this.x, this.y, value);
    }
    return new _a5(this.x, this.y, value(this.z));
  }
  /**
   * Calculates the shortest distance between a point (represented by this Vector3 instance) and a line segment.
   *
   * This method finds the perpendicular projection of the point onto the line defined by the segment. If this
   * projection lies outside the line segment, then the method calculates the distance from the point to the
   * nearest segment endpoint.
   *
   * @param start - The starting point of the line segment.
   * @param end - The ending point of the line segment.
   * @returns The shortest distance between the point and the line segment.
   */
  distanceToLineSegment(start, end) {
    const lineDirection = _a5.from(end).subtract(start);
    if (lineDirection.lengthSquared() === 0) {
      return this.subtract(start).length();
    }
    const t = Math.max(
      0,
      Math.min(
        1,
        this.subtract(start).dot(lineDirection) / lineDirection.dot(lineDirection)
      )
    );
    const projection = _a5.from(start).add(lineDirection.multiply(t));
    return this.subtract(projection).length();
  }
  /**
   * Floors the X, Y, and Z components of the vector.
   * @returns A new vector with the floored components.
   */
  floor() {
    return this.update(Math.floor, Math.floor, Math.floor);
  }
  /**
   * Floors the X component of the vector.
   * @returns A new vector with the floored X component.
   */
  floorX() {
    return this.setX(Math.floor);
  }
  /**
   * Floors the Y component of the vector.
   * @returns A new vector with the floored Y component.
   */
  floorY() {
    return this.setY(Math.floor);
  }
  /**
   * Floors the Z component of the vector.
   * @returns A new vector with the floored Z component.
   */
  floorZ() {
    return this.setZ(Math.floor);
  }
  /**
   * Ceils the X, Y, and Z components of the vector.
   * @returns A new vector with the ceiled components.
   */
  ceil() {
    return new _a5(Math.ceil(this.x), Math.ceil(this.y), Math.ceil(this.z));
  }
  /**
   * Ceils the X component of the vector.
   * @returns A new vector with the ceiled X component.
   */
  ceilX() {
    return this.setX(Math.ceil);
  }
  /**
   * Ceils the Y component of the vector.
   * @returns A new vector with the ceiled Y component.
   */
  ceilY() {
    return this.setY(Math.ceil);
  }
  /**
   * Ceils the Z component of the vector.
   * @returns A new vector with the ceiled Z component.
   */
  ceilZ() {
    return this.setZ(Math.ceil);
  }
  /**
   * Rounds the X, Y, and Z components of the vector.
   * @returns A new vector with the rounded components.
   */
  round() {
    return this.update(Math.round, Math.round, Math.round);
  }
  /**
   * Rounds the X component of the vector.
   * @returns A new vector with the rounded X component.
   */
  roundX() {
    return this.setX(Math.round);
  }
  /**
   * Rounds the Y component of the vector.
   * @returns A new vector with the rounded Y component.
   */
  roundY() {
    return this.setY(Math.round);
  }
  /**
   * Rounds the Z component of the vector.
   * @returns A new vector with the rounded Z component.
   */
  roundZ() {
    return this.setZ(Math.round);
  }
  /**
   * Returns a new vector offset from the current vector up by 1 block.
   * @returns A new vector offset from the current vector up by 1 block.
   */
  up() {
    return this.add(_a5.Up);
  }
  /**
   * Returns a new vector offset from the current vector down by 1 block.
   * @returns A new vector offset from the current vector down by 1 block.
   */
  down() {
    return this.add(_a5.Down);
  }
  /**
   * Returns a new vector offset from the current vector north by 1 block.
   * @returns A new vector offset from the current vector north by 1 block.
   */
  north() {
    return this.add(_a5.North);
  }
  /**
   * Returns a new vector offset from the current vector south by 1 block.
   * @returns A new vector offset from the current vector south by 1 block.
   */
  south() {
    return this.add(_a5.South);
  }
  /**
   * Returns a new vector offset from the current vector east by 1 block.
   * @returns A new vector offset from the current vector east by 1 block.
   */
  east() {
    return this.add(_a5.East);
  }
  /**
   * Returns a new vector offset from the current vector west by 1 block.
   * @returns A new vector offset from the current vector west by 1 block.
   */
  west() {
    return this.add(_a5.West);
  }
  /**
   * Checks if the current vector is equal to the zero vector.
   * @returns true if the vector is equal to the zero vector, else returns false.
   */
  isZero() {
    return this.x === 0 && this.y === 0 && this.z === 0;
  }
  /**
   * Converts the vector to an array containing the X, Y, and Z components of the vector.
   * @returns An array containing the X, Y, and Z components of the vector.
   */
  toArray() {
    return [this.x, this.y, this.z];
  }
  /**
   * Converts the vector to a direction.
   * If the vector is not a unit vector, then it will be normalized and rounded to the nearest direction.
   */
  toDirection() {
    if (this.isZero()) {
      _a5.log.error(
        new Error("Cannot convert zero-length vector to direction")
      );
      throw new Error("Cannot convert zero-length vector to direction");
    }
    const normalized = this.normalize();
    const maxValue = Math.max(
      Math.abs(normalized.x),
      Math.abs(normalized.y),
      Math.abs(normalized.z)
    );
    if (maxValue === normalized.x)
      return Direction.East;
    if (maxValue === -normalized.x)
      return Direction.West;
    if (maxValue === normalized.y)
      return Direction.Up;
    if (maxValue === -normalized.y)
      return Direction.Down;
    if (maxValue === normalized.z)
      return Direction.South;
    if (maxValue === -normalized.z)
      return Direction.North;
    _a5.log.error(new Error("Cannot convert vector to direction"), this);
    throw new Error("Cannot convert vector to direction");
  }
  /**
   * Returns a new vector with the X, Y, and Z components rounded to the nearest block location.
   */
  toBlockLocation() {
    return _a5.from(
      (this.x << 0) - (this.x < 0 && this.x !== this.x << 0 ? 1 : 0),
      (this.y << 0) - (this.y < 0 && this.y !== this.y << 0 ? 1 : 0),
      (this.z << 0) - (this.z < 0 && this.z !== this.z << 0 ? 1 : 0)
    );
  }
  almostEqual(x, y, z, delta) {
    try {
      let other;
      if (typeof x !== "number" && z === void 0) {
        other = _a5._from(x, void 0, void 0);
        delta = y;
      } else {
        other = _a5._from(x, y, z);
      }
      return Math.abs(this.x - other.x) <= delta && Math.abs(this.y - other.y) <= delta && Math.abs(this.z - other.z) <= delta;
    } catch (e) {
      return false;
    }
  }
  equals(x, y, z) {
    try {
      const other = _a5._from(x, y, z);
      return this.x === other.x && this.y === other.y && this.z === other.z;
    } catch (e) {
      return false;
    }
  }
  /**
   * Converts the vector to a string representation.
   *
   * @param format - The format of the string representation. Defaults to "long".
   * @param separator - The separator to use between components. Defaults to ", ".
   * @returns The string representation of the vector.
   * @remarks
   * The "long" format is "Vec3(x, y, z)".
   * The "short" format is "x, y, z".
   */
  toString(format = "long", separator = ", ") {
    const result = `${this.x + separator + this.y + separator + this.z}`;
    return format === "long" ? `Vec3(${result})` : result;
  }
  /**
   * Parses a string representation of a vector.
   *
   * @param str - The string representation of the vector.
   * @param format - The format of the string representation. Defaults to "long".
   * @param separator - The separator to use between components. Defaults to ", ".
   * @returns The vector parsed from the string.
   * @throws {Error} If the string format is invalid.
   */
  static fromString(str, format = "long", separator = ", ") {
    if (format === "long") {
      const match = str.match(/^Vec3\((.*)\)$/);
      if (!match) {
        throw new Error("Invalid string format");
      }
      const components = match[1].split(separator);
      if (components.length !== 3) {
        throw new Error("Invalid string format");
      }
      return _a5.from(Number(components[0]), Number(components[1]), Number(components[2]));
    } else {
      const components = str.split(separator);
      if (components.length !== 3) {
        throw new Error("Invalid string format");
      }
      return _a5.from(Number(components[0]), Number(components[1]), Number(components[2]));
    }
  }
}, __publicField(_a5, "log", Logger.getLogger(
  "vec3",
  "vec3",
  "bedrock-boost"
)), /**
 * Zero vector
 */
__publicField(_a5, "Zero", new _a5(0, 0, 0)), /**
 * Down vector, negative towards Y
 */
__publicField(_a5, "Down", new _a5(Direction.Down)), /**
 * Up vector, positive towards Y
 */
__publicField(_a5, "Up", new _a5(Direction.Up)), /**
 * North vector, negative towards Z
 */
__publicField(_a5, "North", new _a5(Direction.North)), /**
 * South vector, positive towards Z
 */
__publicField(_a5, "South", new _a5(Direction.South)), /**
 * East vector, positive towards X
 */
__publicField(_a5, "East", new _a5(Direction.East)), /**
 * West vector, negative towards X
 */
__publicField(_a5, "West", new _a5(Direction.West)), _a5);
var _a6;
var Timings = (_a6 = class {
  /**
   * Begin measuring the time it takes to perform an operation.
   * @remarks
   * If another operation is already being measured, the measurement will be ended.
   * 
   * @param operation The name of the operation.
   */
  static begin(operation) {
    this.end();
    this.lastTime = (/* @__PURE__ */ new Date()).getTime();
    this.lastOperation = operation;
  }
  /**
   * End measuring the time it takes to perform an operation and log the result.
   * @remarks
   * If no operation is being measured, this method will do nothing.
   */
  static end() {
    const time = (/* @__PURE__ */ new Date()).getTime();
    if (this.lastTime > 0) {
      _a6.log.debug(`Operation ${this.lastOperation} took ${time - this.lastTime}ms`);
    }
    this.lastTime = -1;
  }
}, __publicField(_a6, "log", Logger.getLogger("Timings", "timings")), __publicField(_a6, "lastTime", -1), __publicField(_a6, "lastOperation", ""), _a6);
function isValid(entity) {
  const f = Object.getPrototypeOf(entity).isValid;
  if (typeof f === "function") {
    return f.call(entity);
  }
  return entity.isValid;
}
var log = Logger.getLogger("jobUtils", "bedrock-boost", "jobUtils");
var _a7;
var PulseScheduler = (_a7 = class {
  /**
   * Creates a new PulseScheduler instance.
   * @param period The period of the scheduler.
   */
  constructor(processor, period) {
    __publicField(this, "items", []);
    __publicField(this, "period");
    __publicField(this, "currentTick", 0);
    __publicField(this, "runId");
    __publicField(this, "nextIndex", 0);
    __publicField(this, "executionSchedule", []);
    __publicField(this, "processor");
    if (period <= 0) {
      throw new Error("Period must be a positive integer.");
    }
    if (!processor || typeof processor !== "function") {
      throw new Error("Processor function must be defined.");
    }
    this.period = period;
    this.processor = processor;
  }
  /**
   * Adds an item to the schedule.
   * @param item The item to be added.
   * @deprecated Use `push` instead.
   */
  add(item) {
    this.push(item);
  }
  /**
    * Adds multiple items to the schedule.
    * 
    * @param items - The items to be added.
    * @deprecated Use `push` instead.
    */
  addAll(items) {
    this.push(...items);
  }
  /**
   * Removes an item from the schedule at the specified index.
   * @param index - The index of the item to remove.
   */
  remove(index) {
    if (index >= 0 && index < this.items.length) {
      this.items.splice(index, 1);
      if (index < this.nextIndex) {
        this.nextIndex--;
      }
      this.recalculateExecutionSchedule();
    }
  }
  /**
   * Removes items from the schedule that satisfy the given predicate.
   * 
   * @param predicate - The predicate function used to determine if an item should be removed.
   */
  removeIf(predicate) {
    for (let i = this.items.length - 1; i >= 0; i--) {
      if (predicate(this.items[i])) {
        this.remove(i);
      }
    }
  }
  /**
   * Returns a list of the items in the schedule.
   */
  getItems() {
    return this.items;
  }
  /**
   * Starts the schedule.
   */
  start() {
    this.stop();
    this.currentTick = 0;
    this.nextIndex = 0;
    this.runId = system4.runInterval(() => this.tick(), 1);
  }
  /**
   * Stops the schedule.
   */
  stop() {
    if (this.runId !== void 0) {
      system4.clearRun(this.runId);
      this.runId = void 0;
    }
  }
  recalculateExecutionSchedule() {
    const totalExecutions = this.items.length;
    this.executionSchedule = new Array(this.period).fill(0);
    if (totalExecutions === 0) {
      return;
    }
    const interval = this.period / totalExecutions;
    for (let i = 0; i < totalExecutions; i++) {
      this.executionSchedule[Math.round(interval * i) % this.period]++;
    }
  }
  tick() {
    if (this.items.length === 0) {
      _a7.log.trace("No items to process.");
      return;
    }
    const scheduledExecutions = this.executionSchedule[this.currentTick];
    if (scheduledExecutions === 0) {
      _a7.log.trace("No items to process this tick.");
      this.currentTick = (this.currentTick + 1) % this.period;
      if (this.currentTick === 0) {
        this.nextIndex = 0;
      }
      return;
    }
    let executed = 0;
    for (; this.nextIndex < this.items.length && executed < scheduledExecutions; this.nextIndex++) {
      try {
        this.processor(this.items[this.nextIndex]);
      } catch (e) {
        _a7.log.error("Error processing item", e);
      }
      executed++;
    }
    this.currentTick = (this.currentTick + 1) % this.period;
    if (this.currentTick === 0) {
      this.nextIndex = 0;
    }
  }
  push(...items) {
    this.items.push(...items);
    this.recalculateExecutionSchedule();
    return this.items.length;
  }
  pop() {
    const item = this.items.pop();
    this.recalculateExecutionSchedule();
    return item;
  }
  shift() {
    const item = this.items.shift();
    this.recalculateExecutionSchedule();
    return item;
  }
  unshift(...items) {
    this.items.unshift(...items);
    this.recalculateExecutionSchedule();
    return this.items.length;
  }
  splice(start, deleteCount = 0, ...items) {
    const removed = this.items.splice(start, deleteCount, ...items);
    this.recalculateExecutionSchedule();
    return removed;
  }
}, __publicField(_a7, "log", Logger.getLogger("PulseScheduler", "bedrock-boost", "pulse-scheduler")), _a7);
var _a8;
var EntityPulseScheduler = (_a8 = class extends PulseScheduler {
  /**
   * Creates a new EntityPulseScheduler instance.
   * @param period The period of the scheduler.
   * @param queryOptions The query options to use when querying for entities.
   */
  constructor(processor, period, queryOptions) {
    super((t) => {
      if (isValid(t)) {
        processor(t);
      } else {
        this.removeIf((entity) => !isValid(entity));
      }
    }, period);
    this.queryOptions = queryOptions;
    this.push(
      ...world4.getDimension("minecraft:overworld").getEntities(this.queryOptions)
    );
    this.push(
      ...world4.getDimension("minecraft:nether").getEntities(this.queryOptions)
    );
    this.push(
      ...world4.getDimension("minecraft:the_end").getEntities(this.queryOptions)
    );
  }
  compareEntities(a, b) {
    return a.id === b.id;
  }
  start() {
    world4.afterEvents.entityLoad.subscribe((event) => {
      this.addIfMatchesWithRetry(event.entity);
    });
    world4.afterEvents.entitySpawn.subscribe((event) => {
      this.addIfMatchesWithRetry(event.entity);
    });
    world4.afterEvents.entityRemove.subscribe((event) => {
      this.removeIf(
        (entity) => !isValid(entity) || entity.id === event.removedEntityId
      );
    });
    super.start();
  }
  /**
   * Adds an entity to the scheduler if it matches the query options. In case the entity is not valid, it will retry a tick later.
   * @param entity The entity to add.
   */
  addIfMatchesWithRetry(entity) {
    try {
      if (!entity) {
        return;
      }
      if (!isValid(entity)) {
        system5.runInterval(() => {
          if (isValid(entity) && entity.matches(this.queryOptions)) {
            this.push(entity);
          }
        }, 1);
      } else if (entity.matches(this.queryOptions)) {
        this.push(entity);
      }
    } catch (e) {
      _a8.logger.debug(
        "Failed to push entity to scheduler.",
        e
      );
    }
  }
  push(...items) {
    const filtered = items.filter(
      (item) => isValid(item) && !this.items.some(
        (existingItem) => this.compareEntities(existingItem, item)
      )
    );
    return super.push(...filtered);
  }
  unshift(...items) {
    const filtered = items.filter(
      (item) => isValid(item) && !this.items.some(
        (existingItem) => this.compareEntities(existingItem, item)
      )
    );
    return super.unshift(...filtered);
  }
  splice(start, deleteCount, ...items) {
    if (deleteCount === void 0) {
      return super.splice(start);
    }
    const filtered = items.filter(
      (item) => !this.items.some(
        (existingItem) => this.compareEntities(existingItem, item)
      )
    );
    return super.splice(start, deleteCount, ...filtered);
  }
}, __publicField(_a8, "logger", Logger.getLogger(
  "EntityPulseScheduler",
  "bedrock-boost",
  "entity-pulse-scheduler"
)), _a8);
var _a9;
var PlayerPulseScheduler = (_a9 = class extends PulseScheduler {
  /**
   * Creates a new PlayerPulseScheduler instance.
   * @param period The period of the scheduler.
   */
  constructor(processor, period) {
    super((t) => {
      if (isValid(t)) {
        processor(t);
      } else {
        this.removeIf((entity) => !isValid(entity));
      }
    }, period);
    this.push(...world5.getAllPlayers());
  }
  compareEntities(a, b) {
    return a.id === b.id;
  }
  start() {
    world5.afterEvents.playerJoin.subscribe((event) => {
      let attempts = 0;
      const pushPlayer = () => {
        attempts++;
        if (attempts > 10) {
          _a9.logger.debug("Failed to push player to scheduler after 10 attempts.");
          return;
        }
        try {
          const player = world5.getEntity(event.playerId);
          if (player === void 0) {
            system6.runTimeout(pushPlayer, 1);
          }
          if (player instanceof Player2) {
            this.push(player);
          }
        } catch (e) {
          _a9.logger.debug("Failed to push player to scheduler.", e);
          system6.runTimeout(pushPlayer, 1);
        }
      };
      pushPlayer();
    });
    world5.afterEvents.playerLeave.subscribe((event) => {
      this.removeIf((entity) => !isValid(entity) || entity.id === event.playerId);
    });
    super.start();
  }
  push(...items) {
    const filtered = items.filter((item) => isValid(item) && !this.items.some((existingItem) => this.compareEntities(existingItem, item)));
    return super.push(...filtered);
  }
  unshift(...items) {
    const filtered = items.filter((item) => isValid(item) && !this.items.some((existingItem) => this.compareEntities(existingItem, item)));
    return super.unshift(...filtered);
  }
  splice(start, deleteCount, ...items) {
    if (deleteCount === void 0) {
      return super.splice(start);
    }
    const filtered = items.filter((item) => !this.items.some((existingItem) => this.compareEntities(existingItem, item)));
    return super.splice(start, deleteCount, ...filtered);
  }
}, __publicField(_a9, "logger", Logger.getLogger("PlayerPulseScheduler", "bedrock-boost", "player-pulse-scheduler")), _a9);
var _a10;
var DirectionUtils = (_a10 = class {
}, /**
 * The opposite directions of the given directions.
 */
__publicField(_a10, "Opposites", {
  [Direction2.Down]: Direction2.Up,
  [Direction2.Up]: Direction2.Down,
  [Direction2.North]: Direction2.South,
  [Direction2.South]: Direction2.North,
  [Direction2.East]: Direction2.West,
  [Direction2.West]: Direction2.East
}), /**
 * The positive perpendicular directions of the given directions.
 */
__publicField(_a10, "PositivePerpendiculars", {
  [Direction2.Down]: [Direction2.East, Direction2.North],
  [Direction2.Up]: [Direction2.East, Direction2.North],
  [Direction2.North]: [Direction2.East, Direction2.Up],
  [Direction2.South]: [Direction2.East, Direction2.Up],
  [Direction2.East]: [Direction2.North, Direction2.Up],
  [Direction2.West]: [Direction2.North, Direction2.Up]
}), /**
 * The negative perpendicular directions of the given directions.
 */
__publicField(_a10, "NegativePerpendiculars", {
  [Direction2.Down]: [Direction2.West, Direction2.South],
  [Direction2.Up]: [Direction2.West, Direction2.South],
  [Direction2.North]: [Direction2.West, Direction2.Down],
  [Direction2.South]: [Direction2.West, Direction2.Down],
  [Direction2.East]: [Direction2.South, Direction2.Down],
  [Direction2.West]: [Direction2.South, Direction2.Down]
}), /**
 * All directions.
 */
__publicField(_a10, "Values", [
  Direction2.Down,
  Direction2.Up,
  Direction2.North,
  Direction2.South,
  Direction2.East,
  Direction2.West
]), _a10);
var log2 = Logger.getLogger("itemUtils", "bedrock-boost", "itemUtils");

// data/system_template_esbuild/subscripts/cave_2.ts
import { EntityDamageCause, Player as Player3, system as system8, TicksPerSecond, world as world7 } from "@minecraft/server";
var DEBUG = false;
world7.afterEvents.entityHitEntity.subscribe((event) => {
  const { damagingEntity: player, hitEntity } = event;
  if (player instanceof Player3 && hitEntity.typeId === "shapescape_dra:cave_dragon_egg") {
    const location = hitEntity.location;
    const dimension = hitEntity.dimension;
    const caveDragons = dimension.getEntities({
      location,
      maxDistance: 10,
      type: "shapescape_dra:cave_2_wild"
    });
    for (const dragon of caveDragons) {
      if (dragon.getProperty(`shapescape_dra:cave_dragon_state`) === `sleep_on_guard`) {
        dragon.triggerEvent(`wake_up_and_scream`);
      }
    }
  }
});
world7.afterEvents.playerBreakBlock.subscribe((event) => {
  const { block } = event;
  const location = block.location;
  const dimension = block.dimension;
  const caveDragons = dimension.getEntities({
    location,
    maxDistance: 5,
    type: "shapescape_dra:cave_2_wild"
  });
  for (const dragon of caveDragons) {
    if (dragon.getProperty(`shapescape_dra:cave_dragon_state`) === `sleep_on_guard`) {
      dragon.triggerEvent(`wake_up_and_scream`);
    }
  }
});
system8.afterEvents.scriptEventReceive.subscribe((event) => {
  const { message, id, sourceEntity } = event;
  if (sourceEntity && id === "shapescape_dra:cave_2_wild" && message === "wake_up_and_scream") {
    const location = sourceEntity.location;
    const radius = 10;
    const DAMAGE7 = 3;
    const DURATION = 60;
    let index = 0;
    const DELAY = 2.415 * TicksPerSecond;
    system8.runTimeout(() => {
      const runID = system8.runInterval(() => {
        if (!sourceEntity.isValid)
          return;
        index++;
        if (index > DURATION) {
          system8.clearRun(runID);
          sourceEntity.triggerEvent("attack_behavior");
          return;
        }
        if (DEBUG) {
          world7.sendMessage(`Error occured during cave dragon scream attack!`);
        }
        const entities = sourceEntity.dimension.getEntities({
          maxDistance: radius,
          location,
          excludeFamilies: ["inanimate", "projectile"],
          excludeTypes: ["minecraft:item", "minecraft:arrow"]
        });
        for (const entity of entities) {
          const substractionVector = Vec3.from(entity.location).subtract(sourceEntity.location);
          if (substractionVector.isZero())
            continue;
          const impulseVector = substractionVector.normalize().multiply(5e-3).setY(0);
          if (entity instanceof Player3) {
            entity.applyKnockback({ x: impulseVector.x * 1.25, z: impulseVector.z * 1.25 }, 0);
          } else {
            entity.applyImpulse(impulseVector);
          }
          entity.applyDamage(DAMAGE7, {
            cause: EntityDamageCause.magic,
            damagingEntity: sourceEntity
          });
        }
      }, 1);
    }, DELAY);
  }
});
world7.afterEvents.entityLoad.subscribe((event) => {
  const { entity } = event;
  if (entity.typeId === "shapescape_dra:cave_2_wild") {
    if (entity.getProperty(`shapescape_dra:cave_dragon_state`) === `wake_up_and_scream`) {
      entity.triggerEvent(`attack_behavior`);
    }
  }
});

// data/system_template_esbuild/subscripts/longneck.ts
import { world as world8 } from "@minecraft/server";
world8.afterEvents.entityHitEntity.subscribe((event) => {
  const { damagingEntity, hitEntity } = event;
  if (hitEntity.typeId === `shapescape_dra:longneck_creature`) {
    poisonAround(hitEntity);
    return;
  }
});
world8.afterEvents.projectileHitEntity.subscribe((event) => {
  const entityHit = event.getEntityHit().entity;
  if (!entityHit)
    return;
  if (entityHit.typeId === `shapescape_dra:longneck_creature`) {
    poisonAround(entityHit);
    return;
  }
});
function poisonAround(sourceEntity) {
  sourceEntity.dimension.spawnParticle(`shapescape_dra:longneck_poison`, sourceEntity.location);
  sourceEntity.dimension.playSound(`shapescape_dra.longneck_creature.poison`, sourceEntity.location, {
    volume: 0.5,
    pitch: 1.75
  });
  const entitiesToDamage = sourceEntity.dimension.getEntities({
    excludeTypes: ["shapescape_dra:longneck_creature"],
    location: sourceEntity.location,
    maxDistance: 3.5
  });
  for (const entity of entitiesToDamage) {
    entity.addEffect("minecraft:poison", 80, {
      amplifier: 0,
      showParticles: true
    });
    entity.addEffect("minecraft:nausea", 100, {
      amplifier: 0,
      showParticles: true
    });
  }
}

// data/system_template_esbuild/subscripts/puffer_creature.ts
import { world as world9, system as system10, EntityDamageCause as EntityDamageCause3 } from "@minecraft/server";
var RADIUS = 3;
var DAMAGE = 3;
world9.afterEvents.itemUse.subscribe((event) => {
  let player = event.source;
  let itemStack = event.itemStack;
  if (itemStack === void 0 || itemStack.typeId !== "shapescape_dra:puffer_creature_spike") {
    return;
  }
  player.playAnimation("animation.shapescape_dra.puffer_creature.player.puff");
  player.runCommand("clear @s shapescape_dra:puffer_creature_spike 0 1");
  player.dimension.playSound("shapescape_dra.puffer_creature.spikes", player.location);
  pufferCreaturePlayer(player);
  let runID1 = system10.runInterval(() => {
    if (player) {
      pufferCreaturePlayer(player);
    }
  }, 5);
  let runID2 = system10.runInterval(() => {
    if (player) {
      player.dimension.playSound("shapescape_dra.puffer_creature.spikes", player.location, {
        pitch: Math.random() * 0.2 + 0.9
      });
    }
  }, 15);
  system10.runTimeout(() => {
    system10.clearRun(runID1);
    system10.clearRun(runID2);
  }, 80);
});
function pufferCreaturePlayer(player) {
  const entities = player.dimension.getEntities({
    location: player.location,
    maxDistance: RADIUS
  });
  player.dimension.spawnParticle("shapescape_dra:puffer_creature", player.location);
  for (const entity of entities) {
    if (entity.id === player.id)
      continue;
    entity.applyDamage(DAMAGE, {
      cause: EntityDamageCause3.thorns,
      damagingEntity: player
    });
  }
}

// data/system_template_esbuild/subscripts/pyrobat_creature.ts
import {
  world as world10,
  BlockVolume,
  system as system11,
  EntityComponentTypes,
  EquipmentSlot as EquipmentSlot2
} from "@minecraft/server";
var VOLUME_SIZE_X = 8;
var VOLUME_SIZE_Y = 8;
var VOLUME_SIZE_Z = 8;
var MIN_LIGHT_LEVEL = 4;
system11.beforeEvents.startup.subscribe((event) => {
  event.blockComponentRegistry.registerCustomComponent("shapescape_dra:light", {
    onTick: (event2) => {
      const { x, y, z } = event2.block.location;
      const block = event2.block;
      const lightLevel = Number(block.typeId.replace("shapescape_dra:pyrobat_light_", ""));
      if (lightLevel > MIN_LIGHT_LEVEL) {
        block.dimension.spawnParticle(`shapescape_dra:pyrobat_creature_${lightLevel - 1}`, block.location);
        block.setType(`shapescape_dra:pyrobat_light_${lightLevel - 1}`);
      } else {
        block.setType(`minecraft:air`);
      }
    }
  });
});
world10.afterEvents.itemStartUse.subscribe((event) => {
  let player = event.source;
  let itemStack = event.itemStack;
  if (itemStack === void 0 || itemStack.typeId !== "shapescape_dra:pyrobat_bat") {
    return;
  }
  const { x, y, z } = player.location;
  const volumeP1 = {
    x: x - VOLUME_SIZE_X,
    y: y - VOLUME_SIZE_Y,
    z: z - VOLUME_SIZE_Z
  };
  const volumeP2 = {
    x: x + VOLUME_SIZE_X,
    y: y + VOLUME_SIZE_Y,
    z: z + VOLUME_SIZE_Z
  };
  const blockVolume = new BlockVolume(volumeP1, volumeP2);
  const playerEqComponent = player.getComponent(EntityComponentTypes.Equippable);
  const oldItemDurabilityComponent = itemStack.getComponent("minecraft:durability");
  const newDurability = oldItemDurabilityComponent.damage + 20;
  if (newDurability >= oldItemDurabilityComponent.maxDurability) {
    playerEqComponent.setEquipment(EquipmentSlot2.Mainhand);
    player.playSound("random.break", {
      location: player.location
    });
  } else {
    const newItemDurabilityComponent = itemStack.getComponent("minecraft:durability");
    newItemDurabilityComponent.damage = newDurability;
    playerEqComponent.setEquipment(EquipmentSlot2.Mainhand, itemStack);
  }
  lightUpSpace(blockVolume, player);
});
system11.afterEvents.scriptEventReceive.subscribe((event) => {
  const message = event.message;
  const messageID = event.id;
  const entity = event.sourceEntity;
  if (messageID === "shapescape_dra:pyrobat_creature" && message === "panic" && entity) {
    try {
      const { x, y, z } = entity.location;
      const block = entity.dimension.getBlock(entity.location);
      if (!block)
        return;
      if (!block.isAir)
        return;
      block.setType(`shapescape_dra:pyrobat_light_15`);
      const lightLevel = Number(block.typeId.replace("shapescape_dra:pyrobat_light_", ""));
      block.dimension.spawnParticle(`shapescape_dra:pyrobat_creature_${lightLevel}`, block.location);
    } catch (error) {
    }
  }
});
function lightUpSpace(blockVolume, entity) {
  const listOfCoordinates = blockVolume.getBlockLocationIterator();
  for (const coordinate of listOfCoordinates) {
    const randInt2 = Math.random();
    if (randInt2 > 0.03)
      continue;
    try {
      const block = entity.dimension.getBlock(coordinate);
      if (!block)
        continue;
      if (!block.isAir)
        continue;
      let randomLight = Math.round(Math.max(0, Math.min(15, Math.random() * 15 + 5)));
      block.setType(`shapescape_dra:pyrobat_light_${randomLight}`);
      const lightLevel = Number(block.typeId.replace("shapescape_dra:pyrobat_light_", ""));
      block.dimension.spawnParticle(`shapescape_dra:pyrobat_creature_${lightLevel}`, block.location);
    } catch (error) {
    }
  }
}

// data/system_template_esbuild/subscripts/twin_dragon_bifurcated_heart.ts
import { world as world11 } from "@minecraft/server";
world11.afterEvents.itemUse.subscribe((event) => {
  let player = event.source;
  let itemStack = event.itemStack;
  if (itemStack === void 0 || itemStack.typeId !== "shapescape_dra:twin_dragon_bifurcated_heart") {
    return;
  }
  player.runCommand("clear @s shapescape_dra:twin_dragon_bifurcated_heart 0 1");
  player.playSound(`shapescape_dra.twin_dragon_creature.heart_use`, {
    location: player.location,
    volume: 1,
    pitch: 0.65
  });
  player.dimension.spawnParticle(`shapescape_dra:twin_creature_heart_use`, player.location);
  if (Math.random() < 0.5) {
    passiveEffect(player);
  } else {
    activeEffect(player);
  }
});
function passiveEffect(player) {
  player.removeEffect("minecraft:poison");
  player.removeEffect("minecraft:weakness");
  player.addEffect("minecraft:regeneration", 20 * 10, { amplifier: 2 });
  player.addEffect("minecraft:resistance", 20 * 10, { amplifier: 1 });
}
function activeEffect(player) {
  player.removeEffect("minecraft:regeneration");
  player.removeEffect("minecraft:resistance");
  player.addEffect("minecraft:poison", 20 * 3, { amplifier: 1 });
  player.addEffect("minecraft:weakness", 20 * 3, { amplifier: 1 });
  let entities = player.dimension.getEntities({
    location: player.location,
    maxDistance: 6,
    excludeFamilies: ["player", "inanimate"],
    excludeTypes: ["minecraft:item", "minecraft:arrow"]
  });
  for (let entity of entities) {
    const pushStrength = 1.75;
    const pushVector = getImpulseVector(Vec3.from(player.location), Vec3.from(entity.location), pushStrength);
    try {
      entity.applyImpulse(pushVector);
      player.dimension.spawnParticle("shapescape_dra:poison_burst", player.location);
    } catch (error) {
    }
  }
}
function getImpulseVector(source, target, strength) {
  let direction = target.subtract(source);
  if (direction.length() === 0) {
    return new Vec3(0, 1, 0).normalize().divide(strength);
  }
  return direction.normalize().multiply(strength).add(Vec3.from(0, 0.35, 0));
}

// data/system_template_esbuild/subscripts/despawning_system.ts
import {
  world as world12,
  EntityInitializationCause
} from "@minecraft/server";
world12.afterEvents.entitySpawn.subscribe((event) => {
  const { entity, cause } = event;
  if (!entity || !entity.isValid)
    return;
  if (cause === EntityInitializationCause.Spawned)
    despawn(entity);
});
function despawn(entity) {
  let property = world12.getDynamicProperty(`despawning_system`);
  let propertyArray;
  if (property === void 0) {
    propertyArray = [];
  } else {
    propertyArray = JSON.parse(property);
  }
  if (propertyArray.includes(entity.typeId)) {
    try {
      entity.triggerEvent("shapescape_dra:despawn");
      entity.triggerEvent("despawn");
    } catch {
    }
  }
}

// data/system_template_esbuild/subscripts/tamed_attack_breath.ts
import { world as world13, system as system14 } from "@minecraft/server";
var TICK_INTERVAL = 1;
var projectiles = [];
var projectile = {
  dragonId: "",
  playerId: ""
};
var DAMAGE2 = 5;
function startBreathAttack(sourceEntity, player, eventID) {
  if (eventID == "shapescape_dra:tamed_attack_breath" && sourceEntity) {
    let dragon = {
      typeId: sourceEntity.typeId,
      vector: sourceEntity.getViewDirection(),
      location: sourceEntity.getHeadLocation(),
      dimension: sourceEntity.dimension
    };
    projectile = spawnProjectile(dragon.location, dragon.dimension);
    projectile = assignType(projectile, dragon.typeId);
    projectile = giveVector(projectile, getPlayerRotation(player.name));
    projectile = positionProjectile(projectile, dragon.typeId, dragon.vector);
    projectile.dragonId = sourceEntity.id;
    projectile.playerId = player.id;
    addProjectile(projectile);
  }
}
function addProjectile(projectile3) {
  projectiles.push(projectile3);
}
function removeProjectile(projectile3) {
  for (const item of projectiles) {
    projectiles = projectiles.filter((item2) => item2.id !== projectile3.id);
    return projectiles;
  }
}
function spawnProjectile(location, dimension) {
  let projectiles3;
  dimension.spawnEntity("shapescape_dra:tamed_breath_proj", location);
  projectiles3 = dimension.getEntities({
    type: "shapescape_dra:tamed_breath_proj",
    location,
    maxDistance: 1,
    closest: 1
  });
  for (const projectile3 of projectiles3) {
    return projectile3;
  }
}
function getPlayerRotation(playerName) {
  let players = world13.getPlayers({ name: playerName });
  const defaultVector = { x: 1, y: 1, z: 1 };
  if (players.length == 1) {
    return players[0].getViewDirection();
  } else if (players.length == 0) {
    return defaultVector;
  }
}
function assignType(projectile3, id) {
  id = id.replace("shapescape_dra:", "");
  id = id.replace("_tamed", "");
  id = id.replace("_2", "");
  id = id.replace("_3", "");
  projectile3.triggerEvent(id);
  return projectile3;
}
function giveVector(projectile3, playerVector) {
  let spreadX = Number(Math.min(Math.max((Math.random() - 0.5) / 2.5, -0.2), 0.2).toFixed(2));
  let spreadY = Number(Math.min(Math.max((Math.random() - 0.5) / 5, -0.1), 0.1).toFixed(2));
  let spreadZ = Number(Math.min(Math.max((Math.random() - 0.5) / 2.5, -0.2), 0.2).toFixed(2));
  playerVector.x = Number(playerVector.x.toFixed(2)) + spreadX;
  playerVector.y = Number(playerVector.y.toFixed(2)) + spreadY;
  playerVector.z = Number(playerVector.z.toFixed(2)) + spreadZ;
  projectile3.vector = playerVector;
  return projectile3;
}
function positionProjectile(projectile3, id, dragonVector) {
  id = id.replace("shapescape_dra:", "");
  switch (id) {
    case "fire_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.65,
        y: projectile3.location.y + dragonVector.y * 2 - 1,
        z: projectile3.location.z + dragonVector.z * 2.65
      });
      break;
    case "fire_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4.35,
        y: projectile3.location.y + dragonVector.y * 2 - 1.4,
        z: projectile3.location.z + dragonVector.z * 4.35
      });
      break;
    case "crystal_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 1.8,
        y: projectile3.location.y + dragonVector.y * 2 - 1.2,
        z: projectile3.location.z + dragonVector.z * 1.8
      });
      break;
    case "crystal_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.95,
        y: projectile3.location.y + dragonVector.y * 2 - 1.2,
        z: projectile3.location.z + dragonVector.z * 2.95
      });
      break;
    case "thunder_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 3,
        y: projectile3.location.y + dragonVector.y * 2 - 1.8,
        z: projectile3.location.z + dragonVector.z * 3
      });
      break;
    case "thunder_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4.5,
        y: projectile3.location.y + dragonVector.y * 2 - 2.2,
        z: projectile3.location.z + dragonVector.z * 4.5
      });
      break;
    case "poison_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.1,
        y: projectile3.location.y + dragonVector.y * 2 - 1,
        z: projectile3.location.z + dragonVector.z * 2.1
      });
      break;
    case "poison_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4,
        y: projectile3.location.y + dragonVector.y * 2 - 1,
        z: projectile3.location.z + dragonVector.z * 4
      });
      break;
    case "ice_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.7,
        y: projectile3.location.y + dragonVector.y * 2 - 1.55,
        z: projectile3.location.z + dragonVector.z * 2.7
      });
      break;
    case "ice_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4.4,
        y: projectile3.location.y + dragonVector.y * 2 - 1.8,
        z: projectile3.location.z + dragonVector.z * 4.4
      });
      break;
    case "fae_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.65,
        y: projectile3.location.y + dragonVector.y * 2 - 1.2,
        z: projectile3.location.z + dragonVector.z * 2.65
      });
      break;
    case "fae_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4.35,
        y: projectile3.location.y + dragonVector.y * 2 - 1.7,
        z: projectile3.location.z + dragonVector.z * 4.35
      });
      break;
  }
  return projectile3;
}
function moveEntity(projectile3) {
  if (projectile3.isValid == true) {
    let power = 0.05;
    let vectorX = projectile3.vector.x * power;
    let vectorY = projectile3.vector.y * power;
    let vectorZ = projectile3.vector.z * power;
    projectile3.applyImpulse({
      x: vectorX,
      y: vectorY,
      z: vectorZ
    });
  } else {
    removeProjectile(projectile3);
  }
}
function damageTargets(projectile3) {
  if (projectile3.isValid == true) {
    let targets = projectile3.dimension.getEntities({
      location: projectile3.location,
      maxDistance: 1.5
    });
    for (const target of targets) {
      if (target.id != projectile3.dragonId && target.id != projectile3.playerId && target.id != projectile3.id) {
        target.applyDamage(DAMAGE2);
      }
    }
  }
}
function main() {
  if (projectiles != null) {
    for (const projectile3 of projectiles) {
      moveEntity(projectile3);
      damageTargets(projectile3);
    }
  }
}
system14.runInterval(main, TICK_INTERVAL);

// data/system_template_esbuild/subscripts/tamed_attack_projectile.ts
import { world as world14, system as system15 } from "@minecraft/server";
var TICK_INTERVAL2 = 1;
var projectiles2 = [];
var projectile2 = {
  dragonId: "",
  playerId: ""
};
var DAMAGE3 = 10;
function startProjectileAttack(sourceEntity, player, eventID) {
  if (sourceEntity.typeId == "shapescape_dra:poison_3_tamed" && sourceEntity.isOnGround) {
    return;
  }
  let dragon = {
    typeId: sourceEntity.typeId,
    vector: sourceEntity.getViewDirection(),
    location: sourceEntity.getHeadLocation(),
    dimension: sourceEntity.dimension
  };
  projectile2 = spawnProjectile2(dragon.location, dragon.dimension, dragon.typeId);
  projectile2 = giveVector2(projectile2, getPlayerRotation2(player.name));
  projectile2 = positionProjectile2(projectile2, dragon.typeId, dragon.vector);
  projectile2.dragonId = sourceEntity.id;
  projectile2.playerId = player.id;
  addProjectile2(projectile2);
}
function addProjectile2(projectile3) {
  projectiles2.push(projectile3);
}
function removeProjectile2(projectile3) {
  for (const item of projectiles2) {
    projectiles2 = projectiles2.filter((item2) => item2.id !== projectile3.id);
    return projectiles2;
  }
}
function spawnProjectile2(location, dimension, dragonTypeId) {
  let projectiles3;
  if (dragonTypeId == "shapescape_dra:poison_3_tamed") {
    dimension.spawnEntity("shapescape_dra:poison_3_projectile", location);
    projectiles3 = dimension.getEntities({
      type: "shapescape_dra:poison_3_projectile",
      location,
      maxDistance: 1,
      closest: 1
    });
  } else if (dragonTypeId == "shapescape_dra:fire_3_tamed") {
    dimension.spawnEntity("shapescape_dra:fire_3_projectile", location);
    projectiles3 = dimension.getEntities({
      type: "shapescape_dra:fire_3_projectile",
      location,
      maxDistance: 1,
      closest: 1
    });
  } else if (dragonTypeId == "shapescape_dra:crystal_3_tamed") {
    dimension.spawnEntity("shapescape_dra:crystal_3_projectile", location);
    projectiles3 = dimension.getEntities({
      type: "shapescape_dra:crystal_3_projectile",
      location,
      maxDistance: 1,
      closest: 1
    });
  } else {
    const entity = dimension.spawnEntity("shapescape_dra:tamed_projectile_proj", location);
    let dragonType = dragonTypeId.replace("shapescape_dra:", "");
    dragonType = dragonType.replace("_tamed", "");
    dragonType = dragonType.replace("_2", "");
    dragonType = dragonType.replace("_3", "");
    entity.triggerEvent(dragonType);
    projectiles3 = dimension.getEntities({
      type: "shapescape_dra:tamed_projectile_proj",
      location,
      maxDistance: 1,
      closest: 1
    });
  }
  for (const projectile3 of projectiles3) {
    return projectile3;
  }
}
function getPlayerRotation2(playerName) {
  let players = world14.getPlayers({ name: playerName });
  const defaultVector = { x: 1, y: 1, z: 1 };
  if (players.length == 1) {
    return players[0].getViewDirection();
  } else if (players.length == 0) {
    return defaultVector;
  }
}
function giveVector2(projectile3, playerVector) {
  playerVector.x = Number(playerVector.x.toFixed(2));
  playerVector.y = Number(playerVector.y.toFixed(2));
  playerVector.z = Number(playerVector.z.toFixed(2));
  projectile3.vector = playerVector;
  return projectile3;
}
function positionProjectile2(projectile3, id, dragonVector) {
  id = id.replace("shapescape_dra:", "");
  switch (id) {
    case "fire_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.65,
        y: projectile3.location.y + dragonVector.y * 2 - 1,
        z: projectile3.location.z + dragonVector.z * 2.65
      });
      break;
    case "fire_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4.35,
        y: projectile3.location.y + dragonVector.y * 2 - 1.4,
        z: projectile3.location.z + dragonVector.z * 4.35
      });
      break;
    case "crystal_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 1.8,
        y: projectile3.location.y + dragonVector.y * 2 - 1.2,
        z: projectile3.location.z + dragonVector.z * 1.8
      });
      break;
    case "crystal_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.95,
        y: projectile3.location.y + dragonVector.y * 2 - 1.2,
        z: projectile3.location.z + dragonVector.z * 2.95
      });
      break;
    case "thunder_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 3,
        y: projectile3.location.y + dragonVector.y * 2 - 1.8,
        z: projectile3.location.z + dragonVector.z * 3
      });
      break;
    case "poison_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.1,
        y: projectile3.location.y + dragonVector.y * 2 - 1,
        z: projectile3.location.z + dragonVector.z * 2.1
      });
      break;
    case "poison_3_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 4,
        y: projectile3.location.y + dragonVector.y * 2 - 1,
        z: projectile3.location.z + dragonVector.z * 4
      });
      break;
    case "ice_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.7,
        y: projectile3.location.y + dragonVector.y * 2 - 1.55,
        z: projectile3.location.z + dragonVector.z * 2.7
      });
      break;
    case "fae_2_tamed":
      projectile3.teleport({
        x: projectile3.location.x + dragonVector.x * 2.65,
        y: projectile3.location.y + dragonVector.y * 2 - 1.2,
        z: projectile3.location.z + dragonVector.z * 2.65
      });
      break;
  }
  return projectile3;
}
function moveEntity2(projectile3) {
  if (projectile3.isValid == true) {
    let power = 0.1;
    world14.afterEvents.projectileHitBlock.subscribe((event) => {
      if (event.projectile == projectile3) {
        projectile3.triggerEvent("explode");
      }
    });
    let vectorX = projectile3.vector.x * power;
    let vectorY = projectile3.vector.y * power;
    let vectorZ = projectile3.vector.z * power;
    projectile3.applyImpulse({
      x: vectorX,
      y: vectorY,
      z: vectorZ
    });
  } else {
    removeProjectile2(projectile3);
  }
}
function damageTargets2(projectile3) {
  if (projectile3.isValid == true) {
    let targets = projectile3.dimension.getEntities({
      location: projectile3.location,
      maxDistance: 1.5
    });
    for (const target of targets) {
      if (target.id != projectile3.dragonId && target.id != projectile3.playerId && target.id != projectile3.id) {
        target.applyDamage(DAMAGE3);
        projectile3.triggerEvent("explode");
      }
    }
  }
}
function main2() {
  if (projectiles2 != null) {
    for (const projectile3 of projectiles2) {
      moveEntity2(projectile3);
      damageTargets2(projectile3);
    }
  }
}
system15.runInterval(main2, TICK_INTERVAL2);

// data/system_template_esbuild/subscripts/attack_thunder.ts
import { world as world15, system as system16, EntityComponentTypes as EntityComponentTypes3 } from "@minecraft/server";
var DRAGONS_ATTACKS = [
  {
    identifier: "shapescape_dra:thunder_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:thunder_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:thunder_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:thunder_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player) => {
      thirdStageSpecial(dragon, player);
    }
  }
];
system16.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
var DAMAGE4 = 10;
var DISTANCE = 15;
var ATTACK_DELAY = 20;
function thirdStageSpecial(dragon, player) {
  system16.runTimeout(() => {
    dragon.dimension.playSound("custom.shapescape_dra.attacks.thunder_tail_swing", dragon.location, {
      volume: 1,
      pitch: 1
    });
  }, 7);
  system16.runTimeout(() => {
    attack(dragon, player);
  }, ATTACK_DELAY);
}
function attack(dragon, player) {
  dragon.dimension.spawnParticle("shapescape_dra:special_attack_thunder_1", dragon.location);
  dragon.dimension.spawnParticle("shapescape_dra:special_attack_thunder_2", dragon.location);
  dragon.dimension.playSound("custom.shapescape_dra.attacks.thunder", dragon.location, { volume: 0.75 });
  let targets = dragon.dimension.getEntities({
    location: dragon.location,
    maxDistance: DISTANCE
  });
  targets.forEach((target) => {
    if (target.id != dragon.id && target.id != player.id && !checkIfTamed(target, player)) {
      target.applyDamage(DAMAGE4);
    }
  });
}
function getPlayersByName(playerName) {
  let players = world15.getPlayers({ name: playerName });
  if (players.length == 1) {
    return players[0];
  }
}
function checkIfTamed(entity, player) {
  if (entity.hasComponent(EntityComponentTypes3.Tameable)) {
    let entityTame = entity.getComponent(EntityComponentTypes3.Tameable);
    return entityTame.tamedToPlayer == player;
  } else {
    return false;
  }
}

// data/system_template_esbuild/subscripts/attack_fire.ts
import {
  world as world16,
  system as system17
} from "@minecraft/server";
var DRAGONS_ATTACKS2 = [
  {
    identifier: "shapescape_dra:fire_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:fire_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:fire_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:fire_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  }
];
system17.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS2) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName2(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
function getPlayersByName2(playerName) {
  let players = world16.getPlayers({ name: playerName });
  if (players.length == 1) {
    return players[0];
  }
}

// data/system_template_esbuild/subscripts/attack_fae.ts
import {
  world as world18,
  system as system19,
  EntityDamageCause as EntityDamageCause6
} from "@minecraft/server";

// data/node_modules/@shapescape-software/shapescriptapi/dist/index.mjs
import { system as system18 } from "@minecraft/server";
import { EntityInventoryComponent } from "@minecraft/server";
import {
  EntityTameableComponent as EntityTameableComponent3
} from "@minecraft/server";
import { world as world17 } from "@minecraft/server";
var Storage = class {
  constructor(storage, prefix) {
    __publicField(this, "MAX_BYTE_SIZE", 32 * 1024 - 1);
    __publicField(this, "storage");
    __publicField(this, "prefix");
    this.storage = storage;
    this.prefix = prefix ?? "";
  }
  /**
   * Sets a value in the storage.
   * @param key The key to set.
   * @param value The value to set. This can be any JSON-serializable value.
   * @param options Serialization options.
   */
  async set(key, value, options) {
    key = this.prefix + key;
    value = this.serialize(value, options);
    this.getStorage().setDynamicProperty(key, value);
  }
  /**
   * Removes a value from the storage.
   * @param key The key to remove.
   */
  async remove(key) {
    key = this.prefix + key;
    this.getStorage().setDynamicProperty(key);
  }
  /**
   * Clears all values from the storage.
   * @param pattern A pattern to match keys against. If provided, only keys that match the pattern will be cleared.
   */
  async clear(pattern) {
    if (!pattern) {
      this.getStorage().clearDynamicProperties();
    } else {
      pattern = this.prefix + pattern;
      const keys = this.getStorage().getDynamicPropertyIds();
      for (const key of keys) {
        if (key.startsWith(pattern)) {
          this.getStorage().setDynamicProperty(key);
        }
      }
    }
  }
  /**
   * Gets a value from the storage.
   * @param key The key to get.
   * @param deserialize Whether to deserialize the value.
   * @param options Deserialization options.
   * @returns The value if it exists, or `undefined` if it does not.
   */
  async get(key, deserialize = true, options) {
    key = this.prefix + key;
    const value = this.getStorage().getDynamicProperty(key);
    if (typeof value === "string" && deserialize)
      return this.deserialize(value, options);
    return value;
  }
  /**
   * Gets all values from the storage. Could lead to performance issues if the storage is large.
   * @param pattern A pattern to match keys against. If provided, only keys that match the pattern will be returned.
   * @param deserialize Whether to deserialize the values.
   * @param options Deserialization options.
   * @returns An array of key-value pairs.
   */
  async getAll(pattern, deserialize, options) {
    const properties = [];
    const keys = this.getStorage().getDynamicPropertyIds();
    if (!pattern)
      pattern = this.prefix;
    else
      pattern = this.prefix + pattern;
    for (let key of keys) {
      if (key.startsWith(pattern)) {
        key = key.slice(this.prefix.length);
        const value = this.getStorage().getDynamicProperty(key);
        if (typeof value === "string" && deserialize)
          properties.push({ [key]: this.deserialize(value, options) });
        else
          properties.push({ [key]: value });
      }
    }
    return properties;
  }
  /**
   * Pushes a value to the end of an array in the storage.
   * @param key The key of the array.
   * @param value The value to push.
   */
  async rPush(key, value) {
    const property = await this.assertArray(key, true);
    property.push(value);
    await this.set(key, property);
  }
  /**
   * Pushes a value to the start of an array in the storage.
   * @param key The key of the array.
   * @param value The value to push.
   */
  async lPush(key, value) {
    const property = await this.assertArray(key, true);
    property.unshift(value);
    await this.set(key, property);
  }
  /**
   * Pops a value from the end of an array in the storage.
   * @param key The key of the array.
   * @returns The value that was popped.
   */
  async rPop(key) {
    const property = await this.assertArray(key);
    const value = property.pop();
    await this.set(key, property);
    return value;
  }
  /**
   * Pops a value from the start of an array in the storage.
   * @param key The key of the array.
   * @returns The value that was popped.
   */
  async lPop(key) {
    const property = await this.assertArray(key);
    const value = property.shift();
    await this.set(key, property);
    return value;
  }
  /**
   * Check the byte size of a value in the storage.
   * @param key The key of the value.
   */
  async getByteSize(key) {
    return (await this.encodeValue(await this.get(key, false))).byteLength;
  }
  /**
   * Get the storage object.
   */
  getStorage() {
    return this.storage;
  }
  /**
   * @internal
   * Encodes a value to a Uint8Array.
   */
  async encodeValue(value) {
    const binStr = decodeURIComponent(encodeURIComponent(value)), arr = new Uint8Array(binStr.length);
    const split = binStr.split("");
    for (let i = 0; i < split.length; i++) {
      arr[i] = split[i].charCodeAt(0);
    }
    return arr;
  }
  /**
   * @internal
   * Serializes a value to a string.
   */
  serialize(data, options) {
    if (typeof data !== "string")
      return JSON.stringify(data, options?.replacer, options?.space);
    return data;
  }
  /**
   * @internal
   * Deserializes a string to a value.
   */
  deserialize(data, options) {
    try {
      return JSON.parse(data, options?.reviver);
    } catch (ignored) {
      return data;
    }
  }
  /**
   * @internal
   * Asserts that a property is an array.
   * @param key The key of the property.
   * @param init Whether to initialize the property if it does not exist.
   */
  async assertArray(key, init = false) {
    let property = await this.get(key);
    if (!property) {
      property = [];
      if (init)
        await this.set(key, []);
    } else if (!Array.isArray(property)) {
      throw new TypeError(`${key} is not an array`);
    }
    return property;
  }
};
function rotatePoint(point, rotation) {
  let newPoint = new Vec3(point.x, point.y, point.z);
  newPoint = newPoint.rotate({ x: 1, y: 0, z: 0 }, rotation.x);
  newPoint = newPoint.rotate({ x: 0, y: 1, z: 0 }, rotation.y);
  newPoint = newPoint.rotate({ x: 0, y: 0, z: 1 }, rotation.z);
  return newPoint;
}
function randInt(min, max) {
  return Math.floor(uniform(min, max + 1));
}
function uniform(min, max) {
  return Math.random() * (max - min) + min;
}
function getItemInMainHand(player) {
  const inventory = player.getComponent(EntityInventoryComponent.componentId);
  if (inventory && inventory instanceof EntityInventoryComponent && inventory.container) {
    return inventory.container.getItem(player.selectedSlotIndex);
  }
  return void 0;
}
var Segment = class _Segment {
  constructor(point1, point2) {
    __publicField(this, "point1");
    __publicField(this, "point2");
    __publicField(this, "length");
    point1 = new Vec3(point1);
    point2 = new Vec3(point2);
    this.point1 = point1;
    this.point2 = point2;
    this.length = point1.distance(point2);
  }
  /**
   * Creates a segment from a point and a direction.
   * @param point1
   * @param direction
   * @param length
   */
  static fromVectorWithDirection(point1, direction, length) {
    return new _Segment(point1, new Vec3({
      x: point1.x + direction.x * length,
      y: point1.y + direction.y * length,
      z: point1.z + direction.z * length
    }));
  }
  /**
   * Gets the first point of the segment.
   */
  getPoint1() {
    return this.point1;
  }
  /**
   * Gets the second point of the segment.
   */
  getPoint2() {
    return this.point2;
  }
  /**
   * Gets the smallest distance from the segment to the specified point.
   * @param point The point to measure the distance to.
   */
  distanceToPoint(point) {
    const segmentLength = this.getLength();
    const direction = this.getDirection(
      0
      /* POINT_1 */
    );
    const point1ToTarget = new Vec3({
      x: point.x - this.point1.x,
      y: point.y - this.point1.y,
      z: point.z - this.point1.z
    });
    const dotProduct = point1ToTarget.dot(direction);
    if (dotProduct <= 0) {
      return point1ToTarget.length();
    }
    if (dotProduct >= segmentLength) {
      return new Vec3(point).distance(this.point2);
    }
    const projection = direction.multiply(dotProduct);
    return point1ToTarget.subtract(projection).length();
  }
  /**
   * Rotates the segment around the specified pivot point by the specified rotation.
   * @param pivot The pivot point to rotate around.
   * @param rotation The rotation to apply.
   */
  rotate(pivot, rotation) {
    return new _Segment(
      rotatePoint(this.point1.subtract(pivot), new Vec3(rotation)).add(pivot),
      rotatePoint(this.point2.subtract(pivot), new Vec3(rotation)).add(pivot)
    );
  }
  /**
   * Gets the midpoint of the segment.
   */
  getMidPoint() {
    return Vec3.from({
      x: (this.point1.x + this.point2.x) / 2,
      y: (this.point1.y + this.point2.y) / 2,
      z: (this.point1.z + this.point2.z) / 2
    });
  }
  /**
   * Gets the length of the segment.
   */
  getLength() {
    return this.length;
  }
  /**
   * Get a new segment that is the inverse of this segment.
   */
  invert() {
    return new _Segment(this.point2, this.point1);
  }
  /**
   * Gets the direction of the segment.
   * @param from The vertex to get the direction from.
   */
  getDirection(from = 0) {
    const segmentLength = this.getLength();
    const source = from ? this.point2 : this.point1;
    const to = from ? this.point1 : this.point2;
    return new Vec3({
      x: to.x - source.x,
      y: to.y - source.y,
      z: to.z - source.z
    }).divide(segmentLength);
  }
  /**
   * Gets a point on the segment at the specified distance from the specified vertex.
   * @param from The vertex to start from.
   * @param distance The distance from the specified vertex.
   */
  findPointOnSegment(from, distance) {
    if (distance < 0) {
      from = from === 0 ? 1 : 0;
      distance = Math.abs(distance) + this.getLength();
    }
    const direction = this.getDirection(from);
    const source = from ? this.point2 : this.point1;
    return new Vec3({
      x: source.x + direction.x,
      y: source.y + direction.y,
      z: source.z + direction.z
    }).multiply(distance);
  }
};

// data/system_template_esbuild/subscripts/attack_fae.ts
var DAMAGE5 = 10;
var DISTANCE2 = 20;
var RADIUS2 = 2;
var ATTACK_DELAY2 = 10;
var DRAGONS_ATTACKS3 = [
  {
    identifier: "shapescape_dra:fae_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:fae_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:fae_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:fae_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon) => {
      thirdStageSpecial2(dragon);
    }
  }
];
system19.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS3) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName3(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
function thirdStageSpecial2(dragon) {
  system19.runTimeout(() => {
    if (!dragon.isValid)
      return;
    let mouthPosition = {
      x: dragon.location.x + dragon.getViewDirection().x * 4.35,
      y: dragon.location.y + dragon.getViewDirection().y * 2 + 1.4,
      z: dragon.location.z + dragon.getViewDirection().z * 4.35
    };
    let lastSegmentPosition = Vec3.from({
      x: dragon.getViewDirection().x * 5,
      y: dragon.getViewDirection().y * 2 * 5,
      z: dragon.getViewDirection().z * 5
    });
    let segment = new Segment(mouthPosition, lastSegmentPosition);
    let point = segment.getPoint1();
    let direction = segment.getPoint2().normalize();
    let entities = [];
    for (let index = 0; index < DISTANCE2; index++) {
      point = Vec3.from(point).add(direction);
      let entitiesToAdd = dragon.dimension.getEntities({
        location: point,
        maxDistance: RADIUS2,
        excludeFamilies: ["inanimate", "projectile"],
        excludeTypes: ["minecraft:item", "minecraft:arrow"]
      });
      entities.push(...entitiesToAdd);
    }
    for (const entity of entities) {
      if (!entity)
        continue;
      entity.applyDamage(DAMAGE5, {
        cause: EntityDamageCause6.magic
      });
      entity.setOnFire(5);
    }
    let visualsEntity = dragon.dimension.spawnEntity("shapescape_dra:fae_dragon_ultimate", mouthPosition);
    let rotation = dragon.getRotation();
    visualsEntity.setProperty("shapescape_dra:rotation_x", rotation.x * 1.75);
    visualsEntity.setProperty("shapescape_dra:rotation_y", rotation.y);
    dragon.dimension.playSound("custom.shapescape_dra.swords.thunder", dragon.location, {
      volume: 0.65,
      pitch: 1.5
    });
    dragon.dimension.playSound("custom.shapescape_dra.swords.fire", dragon.location, {
      volume: 0.65,
      pitch: 1.5
    });
  }, ATTACK_DELAY2);
}
function getPlayersByName3(playerName) {
  let players = world18.getPlayers({ name: playerName });
  if (players.length == 1) {
    return players[0];
  }
}

// data/system_template_esbuild/subscripts/attack_poison.ts
import { world as world19, system as system20, EntityComponentTypes as EntityComponentTypes5 } from "@minecraft/server";
var DRAGONS_ATTACKS4 = [
  {
    identifier: "shapescape_dra:poison_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:poison_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:poison_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:poison_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID !== void 0 && !dragon.isOnGround) {
        startProjectileAttack(dragon, player, eventID);
      } else {
        thirdStageSpecial3(dragon, player);
      }
    }
  }
];
system20.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS4) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName4(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
var MAX_DISTANCE = 20;
var MIN_DISTANCE = 5;
var ATTACK_DELAY3 = 20;
var NUM_OF_DAMAGERS = 20;
var damagerTypeId = "shapescape_dra:poison_3_spikes";
function thirdStageSpecial3(dragon, player) {
  dragon.dimension.playSound("custom.shapescape_dra.attacks.poison_tail_swing", dragon.location, {
    volume: 1,
    pitch: 1
  });
  system20.runTimeout(() => {
    attack2(dragon, player);
    dragon.dimension.playSound("custom.shapescape_dra.attacks.poison_tail_hit", dragon.location, {
      volume: 1,
      pitch: 1
    });
  }, ATTACK_DELAY3);
}
function attack2(dragon, player) {
  let targets = dragon.dimension.getEntities({
    location: dragon.location,
    maxDistance: MAX_DISTANCE,
    minDistance: MIN_DISTANCE
  });
  targets.forEach((target) => {
    targets = targets.filter((target2) => target2.id != player.id);
    targets = targets.filter((target2) => target2.id != dragon.id);
    targets = targets.filter((target2) => target2.id != damagerTypeId);
    if (checkIfTamed2(target, player)) {
      targets = targets.filter((tamedTarget) => tamedTarget.id != target.id);
    }
  });
  for (let index = 0; index < NUM_OF_DAMAGERS; index++) {
    let damager = world19.getDimension(dragon.dimension.id).spawnEntity(damagerTypeId, dragon.location);
    let hitChance = randomInt(0, 1);
    if (hitChance > 0.5 && targets.length > 0) {
      targets = attackTargets(dragon, player, damager, targets);
    } else {
      attackRandom(dragon, player, damager);
    }
  }
}
function attackTargets(dragon, player, damager, targets) {
  if (targets.length == 0) {
    return targets;
  }
  let randomIndex = randomInt(0, targets.length - 1);
  let otherDamagers = targets[randomIndex].dimension.getEntities({
    location: targets[randomIndex].location,
    type: damager.typeId,
    maxDistance: 0.5
  });
  if (otherDamagers.length > 0) {
    targets = targets.filter((target) => target != targets[randomIndex]);
    attackTargets(dragon, player, damager, targets);
  } else {
    damager.teleport(targets[randomIndex].location);
  }
  return targets;
}
function attackRandom(dragon, player, damager) {
  damager.runCommand(`/spreadplayers ~ ~ 4 ${MAX_DISTANCE} @s`);
}
function getPlayersByName4(player_name) {
  let players = world19.getPlayers({ name: player_name });
  if (players.length == 1) {
    return players[0];
  }
}
function checkIfTamed2(entity, player) {
  if (entity.hasComponent(EntityComponentTypes5.Tameable)) {
    let entityTame = entity.getComponent(EntityComponentTypes5.Tameable);
    return entityTame.tamedToPlayer == player;
  } else {
    return false;
  }
}
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// data/system_template_esbuild/subscripts/attack_ice.ts
import { world as world20, system as system21, EntityComponentTypes as EntityComponentTypes6 } from "@minecraft/server";
var TICK_INTERVAL3 = 20;
var MAX_DISTANCE2 = 20;
var MIN_DISTANCE2 = 0;
var DAMAGE6 = 5;
var COOLDOWN = 6;
var DRAGONS_ATTACKS5 = [
  {
    identifier: "shapescape_dra:ice_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:ice_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:ice_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:ice_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player) => {
      thirdStageSpecial4(dragon, player);
    }
  }
];
system21.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS5) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName5(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
var dragonPlayerPairs = [];
function thirdStageSpecial4(dragon, player) {
  if (dragon && player) {
    let dragonPlayerPair = {
      dragon,
      player
    };
    dragon.dimension.playSound("custom.shapescape_dra.attacks.ice_tail_swing", dragon.location, {
      pitch: 1,
      volume: 1
    });
    addDragon(dragonPlayerPair);
    dragonPlayerPair.dragon.setDynamicProperty("shapescape_dra_ice_3_tamed_attack", 0);
  }
}
function addDragon(dragonPlayerPair) {
  dragonPlayerPairs.push(dragonPlayerPair);
}
function removeDragon(dragonPlayerPair) {
  for (const item of dragonPlayerPairs) {
    dragonPlayerPairs = dragonPlayerPairs.filter((item2) => item2.dragon.id !== dragonPlayerPair.dragon.id);
    return dragonPlayerPairs;
  }
}
function attack3(dragon, player) {
  dragon.dimension.playSound("custom.shapescape_dra.attacks.ice_start", dragon.location, {
    pitch: 1,
    volume: 0.6
  });
  let targets = dragon.dimension.getEntities({
    location: dragon.location,
    maxDistance: MAX_DISTANCE2,
    minDistance: MIN_DISTANCE2
  });
  targets.forEach((target) => {
    targets = targets.filter((target2) => target2.id != player.id);
    targets = targets.filter((target2) => target2.id != dragon.id);
    if (checkIfTamed3(target, player)) {
      targets = targets.filter((tamedTarget) => tamedTarget.id != target.id);
    }
  });
  targets.forEach((target) => {
    target.addEffect("minecraft:slowness", 60, {
      amplifier: 1,
      showParticles: true
    });
    target.applyDamage(DAMAGE6);
  });
}
function main3() {
  if (dragonPlayerPairs.length > 0) {
    dragonPlayerPairs.forEach((dragonPlayerPair) => {
      if (!dragonPlayerPair.dragon.isValid) {
        return;
      }
      let cooldown = dragonPlayerPair.dragon.getDynamicProperty("shapescape_dra_ice_3_tamed_attack");
      cooldown++;
      if (cooldown >= COOLDOWN) {
        removeDragon(dragonPlayerPair);
      } else {
        attack3(dragonPlayerPair.dragon, dragonPlayerPair.player);
        dragonPlayerPair.dragon.setDynamicProperty("shapescape_dra_ice_3_tamed_attack", cooldown);
      }
    });
  }
}
system21.runInterval(main3, TICK_INTERVAL3);
function getPlayersByName5(playerName) {
  let players = world20.getPlayers({ name: playerName });
  if (players.length == 1) {
    return players[0];
  }
}
function checkIfTamed3(entity, player) {
  if (entity.hasComponent(EntityComponentTypes6.Tameable)) {
    let entityTame = entity.getComponent(EntityComponentTypes6.Tameable);
    return entityTame.tamedToPlayer == player;
  } else {
    return false;
  }
}

// data/system_template_esbuild/subscripts/attack_cave.ts
import {
  world as world21,
  system as system22,
  Player as Player16,
  EntityDamageCause as EntityDamageCause7,
  EntityComponentTypes as EntityComponentTypes7
} from "@minecraft/server";
var DEBUG2 = false;
var DRAGONS_ATTACKS6 = [
  {
    identifier: "shapescape_dra:cave_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      stageTwoOnHit(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:cave_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      stageTwoOnInteract(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:cave_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      stageThreeOnHit(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:cave_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      stageThreeOnInteract(dragon, player, eventID);
    }
  }
];
system22.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS6) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName6(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
function stageTwoOnHit(dragon, player, eventID) {
  const direction = Vec3.from(dragon.getViewDirection()).setY(0).normalize();
  const locations = [];
  let entities = /* @__PURE__ */ new Set();
  const mainLocation = direction.multiply(3).add(dragon.location).setY(dragon.location.y + 1);
  const leftVec = new Vec3(-direction.z, 0, direction.x);
  const rightVec = new Vec3(direction.z, 0, -direction.x);
  const locationLeft = mainLocation.add(leftVec);
  const locationRight = mainLocation.add(rightVec);
  locations.push(mainLocation);
  locations.push(locationLeft);
  locations.push(locationRight);
  const radius = 2;
  for (const location of locations) {
    if (DEBUG2) {
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, location);
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x,
        y: location.y,
        z: location.z + radius
      });
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x + radius,
        y: location.y,
        z: location.z
      });
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x,
        y: location.y,
        z: location.z - radius
      });
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x - radius,
        y: location.y,
        z: location.z
      });
    }
    let entitiesToAdd = dragon.dimension.getEntities({
      location,
      maxDistance: radius,
      excludeFamilies: ["inanimate", "projectile"],
      excludeTypes: ["minecraft:item", "minecraft:arrow"]
    });
    entitiesToAdd.forEach((entity) => entities.add(entity));
  }
  for (const entity of entities) {
    entity.applyDamage(1, {
      cause: EntityDamageCause7.entityAttack,
      damagingEntity: dragon
    });
  }
}
function stageTwoOnInteract(dragon, player, eventID) {
  const DURATION = 60;
  const DAMAGE7 = 3;
  const DISTANCE3 = 10;
  const RADIUS3 = 2;
  const ATTACK_DELAY4 = 20;
  let index = 0;
  system22.runTimeout(() => {
    const runID = system22.runInterval(() => {
      index++;
      if (index > DURATION) {
        system22.clearRun(runID);
        return;
      }
      if (!dragon.isValid)
        return;
      let mouthPosition = {
        x: dragon.location.x + dragon.getViewDirection().x * 4.35,
        y: dragon.location.y + dragon.getViewDirection().y * 2 + 1.4,
        z: dragon.location.z + dragon.getViewDirection().z * 4.35
      };
      let lastSegmentPosition = Vec3.from({
        x: dragon.getViewDirection().x * 5,
        y: dragon.getViewDirection().y * 2 * 5,
        z: dragon.getViewDirection().z * 5
      });
      if (system22.currentTick % 5 == 0) {
        let visualsEntity = dragon.dimension.spawnEntity("shapescape_dra:cave_dragon_ultimate", mouthPosition);
        let rotation = dragon.getRotation();
        visualsEntity.setProperty("shapescape_dra:rotation_x", rotation.x * 1.75);
        visualsEntity.setProperty("shapescape_dra:rotation_y", rotation.y);
      }
      let segment = new Segment(mouthPosition, lastSegmentPosition);
      let point = segment.getPoint1();
      let direction = segment.getPoint2().normalize();
      let entities = [];
      for (let index2 = 0; index2 < DISTANCE3; index2++) {
        point = Vec3.from(point).add(direction);
        if (DEBUG2) {
          dragon.dimension.spawnParticle(`minecraft:villager_happy`, point);
          dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
            x: point.x,
            y: point.y,
            z: point.z + RADIUS3
          });
          dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
            x: point.x + RADIUS3,
            y: point.y,
            z: point.z
          });
          dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
            x: point.x,
            y: point.y,
            z: point.z - RADIUS3
          });
          dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
            x: point.x - RADIUS3,
            y: point.y,
            z: point.z
          });
        }
        let entitiesToAdd = dragon.dimension.getEntities({
          location: point,
          maxDistance: RADIUS3,
          excludeFamilies: ["inanimate", "projectile"],
          excludeTypes: ["minecraft:item", "minecraft:arrow"]
        });
        entities.push(...entitiesToAdd);
      }
      for (const entity of entities) {
        if (!entity)
          continue;
        entity.applyImpulse(Vec3.from(dragon.getViewDirection()).multiply(0.1).setY(0));
        entity.applyDamage(DAMAGE7, {
          cause: EntityDamageCause7.magic,
          damagingEntity: dragon
        });
      }
    }, 1);
  }, ATTACK_DELAY4);
}
function stageThreeOnHit(dragon, player, eventID) {
  const direction = Vec3.from(dragon.getViewDirection()).setY(0).normalize();
  const locations = [];
  let entities = /* @__PURE__ */ new Set();
  const mainLocation = direction.multiply(3).add(dragon.location).setY(dragon.location.y + 1);
  const leftVec = new Vec3(-direction.z, 0, direction.x);
  const rightVec = new Vec3(direction.z, 0, -direction.x);
  const locationLeft = mainLocation.add(leftVec);
  const locationRight = mainLocation.add(rightVec);
  locations.push(mainLocation);
  locations.push(locationLeft);
  locations.push(locationRight);
  const radius = 2;
  for (const location of locations) {
    if (DEBUG2) {
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, location);
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x,
        y: location.y,
        z: location.z + radius
      });
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x + radius,
        y: location.y,
        z: location.z
      });
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x,
        y: location.y,
        z: location.z - radius
      });
      dragon.dimension.spawnParticle(`minecraft:villager_happy`, {
        x: location.x - radius,
        y: location.y,
        z: location.z
      });
    }
    let entitiesToAdd = dragon.dimension.getEntities({
      location,
      maxDistance: radius,
      excludeFamilies: ["inanimate", "projectile"],
      excludeTypes: ["minecraft:item", "minecraft:arrow"]
    });
    entitiesToAdd.forEach((entity) => entities.add(entity));
  }
  for (const entity of entities) {
    entity.applyDamage(2, {
      cause: EntityDamageCause7.entityAttack,
      damagingEntity: dragon
    });
  }
}
function stageThreeOnInteract(dragon, player, eventID) {
  const ATTACK_DELAY4 = 10;
  const radius = 10;
  const DAMAGE7 = 3;
  const DURATION = 60;
  let index = 0;
  system22.runTimeout(() => {
    const runID = system22.runInterval(() => {
      index++;
      if (index > DURATION) {
        system22.clearRun(runID);
        return;
      }
      if (!dragon || !player)
        return;
      const location = dragon.location;
      const entities = dragon.dimension.getEntities({
        maxDistance: radius,
        location,
        excludeFamilies: ["inanimate", "projectile"],
        excludeTypes: ["minecraft:item", "minecraft:arrow"]
      });
      for (const entity of entities) {
        if (checkIfTamed4(entity, player) || entity.id === player.id || entity.id === dragon.id) {
          continue;
        }
        const substractionVector = Vec3.from(entity.location).subtract(dragon.location);
        if (substractionVector.isZero())
          continue;
        const impulseVector = substractionVector.normalize().multiply(5e-3).setY(0);
        if (entity instanceof Player16) {
          entity.applyKnockback({ x: impulseVector.x, z: impulseVector.z }, 0);
        } else {
          entity.applyImpulse(impulseVector);
        }
        entity.applyDamage(DAMAGE7, {
          cause: EntityDamageCause7.magic,
          damagingEntity: dragon
        });
      }
    }, 1);
  }, ATTACK_DELAY4);
}
function getPlayersByName6(playerName) {
  let players = world21.getPlayers({ name: playerName });
  if (players.length == 1) {
    return players[0];
  }
}
function checkIfTamed4(entity, player) {
  if (entity.hasComponent(EntityComponentTypes7.Tameable)) {
    let entityTame = entity.getComponent(EntityComponentTypes7.Tameable);
    return entityTame.tamedToPlayer == player;
  } else {
    return false;
  }
}

// data/system_template_esbuild/subscripts/attack_crystal.ts
import {
  world as world22,
  system as system23
} from "@minecraft/server";
var DRAGONS_ATTACKS7 = [
  {
    identifier: "shapescape_dra:crystal_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:crystal_2_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:crystal_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_breath",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startBreathAttack(dragon, player, eventID);
    }
  },
  {
    identifier: "shapescape_dra:crystal_3_tamed",
    attackTypeEvent: "shapescape_dra:tamed_attack_special",
    callback: (dragon, player, eventID) => {
      if (eventID === void 0)
        return;
      startProjectileAttack(dragon, player, eventID);
    }
  }
];
system23.afterEvents.scriptEventReceive.subscribe((event) => {
  for (const dragonAttack of DRAGONS_ATTACKS7) {
    if (event.id == dragonAttack.attackTypeEvent && event.sourceEntity?.typeId == dragonAttack.identifier) {
      let dragon = event.sourceEntity;
      if (dragon != null && event.message.length > 1) {
        let player = getPlayersByName7(event.message);
        if (player) {
          dragonAttack.callback(dragon, player, event.id);
        }
      }
    }
  }
});
function onProjectileDie(event) {
  if (event.source && event.source.typeId === "shapescape_dra:crystal_3_projectile") {
    const location = new Vec3(event.source.location.x, event.source.location.y, event.source.location.z);
    system23.run(() => {
      event.dimension.playSound("custom.shapescape_dra.swords.crystal", location, { volume: 5 });
      event.dimension.playSound("break.amethyst_cluster", location, { volume: 5 });
      event.dimension.playSound("resonate.amethyst_block", location, { volume: 5 });
      const entities = event.dimension.getEntities({
        location,
        maxDistance: 10
      });
      const entitiesList = entities.filter(() => Math.random() > 0.5);
      if (entitiesList.length) {
        for (const entity of entitiesList) {
          entity.applyDamage(4);
        }
      }
    });
  }
}
world22.beforeEvents.explosion.subscribe(onProjectileDie);
function getPlayersByName7(playerName) {
  let players = world22.getPlayers({ name: playerName });
  if (players.length == 1) {
    return players[0];
  }
}

// data/system_template_esbuild/subscripts/breeding.ts
import { system as system24, world as world23 } from "@minecraft/server";
var TIMER_TICKS = 25;
var _Breeding = class _Breeding {
  static async tickDragons() {
    const dragons = world23.getDimension("overworld").getEntities({
      families: ["shapescape_dra_breedable", "shapescape_dra_dragon"]
    });
    dragons.push(
      ...world23.getDimension("nether").getEntities({
        families: ["shapescape_dra_breedable", "shapescape_dra_dragon"]
      })
    );
    dragons.push(
      ...world23.getDimension("the_end").getEntities({
        families: ["shapescape_dra_breedable", "shapescape_dra_dragon"]
      })
    );
    if (!dragons || dragons.length === 0)
      return;
    for (const dragon of dragons) {
      try {
        const dragonStorage = new Storage(dragon);
        const breedTime = await dragonStorage.get("shapescape_dra:breed_time");
        const currentTick = system24.currentTick;
        if (!dragon.isValid)
          continue;
        const items = dragon.getProperty("shapescape_dra:breeding_items");
        if (items != "none" || breedTime + _Breeding.TIME_TICKS - currentTick < -TIMER_TICKS * 2 + 1) {
          if (_Breeding.DEBUG)
            world23.sendMessage("Breed time set");
          await dragonStorage.set("shapescape_dra:breed_time", currentTick);
        }
        if (!dragon.isValid)
          continue;
        const resetStorage = dragon.getProperty("shapescape_dra:reset_storage");
        if (resetStorage) {
          await dragonStorage.remove("shapescape_dra:breed_time");
          if (!dragon.isValid)
            continue;
          dragon.setProperty("shapescape_dra:reset_storage", false);
        }
        if (!breedTime) {
          await dragonStorage.set("shapescape_dra:breed_time", currentTick - _Breeding.TIME_TICKS / 2);
          if (_Breeding.DEBUG)
            world23.sendMessage("Breed time set for the first time");
          continue;
        }
        if (_Breeding.DEBUG)
          world23.sendMessage(`Remaining ticks: ${breedTime + _Breeding.TIME_TICKS - currentTick}`);
        if (breedTime + _Breeding.TIME_TICKS - currentTick < -TIMER_TICKS + 1)
          continue;
        if (!dragon.isValid)
          continue;
        const wantsItem = dragon.getProperty("shapescape_dra:wants_item");
        if (currentTick >= breedTime + _Breeding.TIME_TICKS && !wantsItem) {
          if (_Breeding.DEBUG)
            world23.sendMessage("Wants item set");
          if (!dragon.isValid)
            continue;
          dragon.setProperty("shapescape_dra:wants_item", true);
        }
      } catch (e) {
        continue;
      }
    }
  }
};
__publicField(_Breeding, "TIME_TICKS", 1080 * 20);
// 18 minutes
__publicField(_Breeding, "DEBUG", false);
var Breeding = _Breeding;
system24.runInterval(Breeding.tickDragons, TIMER_TICKS);

// data/system_template_esbuild/subscripts/dragon_egg_summoner.ts
import {
  world as world24,
  system as system25,
  TicksPerDay,
  BlockVolume as BlockVolume2
} from "@minecraft/server";
var DEBUG3 = false;
system25.afterEvents.scriptEventReceive.subscribe((event) => {
  const { message, id, sourceEntity: spawner } = event;
  if (spawner && id.includes("shapescape_dra:") && id.includes("_dragon_egg_summoner") && message === "respawn_egg") {
    const DRAGON_TYPE = id.replace("shapescape_dra:", "").replace("_dragon_egg_summoner", "");
    const RADIUS3 = 5;
    const RADIUS_DRAGON = 30;
    const COOLDOWN3 = 1 * TicksPerDay;
    const location = spawner.location;
    const dimension = spawner.dimension;
    let canSpawn = false;
    let timeStamp = spawner.getDynamicProperty("dragon_egg_summoner_timestamp");
    let nestLocation = location;
    let nestAround = false;
    const entities = dimension.getEntities({
      location,
      maxDistance: RADIUS3
    });
    for (const entity of entities) {
      if (entity.typeId.includes(`shapescape_dra:`) && entity.typeId.includes(`_dragon_egg`)) {
        timeStamp = world24.getAbsoluteTime();
        spawner.setDynamicProperty("dragon_egg_summoner_timestamp", timeStamp);
        if (DEBUG3)
          world24.sendMessage("There's an egg nearby");
        return;
      }
    }
    const P1 = { x: location.x - RADIUS3, y: location.y - RADIUS3, z: location.z - RADIUS3 };
    const P2 = { x: location.x + RADIUS3, y: location.y + RADIUS3, z: location.z + RADIUS3 };
    const volume = new BlockVolume2(P1, P2);
    for (const location2 of volume.getBlockLocationIterator()) {
      let block;
      try {
        block = dimension.getBlock(location2);
      } catch {
        return;
      }
      if (block && block.typeId === `shapescape_dra:nest`) {
        nestLocation = { x: block.center().x, y: block.center().y + 1, z: block.center().z };
        nestAround = true;
        break;
      }
    }
    if (!nestAround) {
      timeStamp = world24.getAbsoluteTime();
      spawner.setDynamicProperty("dragon_egg_summoner_timestamp", timeStamp);
      if (DEBUG3)
        world24.sendMessage("No nest around");
      return;
    }
    if (timeStamp === void 0) {
      timeStamp = world24.getAbsoluteTime();
      spawner.setDynamicProperty("dragon_egg_summoner_timestamp", timeStamp);
    }
    if (timeStamp > world24.getAbsoluteTime()) {
      canSpawn = true;
    } else {
      canSpawn = Math.abs(world24.getAbsoluteTime() - timeStamp) >= COOLDOWN3;
    }
    if (DEBUG3) {
      world24.sendMessage(`timestamp: ${timeStamp}`);
      world24.sendMessage(`getAbsoluteTime: ${world24.getAbsoluteTime()}`);
      world24.sendMessage(`total: ${Math.abs(world24.getAbsoluteTime() - timeStamp)}`);
    }
    if (canSpawn) {
      try {
        spawner.setDynamicProperty("dragon_egg_summoner_timestamp", world24.getAbsoluteTime());
        dimension.spawnEntity(`shapescape_dra:${DRAGON_TYPE}_dragon_egg`, nestLocation);
        const adultDragons = dimension.getEntities({
          location: nestLocation,
          maxDistance: RADIUS_DRAGON,
          type: `shapescape_dra:${DRAGON_TYPE}_2_wild`
        });
        if (adultDragons.length === 0) {
          dimension.spawnEntity(`shapescape_dra:${DRAGON_TYPE}_2_wild`, {
            x: nestLocation.x,
            y: nestLocation.y + 20,
            z: nestLocation.z
          });
        }
      } catch {
      }
    }
  }
});

// data/system_template_esbuild/subscripts/fly.ts
import {
  world as world25,
  system as system26,
  Player as Player18,
  EntityRideableComponent as EntityRideableComponent2,
  EntityComponentTypes as EntityComponentTypes9
} from "@minecraft/server";

// data/node_modules/@minecraft/vanilla-data/lib/index.js
var MinecraftBiomeTypes = ((MinecraftBiomeTypes2) => {
  MinecraftBiomeTypes2["BambooJungle"] = "minecraft:bamboo_jungle";
  MinecraftBiomeTypes2["BambooJungleHills"] = "minecraft:bamboo_jungle_hills";
  MinecraftBiomeTypes2["BasaltDeltas"] = "minecraft:basalt_deltas";
  MinecraftBiomeTypes2["Beach"] = "minecraft:beach";
  MinecraftBiomeTypes2["BirchForest"] = "minecraft:birch_forest";
  MinecraftBiomeTypes2["BirchForestHills"] = "minecraft:birch_forest_hills";
  MinecraftBiomeTypes2["BirchForestHillsMutated"] = "minecraft:birch_forest_hills_mutated";
  MinecraftBiomeTypes2["BirchForestMutated"] = "minecraft:birch_forest_mutated";
  MinecraftBiomeTypes2["CherryGrove"] = "minecraft:cherry_grove";
  MinecraftBiomeTypes2["ColdBeach"] = "minecraft:cold_beach";
  MinecraftBiomeTypes2["ColdOcean"] = "minecraft:cold_ocean";
  MinecraftBiomeTypes2["ColdTaiga"] = "minecraft:cold_taiga";
  MinecraftBiomeTypes2["ColdTaigaHills"] = "minecraft:cold_taiga_hills";
  MinecraftBiomeTypes2["ColdTaigaMutated"] = "minecraft:cold_taiga_mutated";
  MinecraftBiomeTypes2["CrimsonForest"] = "minecraft:crimson_forest";
  MinecraftBiomeTypes2["DeepColdOcean"] = "minecraft:deep_cold_ocean";
  MinecraftBiomeTypes2["DeepDark"] = "minecraft:deep_dark";
  MinecraftBiomeTypes2["DeepFrozenOcean"] = "minecraft:deep_frozen_ocean";
  MinecraftBiomeTypes2["DeepLukewarmOcean"] = "minecraft:deep_lukewarm_ocean";
  MinecraftBiomeTypes2["DeepOcean"] = "minecraft:deep_ocean";
  MinecraftBiomeTypes2["DeepWarmOcean"] = "minecraft:deep_warm_ocean";
  MinecraftBiomeTypes2["Desert"] = "minecraft:desert";
  MinecraftBiomeTypes2["DesertHills"] = "minecraft:desert_hills";
  MinecraftBiomeTypes2["DesertMutated"] = "minecraft:desert_mutated";
  MinecraftBiomeTypes2["DripstoneCaves"] = "minecraft:dripstone_caves";
  MinecraftBiomeTypes2["ExtremeHills"] = "minecraft:extreme_hills";
  MinecraftBiomeTypes2["ExtremeHillsEdge"] = "minecraft:extreme_hills_edge";
  MinecraftBiomeTypes2["ExtremeHillsMutated"] = "minecraft:extreme_hills_mutated";
  MinecraftBiomeTypes2["ExtremeHillsPlusTrees"] = "minecraft:extreme_hills_plus_trees";
  MinecraftBiomeTypes2["ExtremeHillsPlusTreesMutated"] = "minecraft:extreme_hills_plus_trees_mutated";
  MinecraftBiomeTypes2["FlowerForest"] = "minecraft:flower_forest";
  MinecraftBiomeTypes2["Forest"] = "minecraft:forest";
  MinecraftBiomeTypes2["ForestHills"] = "minecraft:forest_hills";
  MinecraftBiomeTypes2["FrozenOcean"] = "minecraft:frozen_ocean";
  MinecraftBiomeTypes2["FrozenPeaks"] = "minecraft:frozen_peaks";
  MinecraftBiomeTypes2["FrozenRiver"] = "minecraft:frozen_river";
  MinecraftBiomeTypes2["Grove"] = "minecraft:grove";
  MinecraftBiomeTypes2["Hell"] = "minecraft:hell";
  MinecraftBiomeTypes2["IceMountains"] = "minecraft:ice_mountains";
  MinecraftBiomeTypes2["IcePlains"] = "minecraft:ice_plains";
  MinecraftBiomeTypes2["IcePlainsSpikes"] = "minecraft:ice_plains_spikes";
  MinecraftBiomeTypes2["JaggedPeaks"] = "minecraft:jagged_peaks";
  MinecraftBiomeTypes2["Jungle"] = "minecraft:jungle";
  MinecraftBiomeTypes2["JungleEdge"] = "minecraft:jungle_edge";
  MinecraftBiomeTypes2["JungleEdgeMutated"] = "minecraft:jungle_edge_mutated";
  MinecraftBiomeTypes2["JungleHills"] = "minecraft:jungle_hills";
  MinecraftBiomeTypes2["JungleMutated"] = "minecraft:jungle_mutated";
  MinecraftBiomeTypes2["LegacyFrozenOcean"] = "minecraft:legacy_frozen_ocean";
  MinecraftBiomeTypes2["LukewarmOcean"] = "minecraft:lukewarm_ocean";
  MinecraftBiomeTypes2["LushCaves"] = "minecraft:lush_caves";
  MinecraftBiomeTypes2["MangroveSwamp"] = "minecraft:mangrove_swamp";
  MinecraftBiomeTypes2["Meadow"] = "minecraft:meadow";
  MinecraftBiomeTypes2["MegaTaiga"] = "minecraft:mega_taiga";
  MinecraftBiomeTypes2["MegaTaigaHills"] = "minecraft:mega_taiga_hills";
  MinecraftBiomeTypes2["Mesa"] = "minecraft:mesa";
  MinecraftBiomeTypes2["MesaBryce"] = "minecraft:mesa_bryce";
  MinecraftBiomeTypes2["MesaPlateau"] = "minecraft:mesa_plateau";
  MinecraftBiomeTypes2["MesaPlateauMutated"] = "minecraft:mesa_plateau_mutated";
  MinecraftBiomeTypes2["MesaPlateauStone"] = "minecraft:mesa_plateau_stone";
  MinecraftBiomeTypes2["MesaPlateauStoneMutated"] = "minecraft:mesa_plateau_stone_mutated";
  MinecraftBiomeTypes2["MushroomIsland"] = "minecraft:mushroom_island";
  MinecraftBiomeTypes2["MushroomIslandShore"] = "minecraft:mushroom_island_shore";
  MinecraftBiomeTypes2["Ocean"] = "minecraft:ocean";
  MinecraftBiomeTypes2["Plains"] = "minecraft:plains";
  MinecraftBiomeTypes2["RedwoodTaigaHillsMutated"] = "minecraft:redwood_taiga_hills_mutated";
  MinecraftBiomeTypes2["RedwoodTaigaMutated"] = "minecraft:redwood_taiga_mutated";
  MinecraftBiomeTypes2["River"] = "minecraft:river";
  MinecraftBiomeTypes2["RoofedForest"] = "minecraft:roofed_forest";
  MinecraftBiomeTypes2["RoofedForestMutated"] = "minecraft:roofed_forest_mutated";
  MinecraftBiomeTypes2["Savanna"] = "minecraft:savanna";
  MinecraftBiomeTypes2["SavannaMutated"] = "minecraft:savanna_mutated";
  MinecraftBiomeTypes2["SavannaPlateau"] = "minecraft:savanna_plateau";
  MinecraftBiomeTypes2["SavannaPlateauMutated"] = "minecraft:savanna_plateau_mutated";
  MinecraftBiomeTypes2["SnowySlopes"] = "minecraft:snowy_slopes";
  MinecraftBiomeTypes2["SoulsandValley"] = "minecraft:soulsand_valley";
  MinecraftBiomeTypes2["StoneBeach"] = "minecraft:stone_beach";
  MinecraftBiomeTypes2["StonyPeaks"] = "minecraft:stony_peaks";
  MinecraftBiomeTypes2["SunflowerPlains"] = "minecraft:sunflower_plains";
  MinecraftBiomeTypes2["Swampland"] = "minecraft:swampland";
  MinecraftBiomeTypes2["SwamplandMutated"] = "minecraft:swampland_mutated";
  MinecraftBiomeTypes2["Taiga"] = "minecraft:taiga";
  MinecraftBiomeTypes2["TaigaHills"] = "minecraft:taiga_hills";
  MinecraftBiomeTypes2["TaigaMutated"] = "minecraft:taiga_mutated";
  MinecraftBiomeTypes2["TheEnd"] = "minecraft:the_end";
  MinecraftBiomeTypes2["WarmOcean"] = "minecraft:warm_ocean";
  MinecraftBiomeTypes2["WarpedForest"] = "minecraft:warped_forest";
  return MinecraftBiomeTypes2;
})(MinecraftBiomeTypes || {});
var MinecraftBlockTypes = ((MinecraftBlockTypes2) => {
  MinecraftBlockTypes2["AcaciaButton"] = "minecraft:acacia_button";
  MinecraftBlockTypes2["AcaciaDoor"] = "minecraft:acacia_door";
  MinecraftBlockTypes2["AcaciaDoubleSlab"] = "minecraft:acacia_double_slab";
  MinecraftBlockTypes2["AcaciaFence"] = "minecraft:acacia_fence";
  MinecraftBlockTypes2["AcaciaFenceGate"] = "minecraft:acacia_fence_gate";
  MinecraftBlockTypes2["AcaciaHangingSign"] = "minecraft:acacia_hanging_sign";
  MinecraftBlockTypes2["AcaciaLeaves"] = "minecraft:acacia_leaves";
  MinecraftBlockTypes2["AcaciaLog"] = "minecraft:acacia_log";
  MinecraftBlockTypes2["AcaciaPlanks"] = "minecraft:acacia_planks";
  MinecraftBlockTypes2["AcaciaPressurePlate"] = "minecraft:acacia_pressure_plate";
  MinecraftBlockTypes2["AcaciaSapling"] = "minecraft:acacia_sapling";
  MinecraftBlockTypes2["AcaciaSlab"] = "minecraft:acacia_slab";
  MinecraftBlockTypes2["AcaciaStairs"] = "minecraft:acacia_stairs";
  MinecraftBlockTypes2["AcaciaStandingSign"] = "minecraft:acacia_standing_sign";
  MinecraftBlockTypes2["AcaciaTrapdoor"] = "minecraft:acacia_trapdoor";
  MinecraftBlockTypes2["AcaciaWallSign"] = "minecraft:acacia_wall_sign";
  MinecraftBlockTypes2["AcaciaWood"] = "minecraft:acacia_wood";
  MinecraftBlockTypes2["ActivatorRail"] = "minecraft:activator_rail";
  MinecraftBlockTypes2["Air"] = "minecraft:air";
  MinecraftBlockTypes2["Allium"] = "minecraft:allium";
  MinecraftBlockTypes2["Allow"] = "minecraft:allow";
  MinecraftBlockTypes2["AmethystBlock"] = "minecraft:amethyst_block";
  MinecraftBlockTypes2["AmethystCluster"] = "minecraft:amethyst_cluster";
  MinecraftBlockTypes2["AncientDebris"] = "minecraft:ancient_debris";
  MinecraftBlockTypes2["Andesite"] = "minecraft:andesite";
  MinecraftBlockTypes2["AndesiteDoubleSlab"] = "minecraft:andesite_double_slab";
  MinecraftBlockTypes2["AndesiteSlab"] = "minecraft:andesite_slab";
  MinecraftBlockTypes2["AndesiteStairs"] = "minecraft:andesite_stairs";
  MinecraftBlockTypes2["Anvil"] = "minecraft:anvil";
  MinecraftBlockTypes2["Azalea"] = "minecraft:azalea";
  MinecraftBlockTypes2["AzaleaLeaves"] = "minecraft:azalea_leaves";
  MinecraftBlockTypes2["AzaleaLeavesFlowered"] = "minecraft:azalea_leaves_flowered";
  MinecraftBlockTypes2["AzureBluet"] = "minecraft:azure_bluet";
  MinecraftBlockTypes2["Bamboo"] = "minecraft:bamboo";
  MinecraftBlockTypes2["BambooBlock"] = "minecraft:bamboo_block";
  MinecraftBlockTypes2["BambooButton"] = "minecraft:bamboo_button";
  MinecraftBlockTypes2["BambooDoor"] = "minecraft:bamboo_door";
  MinecraftBlockTypes2["BambooDoubleSlab"] = "minecraft:bamboo_double_slab";
  MinecraftBlockTypes2["BambooFence"] = "minecraft:bamboo_fence";
  MinecraftBlockTypes2["BambooFenceGate"] = "minecraft:bamboo_fence_gate";
  MinecraftBlockTypes2["BambooHangingSign"] = "minecraft:bamboo_hanging_sign";
  MinecraftBlockTypes2["BambooMosaic"] = "minecraft:bamboo_mosaic";
  MinecraftBlockTypes2["BambooMosaicDoubleSlab"] = "minecraft:bamboo_mosaic_double_slab";
  MinecraftBlockTypes2["BambooMosaicSlab"] = "minecraft:bamboo_mosaic_slab";
  MinecraftBlockTypes2["BambooMosaicStairs"] = "minecraft:bamboo_mosaic_stairs";
  MinecraftBlockTypes2["BambooPlanks"] = "minecraft:bamboo_planks";
  MinecraftBlockTypes2["BambooPressurePlate"] = "minecraft:bamboo_pressure_plate";
  MinecraftBlockTypes2["BambooSapling"] = "minecraft:bamboo_sapling";
  MinecraftBlockTypes2["BambooSlab"] = "minecraft:bamboo_slab";
  MinecraftBlockTypes2["BambooStairs"] = "minecraft:bamboo_stairs";
  MinecraftBlockTypes2["BambooStandingSign"] = "minecraft:bamboo_standing_sign";
  MinecraftBlockTypes2["BambooTrapdoor"] = "minecraft:bamboo_trapdoor";
  MinecraftBlockTypes2["BambooWallSign"] = "minecraft:bamboo_wall_sign";
  MinecraftBlockTypes2["Barrel"] = "minecraft:barrel";
  MinecraftBlockTypes2["Barrier"] = "minecraft:barrier";
  MinecraftBlockTypes2["Basalt"] = "minecraft:basalt";
  MinecraftBlockTypes2["Beacon"] = "minecraft:beacon";
  MinecraftBlockTypes2["Bed"] = "minecraft:bed";
  MinecraftBlockTypes2["Bedrock"] = "minecraft:bedrock";
  MinecraftBlockTypes2["BeeNest"] = "minecraft:bee_nest";
  MinecraftBlockTypes2["Beehive"] = "minecraft:beehive";
  MinecraftBlockTypes2["Beetroot"] = "minecraft:beetroot";
  MinecraftBlockTypes2["Bell"] = "minecraft:bell";
  MinecraftBlockTypes2["BigDripleaf"] = "minecraft:big_dripleaf";
  MinecraftBlockTypes2["BirchButton"] = "minecraft:birch_button";
  MinecraftBlockTypes2["BirchDoor"] = "minecraft:birch_door";
  MinecraftBlockTypes2["BirchDoubleSlab"] = "minecraft:birch_double_slab";
  MinecraftBlockTypes2["BirchFence"] = "minecraft:birch_fence";
  MinecraftBlockTypes2["BirchFenceGate"] = "minecraft:birch_fence_gate";
  MinecraftBlockTypes2["BirchHangingSign"] = "minecraft:birch_hanging_sign";
  MinecraftBlockTypes2["BirchLeaves"] = "minecraft:birch_leaves";
  MinecraftBlockTypes2["BirchLog"] = "minecraft:birch_log";
  MinecraftBlockTypes2["BirchPlanks"] = "minecraft:birch_planks";
  MinecraftBlockTypes2["BirchPressurePlate"] = "minecraft:birch_pressure_plate";
  MinecraftBlockTypes2["BirchSapling"] = "minecraft:birch_sapling";
  MinecraftBlockTypes2["BirchSlab"] = "minecraft:birch_slab";
  MinecraftBlockTypes2["BirchStairs"] = "minecraft:birch_stairs";
  MinecraftBlockTypes2["BirchStandingSign"] = "minecraft:birch_standing_sign";
  MinecraftBlockTypes2["BirchTrapdoor"] = "minecraft:birch_trapdoor";
  MinecraftBlockTypes2["BirchWallSign"] = "minecraft:birch_wall_sign";
  MinecraftBlockTypes2["BirchWood"] = "minecraft:birch_wood";
  MinecraftBlockTypes2["BlackCandle"] = "minecraft:black_candle";
  MinecraftBlockTypes2["BlackCandleCake"] = "minecraft:black_candle_cake";
  MinecraftBlockTypes2["BlackCarpet"] = "minecraft:black_carpet";
  MinecraftBlockTypes2["BlackConcrete"] = "minecraft:black_concrete";
  MinecraftBlockTypes2["BlackConcretePowder"] = "minecraft:black_concrete_powder";
  MinecraftBlockTypes2["BlackGlazedTerracotta"] = "minecraft:black_glazed_terracotta";
  MinecraftBlockTypes2["BlackShulkerBox"] = "minecraft:black_shulker_box";
  MinecraftBlockTypes2["BlackStainedGlass"] = "minecraft:black_stained_glass";
  MinecraftBlockTypes2["BlackStainedGlassPane"] = "minecraft:black_stained_glass_pane";
  MinecraftBlockTypes2["BlackTerracotta"] = "minecraft:black_terracotta";
  MinecraftBlockTypes2["BlackWool"] = "minecraft:black_wool";
  MinecraftBlockTypes2["Blackstone"] = "minecraft:blackstone";
  MinecraftBlockTypes2["BlackstoneDoubleSlab"] = "minecraft:blackstone_double_slab";
  MinecraftBlockTypes2["BlackstoneSlab"] = "minecraft:blackstone_slab";
  MinecraftBlockTypes2["BlackstoneStairs"] = "minecraft:blackstone_stairs";
  MinecraftBlockTypes2["BlackstoneWall"] = "minecraft:blackstone_wall";
  MinecraftBlockTypes2["BlastFurnace"] = "minecraft:blast_furnace";
  MinecraftBlockTypes2["BlueCandle"] = "minecraft:blue_candle";
  MinecraftBlockTypes2["BlueCandleCake"] = "minecraft:blue_candle_cake";
  MinecraftBlockTypes2["BlueCarpet"] = "minecraft:blue_carpet";
  MinecraftBlockTypes2["BlueConcrete"] = "minecraft:blue_concrete";
  MinecraftBlockTypes2["BlueConcretePowder"] = "minecraft:blue_concrete_powder";
  MinecraftBlockTypes2["BlueGlazedTerracotta"] = "minecraft:blue_glazed_terracotta";
  MinecraftBlockTypes2["BlueIce"] = "minecraft:blue_ice";
  MinecraftBlockTypes2["BlueOrchid"] = "minecraft:blue_orchid";
  MinecraftBlockTypes2["BlueShulkerBox"] = "minecraft:blue_shulker_box";
  MinecraftBlockTypes2["BlueStainedGlass"] = "minecraft:blue_stained_glass";
  MinecraftBlockTypes2["BlueStainedGlassPane"] = "minecraft:blue_stained_glass_pane";
  MinecraftBlockTypes2["BlueTerracotta"] = "minecraft:blue_terracotta";
  MinecraftBlockTypes2["BlueWool"] = "minecraft:blue_wool";
  MinecraftBlockTypes2["BoneBlock"] = "minecraft:bone_block";
  MinecraftBlockTypes2["Bookshelf"] = "minecraft:bookshelf";
  MinecraftBlockTypes2["BorderBlock"] = "minecraft:border_block";
  MinecraftBlockTypes2["BrainCoral"] = "minecraft:brain_coral";
  MinecraftBlockTypes2["BrainCoralBlock"] = "minecraft:brain_coral_block";
  MinecraftBlockTypes2["BrainCoralFan"] = "minecraft:brain_coral_fan";
  MinecraftBlockTypes2["BrainCoralWallFan"] = "minecraft:brain_coral_wall_fan";
  MinecraftBlockTypes2["BrewingStand"] = "minecraft:brewing_stand";
  MinecraftBlockTypes2["BrickBlock"] = "minecraft:brick_block";
  MinecraftBlockTypes2["BrickDoubleSlab"] = "minecraft:brick_double_slab";
  MinecraftBlockTypes2["BrickSlab"] = "minecraft:brick_slab";
  MinecraftBlockTypes2["BrickStairs"] = "minecraft:brick_stairs";
  MinecraftBlockTypes2["BrownCandle"] = "minecraft:brown_candle";
  MinecraftBlockTypes2["BrownCandleCake"] = "minecraft:brown_candle_cake";
  MinecraftBlockTypes2["BrownCarpet"] = "minecraft:brown_carpet";
  MinecraftBlockTypes2["BrownConcrete"] = "minecraft:brown_concrete";
  MinecraftBlockTypes2["BrownConcretePowder"] = "minecraft:brown_concrete_powder";
  MinecraftBlockTypes2["BrownGlazedTerracotta"] = "minecraft:brown_glazed_terracotta";
  MinecraftBlockTypes2["BrownMushroom"] = "minecraft:brown_mushroom";
  MinecraftBlockTypes2["BrownMushroomBlock"] = "minecraft:brown_mushroom_block";
  MinecraftBlockTypes2["BrownShulkerBox"] = "minecraft:brown_shulker_box";
  MinecraftBlockTypes2["BrownStainedGlass"] = "minecraft:brown_stained_glass";
  MinecraftBlockTypes2["BrownStainedGlassPane"] = "minecraft:brown_stained_glass_pane";
  MinecraftBlockTypes2["BrownTerracotta"] = "minecraft:brown_terracotta";
  MinecraftBlockTypes2["BrownWool"] = "minecraft:brown_wool";
  MinecraftBlockTypes2["BubbleColumn"] = "minecraft:bubble_column";
  MinecraftBlockTypes2["BubbleCoral"] = "minecraft:bubble_coral";
  MinecraftBlockTypes2["BubbleCoralBlock"] = "minecraft:bubble_coral_block";
  MinecraftBlockTypes2["BubbleCoralFan"] = "minecraft:bubble_coral_fan";
  MinecraftBlockTypes2["BubbleCoralWallFan"] = "minecraft:bubble_coral_wall_fan";
  MinecraftBlockTypes2["BuddingAmethyst"] = "minecraft:budding_amethyst";
  MinecraftBlockTypes2["Cactus"] = "minecraft:cactus";
  MinecraftBlockTypes2["Cake"] = "minecraft:cake";
  MinecraftBlockTypes2["Calcite"] = "minecraft:calcite";
  MinecraftBlockTypes2["CalibratedSculkSensor"] = "minecraft:calibrated_sculk_sensor";
  MinecraftBlockTypes2["Camera"] = "minecraft:camera";
  MinecraftBlockTypes2["Campfire"] = "minecraft:campfire";
  MinecraftBlockTypes2["Candle"] = "minecraft:candle";
  MinecraftBlockTypes2["CandleCake"] = "minecraft:candle_cake";
  MinecraftBlockTypes2["Carrots"] = "minecraft:carrots";
  MinecraftBlockTypes2["CartographyTable"] = "minecraft:cartography_table";
  MinecraftBlockTypes2["CarvedPumpkin"] = "minecraft:carved_pumpkin";
  MinecraftBlockTypes2["Cauldron"] = "minecraft:cauldron";
  MinecraftBlockTypes2["CaveVines"] = "minecraft:cave_vines";
  MinecraftBlockTypes2["CaveVinesBodyWithBerries"] = "minecraft:cave_vines_body_with_berries";
  MinecraftBlockTypes2["CaveVinesHeadWithBerries"] = "minecraft:cave_vines_head_with_berries";
  MinecraftBlockTypes2["Chain"] = "minecraft:chain";
  MinecraftBlockTypes2["ChainCommandBlock"] = "minecraft:chain_command_block";
  MinecraftBlockTypes2["ChemicalHeat"] = "minecraft:chemical_heat";
  MinecraftBlockTypes2["ChemistryTable"] = "minecraft:chemistry_table";
  MinecraftBlockTypes2["CherryButton"] = "minecraft:cherry_button";
  MinecraftBlockTypes2["CherryDoor"] = "minecraft:cherry_door";
  MinecraftBlockTypes2["CherryDoubleSlab"] = "minecraft:cherry_double_slab";
  MinecraftBlockTypes2["CherryFence"] = "minecraft:cherry_fence";
  MinecraftBlockTypes2["CherryFenceGate"] = "minecraft:cherry_fence_gate";
  MinecraftBlockTypes2["CherryHangingSign"] = "minecraft:cherry_hanging_sign";
  MinecraftBlockTypes2["CherryLeaves"] = "minecraft:cherry_leaves";
  MinecraftBlockTypes2["CherryLog"] = "minecraft:cherry_log";
  MinecraftBlockTypes2["CherryPlanks"] = "minecraft:cherry_planks";
  MinecraftBlockTypes2["CherryPressurePlate"] = "minecraft:cherry_pressure_plate";
  MinecraftBlockTypes2["CherrySapling"] = "minecraft:cherry_sapling";
  MinecraftBlockTypes2["CherrySlab"] = "minecraft:cherry_slab";
  MinecraftBlockTypes2["CherryStairs"] = "minecraft:cherry_stairs";
  MinecraftBlockTypes2["CherryStandingSign"] = "minecraft:cherry_standing_sign";
  MinecraftBlockTypes2["CherryTrapdoor"] = "minecraft:cherry_trapdoor";
  MinecraftBlockTypes2["CherryWallSign"] = "minecraft:cherry_wall_sign";
  MinecraftBlockTypes2["CherryWood"] = "minecraft:cherry_wood";
  MinecraftBlockTypes2["Chest"] = "minecraft:chest";
  MinecraftBlockTypes2["ChippedAnvil"] = "minecraft:chipped_anvil";
  MinecraftBlockTypes2["ChiseledBookshelf"] = "minecraft:chiseled_bookshelf";
  MinecraftBlockTypes2["ChiseledCopper"] = "minecraft:chiseled_copper";
  MinecraftBlockTypes2["ChiseledDeepslate"] = "minecraft:chiseled_deepslate";
  MinecraftBlockTypes2["ChiseledNetherBricks"] = "minecraft:chiseled_nether_bricks";
  MinecraftBlockTypes2["ChiseledPolishedBlackstone"] = "minecraft:chiseled_polished_blackstone";
  MinecraftBlockTypes2["ChiseledQuartzBlock"] = "minecraft:chiseled_quartz_block";
  MinecraftBlockTypes2["ChiseledRedSandstone"] = "minecraft:chiseled_red_sandstone";
  MinecraftBlockTypes2["ChiseledSandstone"] = "minecraft:chiseled_sandstone";
  MinecraftBlockTypes2["ChiseledStoneBricks"] = "minecraft:chiseled_stone_bricks";
  MinecraftBlockTypes2["ChiseledTuff"] = "minecraft:chiseled_tuff";
  MinecraftBlockTypes2["ChiseledTuffBricks"] = "minecraft:chiseled_tuff_bricks";
  MinecraftBlockTypes2["ChorusFlower"] = "minecraft:chorus_flower";
  MinecraftBlockTypes2["ChorusPlant"] = "minecraft:chorus_plant";
  MinecraftBlockTypes2["Clay"] = "minecraft:clay";
  MinecraftBlockTypes2["ClientRequestPlaceholderBlock"] = "minecraft:client_request_placeholder_block";
  MinecraftBlockTypes2["CoalBlock"] = "minecraft:coal_block";
  MinecraftBlockTypes2["CoalOre"] = "minecraft:coal_ore";
  MinecraftBlockTypes2["CoarseDirt"] = "minecraft:coarse_dirt";
  MinecraftBlockTypes2["CobbledDeepslate"] = "minecraft:cobbled_deepslate";
  MinecraftBlockTypes2["CobbledDeepslateDoubleSlab"] = "minecraft:cobbled_deepslate_double_slab";
  MinecraftBlockTypes2["CobbledDeepslateSlab"] = "minecraft:cobbled_deepslate_slab";
  MinecraftBlockTypes2["CobbledDeepslateStairs"] = "minecraft:cobbled_deepslate_stairs";
  MinecraftBlockTypes2["CobbledDeepslateWall"] = "minecraft:cobbled_deepslate_wall";
  MinecraftBlockTypes2["Cobblestone"] = "minecraft:cobblestone";
  MinecraftBlockTypes2["CobblestoneDoubleSlab"] = "minecraft:cobblestone_double_slab";
  MinecraftBlockTypes2["CobblestoneSlab"] = "minecraft:cobblestone_slab";
  MinecraftBlockTypes2["CobblestoneWall"] = "minecraft:cobblestone_wall";
  MinecraftBlockTypes2["Cocoa"] = "minecraft:cocoa";
  MinecraftBlockTypes2["ColoredTorchBp"] = "minecraft:colored_torch_bp";
  MinecraftBlockTypes2["ColoredTorchRg"] = "minecraft:colored_torch_rg";
  MinecraftBlockTypes2["CommandBlock"] = "minecraft:command_block";
  MinecraftBlockTypes2["Composter"] = "minecraft:composter";
  MinecraftBlockTypes2["Conduit"] = "minecraft:conduit";
  MinecraftBlockTypes2["CopperBlock"] = "minecraft:copper_block";
  MinecraftBlockTypes2["CopperBulb"] = "minecraft:copper_bulb";
  MinecraftBlockTypes2["CopperDoor"] = "minecraft:copper_door";
  MinecraftBlockTypes2["CopperGrate"] = "minecraft:copper_grate";
  MinecraftBlockTypes2["CopperOre"] = "minecraft:copper_ore";
  MinecraftBlockTypes2["CopperTrapdoor"] = "minecraft:copper_trapdoor";
  MinecraftBlockTypes2["Cornflower"] = "minecraft:cornflower";
  MinecraftBlockTypes2["CrackedDeepslateBricks"] = "minecraft:cracked_deepslate_bricks";
  MinecraftBlockTypes2["CrackedDeepslateTiles"] = "minecraft:cracked_deepslate_tiles";
  MinecraftBlockTypes2["CrackedNetherBricks"] = "minecraft:cracked_nether_bricks";
  MinecraftBlockTypes2["CrackedPolishedBlackstoneBricks"] = "minecraft:cracked_polished_blackstone_bricks";
  MinecraftBlockTypes2["CrackedStoneBricks"] = "minecraft:cracked_stone_bricks";
  MinecraftBlockTypes2["Crafter"] = "minecraft:crafter";
  MinecraftBlockTypes2["CraftingTable"] = "minecraft:crafting_table";
  MinecraftBlockTypes2["CrimsonButton"] = "minecraft:crimson_button";
  MinecraftBlockTypes2["CrimsonDoor"] = "minecraft:crimson_door";
  MinecraftBlockTypes2["CrimsonDoubleSlab"] = "minecraft:crimson_double_slab";
  MinecraftBlockTypes2["CrimsonFence"] = "minecraft:crimson_fence";
  MinecraftBlockTypes2["CrimsonFenceGate"] = "minecraft:crimson_fence_gate";
  MinecraftBlockTypes2["CrimsonFungus"] = "minecraft:crimson_fungus";
  MinecraftBlockTypes2["CrimsonHangingSign"] = "minecraft:crimson_hanging_sign";
  MinecraftBlockTypes2["CrimsonHyphae"] = "minecraft:crimson_hyphae";
  MinecraftBlockTypes2["CrimsonNylium"] = "minecraft:crimson_nylium";
  MinecraftBlockTypes2["CrimsonPlanks"] = "minecraft:crimson_planks";
  MinecraftBlockTypes2["CrimsonPressurePlate"] = "minecraft:crimson_pressure_plate";
  MinecraftBlockTypes2["CrimsonRoots"] = "minecraft:crimson_roots";
  MinecraftBlockTypes2["CrimsonSlab"] = "minecraft:crimson_slab";
  MinecraftBlockTypes2["CrimsonStairs"] = "minecraft:crimson_stairs";
  MinecraftBlockTypes2["CrimsonStandingSign"] = "minecraft:crimson_standing_sign";
  MinecraftBlockTypes2["CrimsonStem"] = "minecraft:crimson_stem";
  MinecraftBlockTypes2["CrimsonTrapdoor"] = "minecraft:crimson_trapdoor";
  MinecraftBlockTypes2["CrimsonWallSign"] = "minecraft:crimson_wall_sign";
  MinecraftBlockTypes2["CryingObsidian"] = "minecraft:crying_obsidian";
  MinecraftBlockTypes2["CutCopper"] = "minecraft:cut_copper";
  MinecraftBlockTypes2["CutCopperSlab"] = "minecraft:cut_copper_slab";
  MinecraftBlockTypes2["CutCopperStairs"] = "minecraft:cut_copper_stairs";
  MinecraftBlockTypes2["CutRedSandstone"] = "minecraft:cut_red_sandstone";
  MinecraftBlockTypes2["CutRedSandstoneDoubleSlab"] = "minecraft:cut_red_sandstone_double_slab";
  MinecraftBlockTypes2["CutRedSandstoneSlab"] = "minecraft:cut_red_sandstone_slab";
  MinecraftBlockTypes2["CutSandstone"] = "minecraft:cut_sandstone";
  MinecraftBlockTypes2["CutSandstoneDoubleSlab"] = "minecraft:cut_sandstone_double_slab";
  MinecraftBlockTypes2["CutSandstoneSlab"] = "minecraft:cut_sandstone_slab";
  MinecraftBlockTypes2["CyanCandle"] = "minecraft:cyan_candle";
  MinecraftBlockTypes2["CyanCandleCake"] = "minecraft:cyan_candle_cake";
  MinecraftBlockTypes2["CyanCarpet"] = "minecraft:cyan_carpet";
  MinecraftBlockTypes2["CyanConcrete"] = "minecraft:cyan_concrete";
  MinecraftBlockTypes2["CyanConcretePowder"] = "minecraft:cyan_concrete_powder";
  MinecraftBlockTypes2["CyanGlazedTerracotta"] = "minecraft:cyan_glazed_terracotta";
  MinecraftBlockTypes2["CyanShulkerBox"] = "minecraft:cyan_shulker_box";
  MinecraftBlockTypes2["CyanStainedGlass"] = "minecraft:cyan_stained_glass";
  MinecraftBlockTypes2["CyanStainedGlassPane"] = "minecraft:cyan_stained_glass_pane";
  MinecraftBlockTypes2["CyanTerracotta"] = "minecraft:cyan_terracotta";
  MinecraftBlockTypes2["CyanWool"] = "minecraft:cyan_wool";
  MinecraftBlockTypes2["DamagedAnvil"] = "minecraft:damaged_anvil";
  MinecraftBlockTypes2["Dandelion"] = "minecraft:dandelion";
  MinecraftBlockTypes2["DarkOakButton"] = "minecraft:dark_oak_button";
  MinecraftBlockTypes2["DarkOakDoor"] = "minecraft:dark_oak_door";
  MinecraftBlockTypes2["DarkOakDoubleSlab"] = "minecraft:dark_oak_double_slab";
  MinecraftBlockTypes2["DarkOakFence"] = "minecraft:dark_oak_fence";
  MinecraftBlockTypes2["DarkOakFenceGate"] = "minecraft:dark_oak_fence_gate";
  MinecraftBlockTypes2["DarkOakHangingSign"] = "minecraft:dark_oak_hanging_sign";
  MinecraftBlockTypes2["DarkOakLeaves"] = "minecraft:dark_oak_leaves";
  MinecraftBlockTypes2["DarkOakLog"] = "minecraft:dark_oak_log";
  MinecraftBlockTypes2["DarkOakPlanks"] = "minecraft:dark_oak_planks";
  MinecraftBlockTypes2["DarkOakPressurePlate"] = "minecraft:dark_oak_pressure_plate";
  MinecraftBlockTypes2["DarkOakSapling"] = "minecraft:dark_oak_sapling";
  MinecraftBlockTypes2["DarkOakSlab"] = "minecraft:dark_oak_slab";
  MinecraftBlockTypes2["DarkOakStairs"] = "minecraft:dark_oak_stairs";
  MinecraftBlockTypes2["DarkOakTrapdoor"] = "minecraft:dark_oak_trapdoor";
  MinecraftBlockTypes2["DarkOakWood"] = "minecraft:dark_oak_wood";
  MinecraftBlockTypes2["DarkPrismarine"] = "minecraft:dark_prismarine";
  MinecraftBlockTypes2["DarkPrismarineDoubleSlab"] = "minecraft:dark_prismarine_double_slab";
  MinecraftBlockTypes2["DarkPrismarineSlab"] = "minecraft:dark_prismarine_slab";
  MinecraftBlockTypes2["DarkPrismarineStairs"] = "minecraft:dark_prismarine_stairs";
  MinecraftBlockTypes2["DarkoakStandingSign"] = "minecraft:darkoak_standing_sign";
  MinecraftBlockTypes2["DarkoakWallSign"] = "minecraft:darkoak_wall_sign";
  MinecraftBlockTypes2["DaylightDetector"] = "minecraft:daylight_detector";
  MinecraftBlockTypes2["DaylightDetectorInverted"] = "minecraft:daylight_detector_inverted";
  MinecraftBlockTypes2["DeadBrainCoral"] = "minecraft:dead_brain_coral";
  MinecraftBlockTypes2["DeadBrainCoralBlock"] = "minecraft:dead_brain_coral_block";
  MinecraftBlockTypes2["DeadBrainCoralFan"] = "minecraft:dead_brain_coral_fan";
  MinecraftBlockTypes2["DeadBrainCoralWallFan"] = "minecraft:dead_brain_coral_wall_fan";
  MinecraftBlockTypes2["DeadBubbleCoral"] = "minecraft:dead_bubble_coral";
  MinecraftBlockTypes2["DeadBubbleCoralBlock"] = "minecraft:dead_bubble_coral_block";
  MinecraftBlockTypes2["DeadBubbleCoralFan"] = "minecraft:dead_bubble_coral_fan";
  MinecraftBlockTypes2["DeadBubbleCoralWallFan"] = "minecraft:dead_bubble_coral_wall_fan";
  MinecraftBlockTypes2["DeadFireCoral"] = "minecraft:dead_fire_coral";
  MinecraftBlockTypes2["DeadFireCoralBlock"] = "minecraft:dead_fire_coral_block";
  MinecraftBlockTypes2["DeadFireCoralFan"] = "minecraft:dead_fire_coral_fan";
  MinecraftBlockTypes2["DeadFireCoralWallFan"] = "minecraft:dead_fire_coral_wall_fan";
  MinecraftBlockTypes2["DeadHornCoral"] = "minecraft:dead_horn_coral";
  MinecraftBlockTypes2["DeadHornCoralBlock"] = "minecraft:dead_horn_coral_block";
  MinecraftBlockTypes2["DeadHornCoralFan"] = "minecraft:dead_horn_coral_fan";
  MinecraftBlockTypes2["DeadHornCoralWallFan"] = "minecraft:dead_horn_coral_wall_fan";
  MinecraftBlockTypes2["DeadTubeCoral"] = "minecraft:dead_tube_coral";
  MinecraftBlockTypes2["DeadTubeCoralBlock"] = "minecraft:dead_tube_coral_block";
  MinecraftBlockTypes2["DeadTubeCoralFan"] = "minecraft:dead_tube_coral_fan";
  MinecraftBlockTypes2["DeadTubeCoralWallFan"] = "minecraft:dead_tube_coral_wall_fan";
  MinecraftBlockTypes2["Deadbush"] = "minecraft:deadbush";
  MinecraftBlockTypes2["DecoratedPot"] = "minecraft:decorated_pot";
  MinecraftBlockTypes2["Deepslate"] = "minecraft:deepslate";
  MinecraftBlockTypes2["DeepslateBrickDoubleSlab"] = "minecraft:deepslate_brick_double_slab";
  MinecraftBlockTypes2["DeepslateBrickSlab"] = "minecraft:deepslate_brick_slab";
  MinecraftBlockTypes2["DeepslateBrickStairs"] = "minecraft:deepslate_brick_stairs";
  MinecraftBlockTypes2["DeepslateBrickWall"] = "minecraft:deepslate_brick_wall";
  MinecraftBlockTypes2["DeepslateBricks"] = "minecraft:deepslate_bricks";
  MinecraftBlockTypes2["DeepslateCoalOre"] = "minecraft:deepslate_coal_ore";
  MinecraftBlockTypes2["DeepslateCopperOre"] = "minecraft:deepslate_copper_ore";
  MinecraftBlockTypes2["DeepslateDiamondOre"] = "minecraft:deepslate_diamond_ore";
  MinecraftBlockTypes2["DeepslateEmeraldOre"] = "minecraft:deepslate_emerald_ore";
  MinecraftBlockTypes2["DeepslateGoldOre"] = "minecraft:deepslate_gold_ore";
  MinecraftBlockTypes2["DeepslateIronOre"] = "minecraft:deepslate_iron_ore";
  MinecraftBlockTypes2["DeepslateLapisOre"] = "minecraft:deepslate_lapis_ore";
  MinecraftBlockTypes2["DeepslateRedstoneOre"] = "minecraft:deepslate_redstone_ore";
  MinecraftBlockTypes2["DeepslateTileDoubleSlab"] = "minecraft:deepslate_tile_double_slab";
  MinecraftBlockTypes2["DeepslateTileSlab"] = "minecraft:deepslate_tile_slab";
  MinecraftBlockTypes2["DeepslateTileStairs"] = "minecraft:deepslate_tile_stairs";
  MinecraftBlockTypes2["DeepslateTileWall"] = "minecraft:deepslate_tile_wall";
  MinecraftBlockTypes2["DeepslateTiles"] = "minecraft:deepslate_tiles";
  MinecraftBlockTypes2["Deny"] = "minecraft:deny";
  MinecraftBlockTypes2["DeprecatedAnvil"] = "minecraft:deprecated_anvil";
  MinecraftBlockTypes2["DetectorRail"] = "minecraft:detector_rail";
  MinecraftBlockTypes2["DiamondBlock"] = "minecraft:diamond_block";
  MinecraftBlockTypes2["DiamondOre"] = "minecraft:diamond_ore";
  MinecraftBlockTypes2["Diorite"] = "minecraft:diorite";
  MinecraftBlockTypes2["DioriteDoubleSlab"] = "minecraft:diorite_double_slab";
  MinecraftBlockTypes2["DioriteSlab"] = "minecraft:diorite_slab";
  MinecraftBlockTypes2["DioriteStairs"] = "minecraft:diorite_stairs";
  MinecraftBlockTypes2["Dirt"] = "minecraft:dirt";
  MinecraftBlockTypes2["DirtWithRoots"] = "minecraft:dirt_with_roots";
  MinecraftBlockTypes2["Dispenser"] = "minecraft:dispenser";
  MinecraftBlockTypes2["DoubleCutCopperSlab"] = "minecraft:double_cut_copper_slab";
  MinecraftBlockTypes2["DragonEgg"] = "minecraft:dragon_egg";
  MinecraftBlockTypes2["DriedKelpBlock"] = "minecraft:dried_kelp_block";
  MinecraftBlockTypes2["DripstoneBlock"] = "minecraft:dripstone_block";
  MinecraftBlockTypes2["Dropper"] = "minecraft:dropper";
  MinecraftBlockTypes2["Element0"] = "minecraft:element_0";
  MinecraftBlockTypes2["Element1"] = "minecraft:element_1";
  MinecraftBlockTypes2["Element10"] = "minecraft:element_10";
  MinecraftBlockTypes2["Element100"] = "minecraft:element_100";
  MinecraftBlockTypes2["Element101"] = "minecraft:element_101";
  MinecraftBlockTypes2["Element102"] = "minecraft:element_102";
  MinecraftBlockTypes2["Element103"] = "minecraft:element_103";
  MinecraftBlockTypes2["Element104"] = "minecraft:element_104";
  MinecraftBlockTypes2["Element105"] = "minecraft:element_105";
  MinecraftBlockTypes2["Element106"] = "minecraft:element_106";
  MinecraftBlockTypes2["Element107"] = "minecraft:element_107";
  MinecraftBlockTypes2["Element108"] = "minecraft:element_108";
  MinecraftBlockTypes2["Element109"] = "minecraft:element_109";
  MinecraftBlockTypes2["Element11"] = "minecraft:element_11";
  MinecraftBlockTypes2["Element110"] = "minecraft:element_110";
  MinecraftBlockTypes2["Element111"] = "minecraft:element_111";
  MinecraftBlockTypes2["Element112"] = "minecraft:element_112";
  MinecraftBlockTypes2["Element113"] = "minecraft:element_113";
  MinecraftBlockTypes2["Element114"] = "minecraft:element_114";
  MinecraftBlockTypes2["Element115"] = "minecraft:element_115";
  MinecraftBlockTypes2["Element116"] = "minecraft:element_116";
  MinecraftBlockTypes2["Element117"] = "minecraft:element_117";
  MinecraftBlockTypes2["Element118"] = "minecraft:element_118";
  MinecraftBlockTypes2["Element12"] = "minecraft:element_12";
  MinecraftBlockTypes2["Element13"] = "minecraft:element_13";
  MinecraftBlockTypes2["Element14"] = "minecraft:element_14";
  MinecraftBlockTypes2["Element15"] = "minecraft:element_15";
  MinecraftBlockTypes2["Element16"] = "minecraft:element_16";
  MinecraftBlockTypes2["Element17"] = "minecraft:element_17";
  MinecraftBlockTypes2["Element18"] = "minecraft:element_18";
  MinecraftBlockTypes2["Element19"] = "minecraft:element_19";
  MinecraftBlockTypes2["Element2"] = "minecraft:element_2";
  MinecraftBlockTypes2["Element20"] = "minecraft:element_20";
  MinecraftBlockTypes2["Element21"] = "minecraft:element_21";
  MinecraftBlockTypes2["Element22"] = "minecraft:element_22";
  MinecraftBlockTypes2["Element23"] = "minecraft:element_23";
  MinecraftBlockTypes2["Element24"] = "minecraft:element_24";
  MinecraftBlockTypes2["Element25"] = "minecraft:element_25";
  MinecraftBlockTypes2["Element26"] = "minecraft:element_26";
  MinecraftBlockTypes2["Element27"] = "minecraft:element_27";
  MinecraftBlockTypes2["Element28"] = "minecraft:element_28";
  MinecraftBlockTypes2["Element29"] = "minecraft:element_29";
  MinecraftBlockTypes2["Element3"] = "minecraft:element_3";
  MinecraftBlockTypes2["Element30"] = "minecraft:element_30";
  MinecraftBlockTypes2["Element31"] = "minecraft:element_31";
  MinecraftBlockTypes2["Element32"] = "minecraft:element_32";
  MinecraftBlockTypes2["Element33"] = "minecraft:element_33";
  MinecraftBlockTypes2["Element34"] = "minecraft:element_34";
  MinecraftBlockTypes2["Element35"] = "minecraft:element_35";
  MinecraftBlockTypes2["Element36"] = "minecraft:element_36";
  MinecraftBlockTypes2["Element37"] = "minecraft:element_37";
  MinecraftBlockTypes2["Element38"] = "minecraft:element_38";
  MinecraftBlockTypes2["Element39"] = "minecraft:element_39";
  MinecraftBlockTypes2["Element4"] = "minecraft:element_4";
  MinecraftBlockTypes2["Element40"] = "minecraft:element_40";
  MinecraftBlockTypes2["Element41"] = "minecraft:element_41";
  MinecraftBlockTypes2["Element42"] = "minecraft:element_42";
  MinecraftBlockTypes2["Element43"] = "minecraft:element_43";
  MinecraftBlockTypes2["Element44"] = "minecraft:element_44";
  MinecraftBlockTypes2["Element45"] = "minecraft:element_45";
  MinecraftBlockTypes2["Element46"] = "minecraft:element_46";
  MinecraftBlockTypes2["Element47"] = "minecraft:element_47";
  MinecraftBlockTypes2["Element48"] = "minecraft:element_48";
  MinecraftBlockTypes2["Element49"] = "minecraft:element_49";
  MinecraftBlockTypes2["Element5"] = "minecraft:element_5";
  MinecraftBlockTypes2["Element50"] = "minecraft:element_50";
  MinecraftBlockTypes2["Element51"] = "minecraft:element_51";
  MinecraftBlockTypes2["Element52"] = "minecraft:element_52";
  MinecraftBlockTypes2["Element53"] = "minecraft:element_53";
  MinecraftBlockTypes2["Element54"] = "minecraft:element_54";
  MinecraftBlockTypes2["Element55"] = "minecraft:element_55";
  MinecraftBlockTypes2["Element56"] = "minecraft:element_56";
  MinecraftBlockTypes2["Element57"] = "minecraft:element_57";
  MinecraftBlockTypes2["Element58"] = "minecraft:element_58";
  MinecraftBlockTypes2["Element59"] = "minecraft:element_59";
  MinecraftBlockTypes2["Element6"] = "minecraft:element_6";
  MinecraftBlockTypes2["Element60"] = "minecraft:element_60";
  MinecraftBlockTypes2["Element61"] = "minecraft:element_61";
  MinecraftBlockTypes2["Element62"] = "minecraft:element_62";
  MinecraftBlockTypes2["Element63"] = "minecraft:element_63";
  MinecraftBlockTypes2["Element64"] = "minecraft:element_64";
  MinecraftBlockTypes2["Element65"] = "minecraft:element_65";
  MinecraftBlockTypes2["Element66"] = "minecraft:element_66";
  MinecraftBlockTypes2["Element67"] = "minecraft:element_67";
  MinecraftBlockTypes2["Element68"] = "minecraft:element_68";
  MinecraftBlockTypes2["Element69"] = "minecraft:element_69";
  MinecraftBlockTypes2["Element7"] = "minecraft:element_7";
  MinecraftBlockTypes2["Element70"] = "minecraft:element_70";
  MinecraftBlockTypes2["Element71"] = "minecraft:element_71";
  MinecraftBlockTypes2["Element72"] = "minecraft:element_72";
  MinecraftBlockTypes2["Element73"] = "minecraft:element_73";
  MinecraftBlockTypes2["Element74"] = "minecraft:element_74";
  MinecraftBlockTypes2["Element75"] = "minecraft:element_75";
  MinecraftBlockTypes2["Element76"] = "minecraft:element_76";
  MinecraftBlockTypes2["Element77"] = "minecraft:element_77";
  MinecraftBlockTypes2["Element78"] = "minecraft:element_78";
  MinecraftBlockTypes2["Element79"] = "minecraft:element_79";
  MinecraftBlockTypes2["Element8"] = "minecraft:element_8";
  MinecraftBlockTypes2["Element80"] = "minecraft:element_80";
  MinecraftBlockTypes2["Element81"] = "minecraft:element_81";
  MinecraftBlockTypes2["Element82"] = "minecraft:element_82";
  MinecraftBlockTypes2["Element83"] = "minecraft:element_83";
  MinecraftBlockTypes2["Element84"] = "minecraft:element_84";
  MinecraftBlockTypes2["Element85"] = "minecraft:element_85";
  MinecraftBlockTypes2["Element86"] = "minecraft:element_86";
  MinecraftBlockTypes2["Element87"] = "minecraft:element_87";
  MinecraftBlockTypes2["Element88"] = "minecraft:element_88";
  MinecraftBlockTypes2["Element89"] = "minecraft:element_89";
  MinecraftBlockTypes2["Element9"] = "minecraft:element_9";
  MinecraftBlockTypes2["Element90"] = "minecraft:element_90";
  MinecraftBlockTypes2["Element91"] = "minecraft:element_91";
  MinecraftBlockTypes2["Element92"] = "minecraft:element_92";
  MinecraftBlockTypes2["Element93"] = "minecraft:element_93";
  MinecraftBlockTypes2["Element94"] = "minecraft:element_94";
  MinecraftBlockTypes2["Element95"] = "minecraft:element_95";
  MinecraftBlockTypes2["Element96"] = "minecraft:element_96";
  MinecraftBlockTypes2["Element97"] = "minecraft:element_97";
  MinecraftBlockTypes2["Element98"] = "minecraft:element_98";
  MinecraftBlockTypes2["Element99"] = "minecraft:element_99";
  MinecraftBlockTypes2["EmeraldBlock"] = "minecraft:emerald_block";
  MinecraftBlockTypes2["EmeraldOre"] = "minecraft:emerald_ore";
  MinecraftBlockTypes2["EnchantingTable"] = "minecraft:enchanting_table";
  MinecraftBlockTypes2["EndBrickStairs"] = "minecraft:end_brick_stairs";
  MinecraftBlockTypes2["EndBricks"] = "minecraft:end_bricks";
  MinecraftBlockTypes2["EndGateway"] = "minecraft:end_gateway";
  MinecraftBlockTypes2["EndPortal"] = "minecraft:end_portal";
  MinecraftBlockTypes2["EndPortalFrame"] = "minecraft:end_portal_frame";
  MinecraftBlockTypes2["EndRod"] = "minecraft:end_rod";
  MinecraftBlockTypes2["EndStone"] = "minecraft:end_stone";
  MinecraftBlockTypes2["EndStoneBrickDoubleSlab"] = "minecraft:end_stone_brick_double_slab";
  MinecraftBlockTypes2["EndStoneBrickSlab"] = "minecraft:end_stone_brick_slab";
  MinecraftBlockTypes2["EnderChest"] = "minecraft:ender_chest";
  MinecraftBlockTypes2["ExposedChiseledCopper"] = "minecraft:exposed_chiseled_copper";
  MinecraftBlockTypes2["ExposedCopper"] = "minecraft:exposed_copper";
  MinecraftBlockTypes2["ExposedCopperBulb"] = "minecraft:exposed_copper_bulb";
  MinecraftBlockTypes2["ExposedCopperDoor"] = "minecraft:exposed_copper_door";
  MinecraftBlockTypes2["ExposedCopperGrate"] = "minecraft:exposed_copper_grate";
  MinecraftBlockTypes2["ExposedCopperTrapdoor"] = "minecraft:exposed_copper_trapdoor";
  MinecraftBlockTypes2["ExposedCutCopper"] = "minecraft:exposed_cut_copper";
  MinecraftBlockTypes2["ExposedCutCopperSlab"] = "minecraft:exposed_cut_copper_slab";
  MinecraftBlockTypes2["ExposedCutCopperStairs"] = "minecraft:exposed_cut_copper_stairs";
  MinecraftBlockTypes2["ExposedDoubleCutCopperSlab"] = "minecraft:exposed_double_cut_copper_slab";
  MinecraftBlockTypes2["Farmland"] = "minecraft:farmland";
  MinecraftBlockTypes2["FenceGate"] = "minecraft:fence_gate";
  MinecraftBlockTypes2["Fern"] = "minecraft:fern";
  MinecraftBlockTypes2["Fire"] = "minecraft:fire";
  MinecraftBlockTypes2["FireCoral"] = "minecraft:fire_coral";
  MinecraftBlockTypes2["FireCoralBlock"] = "minecraft:fire_coral_block";
  MinecraftBlockTypes2["FireCoralFan"] = "minecraft:fire_coral_fan";
  MinecraftBlockTypes2["FireCoralWallFan"] = "minecraft:fire_coral_wall_fan";
  MinecraftBlockTypes2["FletchingTable"] = "minecraft:fletching_table";
  MinecraftBlockTypes2["FlowerPot"] = "minecraft:flower_pot";
  MinecraftBlockTypes2["FloweringAzalea"] = "minecraft:flowering_azalea";
  MinecraftBlockTypes2["FlowingLava"] = "minecraft:flowing_lava";
  MinecraftBlockTypes2["FlowingWater"] = "minecraft:flowing_water";
  MinecraftBlockTypes2["Frame"] = "minecraft:frame";
  MinecraftBlockTypes2["FrogSpawn"] = "minecraft:frog_spawn";
  MinecraftBlockTypes2["FrostedIce"] = "minecraft:frosted_ice";
  MinecraftBlockTypes2["Furnace"] = "minecraft:furnace";
  MinecraftBlockTypes2["GildedBlackstone"] = "minecraft:gilded_blackstone";
  MinecraftBlockTypes2["Glass"] = "minecraft:glass";
  MinecraftBlockTypes2["GlassPane"] = "minecraft:glass_pane";
  MinecraftBlockTypes2["GlowFrame"] = "minecraft:glow_frame";
  MinecraftBlockTypes2["GlowLichen"] = "minecraft:glow_lichen";
  MinecraftBlockTypes2["Glowingobsidian"] = "minecraft:glowingobsidian";
  MinecraftBlockTypes2["Glowstone"] = "minecraft:glowstone";
  MinecraftBlockTypes2["GoldBlock"] = "minecraft:gold_block";
  MinecraftBlockTypes2["GoldOre"] = "minecraft:gold_ore";
  MinecraftBlockTypes2["GoldenRail"] = "minecraft:golden_rail";
  MinecraftBlockTypes2["Granite"] = "minecraft:granite";
  MinecraftBlockTypes2["GraniteDoubleSlab"] = "minecraft:granite_double_slab";
  MinecraftBlockTypes2["GraniteSlab"] = "minecraft:granite_slab";
  MinecraftBlockTypes2["GraniteStairs"] = "minecraft:granite_stairs";
  MinecraftBlockTypes2["GrassBlock"] = "minecraft:grass_block";
  MinecraftBlockTypes2["GrassPath"] = "minecraft:grass_path";
  MinecraftBlockTypes2["Gravel"] = "minecraft:gravel";
  MinecraftBlockTypes2["GrayCandle"] = "minecraft:gray_candle";
  MinecraftBlockTypes2["GrayCandleCake"] = "minecraft:gray_candle_cake";
  MinecraftBlockTypes2["GrayCarpet"] = "minecraft:gray_carpet";
  MinecraftBlockTypes2["GrayConcrete"] = "minecraft:gray_concrete";
  MinecraftBlockTypes2["GrayConcretePowder"] = "minecraft:gray_concrete_powder";
  MinecraftBlockTypes2["GrayGlazedTerracotta"] = "minecraft:gray_glazed_terracotta";
  MinecraftBlockTypes2["GrayShulkerBox"] = "minecraft:gray_shulker_box";
  MinecraftBlockTypes2["GrayStainedGlass"] = "minecraft:gray_stained_glass";
  MinecraftBlockTypes2["GrayStainedGlassPane"] = "minecraft:gray_stained_glass_pane";
  MinecraftBlockTypes2["GrayTerracotta"] = "minecraft:gray_terracotta";
  MinecraftBlockTypes2["GrayWool"] = "minecraft:gray_wool";
  MinecraftBlockTypes2["GreenCandle"] = "minecraft:green_candle";
  MinecraftBlockTypes2["GreenCandleCake"] = "minecraft:green_candle_cake";
  MinecraftBlockTypes2["GreenCarpet"] = "minecraft:green_carpet";
  MinecraftBlockTypes2["GreenConcrete"] = "minecraft:green_concrete";
  MinecraftBlockTypes2["GreenConcretePowder"] = "minecraft:green_concrete_powder";
  MinecraftBlockTypes2["GreenGlazedTerracotta"] = "minecraft:green_glazed_terracotta";
  MinecraftBlockTypes2["GreenShulkerBox"] = "minecraft:green_shulker_box";
  MinecraftBlockTypes2["GreenStainedGlass"] = "minecraft:green_stained_glass";
  MinecraftBlockTypes2["GreenStainedGlassPane"] = "minecraft:green_stained_glass_pane";
  MinecraftBlockTypes2["GreenTerracotta"] = "minecraft:green_terracotta";
  MinecraftBlockTypes2["GreenWool"] = "minecraft:green_wool";
  MinecraftBlockTypes2["Grindstone"] = "minecraft:grindstone";
  MinecraftBlockTypes2["HangingRoots"] = "minecraft:hanging_roots";
  MinecraftBlockTypes2["HardBlackStainedGlass"] = "minecraft:hard_black_stained_glass";
  MinecraftBlockTypes2["HardBlackStainedGlassPane"] = "minecraft:hard_black_stained_glass_pane";
  MinecraftBlockTypes2["HardBlueStainedGlass"] = "minecraft:hard_blue_stained_glass";
  MinecraftBlockTypes2["HardBlueStainedGlassPane"] = "minecraft:hard_blue_stained_glass_pane";
  MinecraftBlockTypes2["HardBrownStainedGlass"] = "minecraft:hard_brown_stained_glass";
  MinecraftBlockTypes2["HardBrownStainedGlassPane"] = "minecraft:hard_brown_stained_glass_pane";
  MinecraftBlockTypes2["HardCyanStainedGlass"] = "minecraft:hard_cyan_stained_glass";
  MinecraftBlockTypes2["HardCyanStainedGlassPane"] = "minecraft:hard_cyan_stained_glass_pane";
  MinecraftBlockTypes2["HardGlass"] = "minecraft:hard_glass";
  MinecraftBlockTypes2["HardGlassPane"] = "minecraft:hard_glass_pane";
  MinecraftBlockTypes2["HardGrayStainedGlass"] = "minecraft:hard_gray_stained_glass";
  MinecraftBlockTypes2["HardGrayStainedGlassPane"] = "minecraft:hard_gray_stained_glass_pane";
  MinecraftBlockTypes2["HardGreenStainedGlass"] = "minecraft:hard_green_stained_glass";
  MinecraftBlockTypes2["HardGreenStainedGlassPane"] = "minecraft:hard_green_stained_glass_pane";
  MinecraftBlockTypes2["HardLightBlueStainedGlass"] = "minecraft:hard_light_blue_stained_glass";
  MinecraftBlockTypes2["HardLightBlueStainedGlassPane"] = "minecraft:hard_light_blue_stained_glass_pane";
  MinecraftBlockTypes2["HardLightGrayStainedGlass"] = "minecraft:hard_light_gray_stained_glass";
  MinecraftBlockTypes2["HardLightGrayStainedGlassPane"] = "minecraft:hard_light_gray_stained_glass_pane";
  MinecraftBlockTypes2["HardLimeStainedGlass"] = "minecraft:hard_lime_stained_glass";
  MinecraftBlockTypes2["HardLimeStainedGlassPane"] = "minecraft:hard_lime_stained_glass_pane";
  MinecraftBlockTypes2["HardMagentaStainedGlass"] = "minecraft:hard_magenta_stained_glass";
  MinecraftBlockTypes2["HardMagentaStainedGlassPane"] = "minecraft:hard_magenta_stained_glass_pane";
  MinecraftBlockTypes2["HardOrangeStainedGlass"] = "minecraft:hard_orange_stained_glass";
  MinecraftBlockTypes2["HardOrangeStainedGlassPane"] = "minecraft:hard_orange_stained_glass_pane";
  MinecraftBlockTypes2["HardPinkStainedGlass"] = "minecraft:hard_pink_stained_glass";
  MinecraftBlockTypes2["HardPinkStainedGlassPane"] = "minecraft:hard_pink_stained_glass_pane";
  MinecraftBlockTypes2["HardPurpleStainedGlass"] = "minecraft:hard_purple_stained_glass";
  MinecraftBlockTypes2["HardPurpleStainedGlassPane"] = "minecraft:hard_purple_stained_glass_pane";
  MinecraftBlockTypes2["HardRedStainedGlass"] = "minecraft:hard_red_stained_glass";
  MinecraftBlockTypes2["HardRedStainedGlassPane"] = "minecraft:hard_red_stained_glass_pane";
  MinecraftBlockTypes2["HardWhiteStainedGlass"] = "minecraft:hard_white_stained_glass";
  MinecraftBlockTypes2["HardWhiteStainedGlassPane"] = "minecraft:hard_white_stained_glass_pane";
  MinecraftBlockTypes2["HardYellowStainedGlass"] = "minecraft:hard_yellow_stained_glass";
  MinecraftBlockTypes2["HardYellowStainedGlassPane"] = "minecraft:hard_yellow_stained_glass_pane";
  MinecraftBlockTypes2["HardenedClay"] = "minecraft:hardened_clay";
  MinecraftBlockTypes2["HayBlock"] = "minecraft:hay_block";
  MinecraftBlockTypes2["HeavyCore"] = "minecraft:heavy_core";
  MinecraftBlockTypes2["HeavyWeightedPressurePlate"] = "minecraft:heavy_weighted_pressure_plate";
  MinecraftBlockTypes2["HoneyBlock"] = "minecraft:honey_block";
  MinecraftBlockTypes2["HoneycombBlock"] = "minecraft:honeycomb_block";
  MinecraftBlockTypes2["Hopper"] = "minecraft:hopper";
  MinecraftBlockTypes2["HornCoral"] = "minecraft:horn_coral";
  MinecraftBlockTypes2["HornCoralBlock"] = "minecraft:horn_coral_block";
  MinecraftBlockTypes2["HornCoralFan"] = "minecraft:horn_coral_fan";
  MinecraftBlockTypes2["HornCoralWallFan"] = "minecraft:horn_coral_wall_fan";
  MinecraftBlockTypes2["Ice"] = "minecraft:ice";
  MinecraftBlockTypes2["InfestedChiseledStoneBricks"] = "minecraft:infested_chiseled_stone_bricks";
  MinecraftBlockTypes2["InfestedCobblestone"] = "minecraft:infested_cobblestone";
  MinecraftBlockTypes2["InfestedCrackedStoneBricks"] = "minecraft:infested_cracked_stone_bricks";
  MinecraftBlockTypes2["InfestedDeepslate"] = "minecraft:infested_deepslate";
  MinecraftBlockTypes2["InfestedMossyStoneBricks"] = "minecraft:infested_mossy_stone_bricks";
  MinecraftBlockTypes2["InfestedStone"] = "minecraft:infested_stone";
  MinecraftBlockTypes2["InfestedStoneBricks"] = "minecraft:infested_stone_bricks";
  MinecraftBlockTypes2["InfoUpdate"] = "minecraft:info_update";
  MinecraftBlockTypes2["InfoUpdate2"] = "minecraft:info_update2";
  MinecraftBlockTypes2["InvisibleBedrock"] = "minecraft:invisible_bedrock";
  MinecraftBlockTypes2["IronBars"] = "minecraft:iron_bars";
  MinecraftBlockTypes2["IronBlock"] = "minecraft:iron_block";
  MinecraftBlockTypes2["IronDoor"] = "minecraft:iron_door";
  MinecraftBlockTypes2["IronOre"] = "minecraft:iron_ore";
  MinecraftBlockTypes2["IronTrapdoor"] = "minecraft:iron_trapdoor";
  MinecraftBlockTypes2["Jigsaw"] = "minecraft:jigsaw";
  MinecraftBlockTypes2["Jukebox"] = "minecraft:jukebox";
  MinecraftBlockTypes2["JungleButton"] = "minecraft:jungle_button";
  MinecraftBlockTypes2["JungleDoor"] = "minecraft:jungle_door";
  MinecraftBlockTypes2["JungleDoubleSlab"] = "minecraft:jungle_double_slab";
  MinecraftBlockTypes2["JungleFence"] = "minecraft:jungle_fence";
  MinecraftBlockTypes2["JungleFenceGate"] = "minecraft:jungle_fence_gate";
  MinecraftBlockTypes2["JungleHangingSign"] = "minecraft:jungle_hanging_sign";
  MinecraftBlockTypes2["JungleLeaves"] = "minecraft:jungle_leaves";
  MinecraftBlockTypes2["JungleLog"] = "minecraft:jungle_log";
  MinecraftBlockTypes2["JunglePlanks"] = "minecraft:jungle_planks";
  MinecraftBlockTypes2["JunglePressurePlate"] = "minecraft:jungle_pressure_plate";
  MinecraftBlockTypes2["JungleSapling"] = "minecraft:jungle_sapling";
  MinecraftBlockTypes2["JungleSlab"] = "minecraft:jungle_slab";
  MinecraftBlockTypes2["JungleStairs"] = "minecraft:jungle_stairs";
  MinecraftBlockTypes2["JungleStandingSign"] = "minecraft:jungle_standing_sign";
  MinecraftBlockTypes2["JungleTrapdoor"] = "minecraft:jungle_trapdoor";
  MinecraftBlockTypes2["JungleWallSign"] = "minecraft:jungle_wall_sign";
  MinecraftBlockTypes2["JungleWood"] = "minecraft:jungle_wood";
  MinecraftBlockTypes2["Kelp"] = "minecraft:kelp";
  MinecraftBlockTypes2["Ladder"] = "minecraft:ladder";
  MinecraftBlockTypes2["Lantern"] = "minecraft:lantern";
  MinecraftBlockTypes2["LapisBlock"] = "minecraft:lapis_block";
  MinecraftBlockTypes2["LapisOre"] = "minecraft:lapis_ore";
  MinecraftBlockTypes2["LargeAmethystBud"] = "minecraft:large_amethyst_bud";
  MinecraftBlockTypes2["LargeFern"] = "minecraft:large_fern";
  MinecraftBlockTypes2["Lava"] = "minecraft:lava";
  MinecraftBlockTypes2["Lectern"] = "minecraft:lectern";
  MinecraftBlockTypes2["Lever"] = "minecraft:lever";
  MinecraftBlockTypes2["LightBlock0"] = "minecraft:light_block_0";
  MinecraftBlockTypes2["LightBlock1"] = "minecraft:light_block_1";
  MinecraftBlockTypes2["LightBlock10"] = "minecraft:light_block_10";
  MinecraftBlockTypes2["LightBlock11"] = "minecraft:light_block_11";
  MinecraftBlockTypes2["LightBlock12"] = "minecraft:light_block_12";
  MinecraftBlockTypes2["LightBlock13"] = "minecraft:light_block_13";
  MinecraftBlockTypes2["LightBlock14"] = "minecraft:light_block_14";
  MinecraftBlockTypes2["LightBlock15"] = "minecraft:light_block_15";
  MinecraftBlockTypes2["LightBlock2"] = "minecraft:light_block_2";
  MinecraftBlockTypes2["LightBlock3"] = "minecraft:light_block_3";
  MinecraftBlockTypes2["LightBlock4"] = "minecraft:light_block_4";
  MinecraftBlockTypes2["LightBlock5"] = "minecraft:light_block_5";
  MinecraftBlockTypes2["LightBlock6"] = "minecraft:light_block_6";
  MinecraftBlockTypes2["LightBlock7"] = "minecraft:light_block_7";
  MinecraftBlockTypes2["LightBlock8"] = "minecraft:light_block_8";
  MinecraftBlockTypes2["LightBlock9"] = "minecraft:light_block_9";
  MinecraftBlockTypes2["LightBlueCandle"] = "minecraft:light_blue_candle";
  MinecraftBlockTypes2["LightBlueCandleCake"] = "minecraft:light_blue_candle_cake";
  MinecraftBlockTypes2["LightBlueCarpet"] = "minecraft:light_blue_carpet";
  MinecraftBlockTypes2["LightBlueConcrete"] = "minecraft:light_blue_concrete";
  MinecraftBlockTypes2["LightBlueConcretePowder"] = "minecraft:light_blue_concrete_powder";
  MinecraftBlockTypes2["LightBlueGlazedTerracotta"] = "minecraft:light_blue_glazed_terracotta";
  MinecraftBlockTypes2["LightBlueShulkerBox"] = "minecraft:light_blue_shulker_box";
  MinecraftBlockTypes2["LightBlueStainedGlass"] = "minecraft:light_blue_stained_glass";
  MinecraftBlockTypes2["LightBlueStainedGlassPane"] = "minecraft:light_blue_stained_glass_pane";
  MinecraftBlockTypes2["LightBlueTerracotta"] = "minecraft:light_blue_terracotta";
  MinecraftBlockTypes2["LightBlueWool"] = "minecraft:light_blue_wool";
  MinecraftBlockTypes2["LightGrayCandle"] = "minecraft:light_gray_candle";
  MinecraftBlockTypes2["LightGrayCandleCake"] = "minecraft:light_gray_candle_cake";
  MinecraftBlockTypes2["LightGrayCarpet"] = "minecraft:light_gray_carpet";
  MinecraftBlockTypes2["LightGrayConcrete"] = "minecraft:light_gray_concrete";
  MinecraftBlockTypes2["LightGrayConcretePowder"] = "minecraft:light_gray_concrete_powder";
  MinecraftBlockTypes2["LightGrayShulkerBox"] = "minecraft:light_gray_shulker_box";
  MinecraftBlockTypes2["LightGrayStainedGlass"] = "minecraft:light_gray_stained_glass";
  MinecraftBlockTypes2["LightGrayStainedGlassPane"] = "minecraft:light_gray_stained_glass_pane";
  MinecraftBlockTypes2["LightGrayTerracotta"] = "minecraft:light_gray_terracotta";
  MinecraftBlockTypes2["LightGrayWool"] = "minecraft:light_gray_wool";
  MinecraftBlockTypes2["LightWeightedPressurePlate"] = "minecraft:light_weighted_pressure_plate";
  MinecraftBlockTypes2["LightningRod"] = "minecraft:lightning_rod";
  MinecraftBlockTypes2["Lilac"] = "minecraft:lilac";
  MinecraftBlockTypes2["LilyOfTheValley"] = "minecraft:lily_of_the_valley";
  MinecraftBlockTypes2["LimeCandle"] = "minecraft:lime_candle";
  MinecraftBlockTypes2["LimeCandleCake"] = "minecraft:lime_candle_cake";
  MinecraftBlockTypes2["LimeCarpet"] = "minecraft:lime_carpet";
  MinecraftBlockTypes2["LimeConcrete"] = "minecraft:lime_concrete";
  MinecraftBlockTypes2["LimeConcretePowder"] = "minecraft:lime_concrete_powder";
  MinecraftBlockTypes2["LimeGlazedTerracotta"] = "minecraft:lime_glazed_terracotta";
  MinecraftBlockTypes2["LimeShulkerBox"] = "minecraft:lime_shulker_box";
  MinecraftBlockTypes2["LimeStainedGlass"] = "minecraft:lime_stained_glass";
  MinecraftBlockTypes2["LimeStainedGlassPane"] = "minecraft:lime_stained_glass_pane";
  MinecraftBlockTypes2["LimeTerracotta"] = "minecraft:lime_terracotta";
  MinecraftBlockTypes2["LimeWool"] = "minecraft:lime_wool";
  MinecraftBlockTypes2["LitBlastFurnace"] = "minecraft:lit_blast_furnace";
  MinecraftBlockTypes2["LitDeepslateRedstoneOre"] = "minecraft:lit_deepslate_redstone_ore";
  MinecraftBlockTypes2["LitFurnace"] = "minecraft:lit_furnace";
  MinecraftBlockTypes2["LitPumpkin"] = "minecraft:lit_pumpkin";
  MinecraftBlockTypes2["LitRedstoneLamp"] = "minecraft:lit_redstone_lamp";
  MinecraftBlockTypes2["LitRedstoneOre"] = "minecraft:lit_redstone_ore";
  MinecraftBlockTypes2["LitSmoker"] = "minecraft:lit_smoker";
  MinecraftBlockTypes2["Lodestone"] = "minecraft:lodestone";
  MinecraftBlockTypes2["Loom"] = "minecraft:loom";
  MinecraftBlockTypes2["MagentaCandle"] = "minecraft:magenta_candle";
  MinecraftBlockTypes2["MagentaCandleCake"] = "minecraft:magenta_candle_cake";
  MinecraftBlockTypes2["MagentaCarpet"] = "minecraft:magenta_carpet";
  MinecraftBlockTypes2["MagentaConcrete"] = "minecraft:magenta_concrete";
  MinecraftBlockTypes2["MagentaConcretePowder"] = "minecraft:magenta_concrete_powder";
  MinecraftBlockTypes2["MagentaGlazedTerracotta"] = "minecraft:magenta_glazed_terracotta";
  MinecraftBlockTypes2["MagentaShulkerBox"] = "minecraft:magenta_shulker_box";
  MinecraftBlockTypes2["MagentaStainedGlass"] = "minecraft:magenta_stained_glass";
  MinecraftBlockTypes2["MagentaStainedGlassPane"] = "minecraft:magenta_stained_glass_pane";
  MinecraftBlockTypes2["MagentaTerracotta"] = "minecraft:magenta_terracotta";
  MinecraftBlockTypes2["MagentaWool"] = "minecraft:magenta_wool";
  MinecraftBlockTypes2["Magma"] = "minecraft:magma";
  MinecraftBlockTypes2["MangroveButton"] = "minecraft:mangrove_button";
  MinecraftBlockTypes2["MangroveDoor"] = "minecraft:mangrove_door";
  MinecraftBlockTypes2["MangroveDoubleSlab"] = "minecraft:mangrove_double_slab";
  MinecraftBlockTypes2["MangroveFence"] = "minecraft:mangrove_fence";
  MinecraftBlockTypes2["MangroveFenceGate"] = "minecraft:mangrove_fence_gate";
  MinecraftBlockTypes2["MangroveHangingSign"] = "minecraft:mangrove_hanging_sign";
  MinecraftBlockTypes2["MangroveLeaves"] = "minecraft:mangrove_leaves";
  MinecraftBlockTypes2["MangroveLog"] = "minecraft:mangrove_log";
  MinecraftBlockTypes2["MangrovePlanks"] = "minecraft:mangrove_planks";
  MinecraftBlockTypes2["MangrovePressurePlate"] = "minecraft:mangrove_pressure_plate";
  MinecraftBlockTypes2["MangrovePropagule"] = "minecraft:mangrove_propagule";
  MinecraftBlockTypes2["MangroveRoots"] = "minecraft:mangrove_roots";
  MinecraftBlockTypes2["MangroveSlab"] = "minecraft:mangrove_slab";
  MinecraftBlockTypes2["MangroveStairs"] = "minecraft:mangrove_stairs";
  MinecraftBlockTypes2["MangroveStandingSign"] = "minecraft:mangrove_standing_sign";
  MinecraftBlockTypes2["MangroveTrapdoor"] = "minecraft:mangrove_trapdoor";
  MinecraftBlockTypes2["MangroveWallSign"] = "minecraft:mangrove_wall_sign";
  MinecraftBlockTypes2["MangroveWood"] = "minecraft:mangrove_wood";
  MinecraftBlockTypes2["MediumAmethystBud"] = "minecraft:medium_amethyst_bud";
  MinecraftBlockTypes2["MelonBlock"] = "minecraft:melon_block";
  MinecraftBlockTypes2["MelonStem"] = "minecraft:melon_stem";
  MinecraftBlockTypes2["MobSpawner"] = "minecraft:mob_spawner";
  MinecraftBlockTypes2["MossBlock"] = "minecraft:moss_block";
  MinecraftBlockTypes2["MossCarpet"] = "minecraft:moss_carpet";
  MinecraftBlockTypes2["MossyCobblestone"] = "minecraft:mossy_cobblestone";
  MinecraftBlockTypes2["MossyCobblestoneDoubleSlab"] = "minecraft:mossy_cobblestone_double_slab";
  MinecraftBlockTypes2["MossyCobblestoneSlab"] = "minecraft:mossy_cobblestone_slab";
  MinecraftBlockTypes2["MossyCobblestoneStairs"] = "minecraft:mossy_cobblestone_stairs";
  MinecraftBlockTypes2["MossyStoneBrickDoubleSlab"] = "minecraft:mossy_stone_brick_double_slab";
  MinecraftBlockTypes2["MossyStoneBrickSlab"] = "minecraft:mossy_stone_brick_slab";
  MinecraftBlockTypes2["MossyStoneBrickStairs"] = "minecraft:mossy_stone_brick_stairs";
  MinecraftBlockTypes2["MossyStoneBricks"] = "minecraft:mossy_stone_bricks";
  MinecraftBlockTypes2["MovingBlock"] = "minecraft:moving_block";
  MinecraftBlockTypes2["Mud"] = "minecraft:mud";
  MinecraftBlockTypes2["MudBrickDoubleSlab"] = "minecraft:mud_brick_double_slab";
  MinecraftBlockTypes2["MudBrickSlab"] = "minecraft:mud_brick_slab";
  MinecraftBlockTypes2["MudBrickStairs"] = "minecraft:mud_brick_stairs";
  MinecraftBlockTypes2["MudBrickWall"] = "minecraft:mud_brick_wall";
  MinecraftBlockTypes2["MudBricks"] = "minecraft:mud_bricks";
  MinecraftBlockTypes2["MuddyMangroveRoots"] = "minecraft:muddy_mangrove_roots";
  MinecraftBlockTypes2["Mycelium"] = "minecraft:mycelium";
  MinecraftBlockTypes2["NetherBrick"] = "minecraft:nether_brick";
  MinecraftBlockTypes2["NetherBrickDoubleSlab"] = "minecraft:nether_brick_double_slab";
  MinecraftBlockTypes2["NetherBrickFence"] = "minecraft:nether_brick_fence";
  MinecraftBlockTypes2["NetherBrickSlab"] = "minecraft:nether_brick_slab";
  MinecraftBlockTypes2["NetherBrickStairs"] = "minecraft:nether_brick_stairs";
  MinecraftBlockTypes2["NetherGoldOre"] = "minecraft:nether_gold_ore";
  MinecraftBlockTypes2["NetherSprouts"] = "minecraft:nether_sprouts";
  MinecraftBlockTypes2["NetherWart"] = "minecraft:nether_wart";
  MinecraftBlockTypes2["NetherWartBlock"] = "minecraft:nether_wart_block";
  MinecraftBlockTypes2["NetheriteBlock"] = "minecraft:netherite_block";
  MinecraftBlockTypes2["Netherrack"] = "minecraft:netherrack";
  MinecraftBlockTypes2["Netherreactor"] = "minecraft:netherreactor";
  MinecraftBlockTypes2["NormalStoneDoubleSlab"] = "minecraft:normal_stone_double_slab";
  MinecraftBlockTypes2["NormalStoneSlab"] = "minecraft:normal_stone_slab";
  MinecraftBlockTypes2["NormalStoneStairs"] = "minecraft:normal_stone_stairs";
  MinecraftBlockTypes2["Noteblock"] = "minecraft:noteblock";
  MinecraftBlockTypes2["OakDoubleSlab"] = "minecraft:oak_double_slab";
  MinecraftBlockTypes2["OakFence"] = "minecraft:oak_fence";
  MinecraftBlockTypes2["OakHangingSign"] = "minecraft:oak_hanging_sign";
  MinecraftBlockTypes2["OakLeaves"] = "minecraft:oak_leaves";
  MinecraftBlockTypes2["OakLog"] = "minecraft:oak_log";
  MinecraftBlockTypes2["OakPlanks"] = "minecraft:oak_planks";
  MinecraftBlockTypes2["OakSapling"] = "minecraft:oak_sapling";
  MinecraftBlockTypes2["OakSlab"] = "minecraft:oak_slab";
  MinecraftBlockTypes2["OakStairs"] = "minecraft:oak_stairs";
  MinecraftBlockTypes2["OakWood"] = "minecraft:oak_wood";
  MinecraftBlockTypes2["Observer"] = "minecraft:observer";
  MinecraftBlockTypes2["Obsidian"] = "minecraft:obsidian";
  MinecraftBlockTypes2["OchreFroglight"] = "minecraft:ochre_froglight";
  MinecraftBlockTypes2["OrangeCandle"] = "minecraft:orange_candle";
  MinecraftBlockTypes2["OrangeCandleCake"] = "minecraft:orange_candle_cake";
  MinecraftBlockTypes2["OrangeCarpet"] = "minecraft:orange_carpet";
  MinecraftBlockTypes2["OrangeConcrete"] = "minecraft:orange_concrete";
  MinecraftBlockTypes2["OrangeConcretePowder"] = "minecraft:orange_concrete_powder";
  MinecraftBlockTypes2["OrangeGlazedTerracotta"] = "minecraft:orange_glazed_terracotta";
  MinecraftBlockTypes2["OrangeShulkerBox"] = "minecraft:orange_shulker_box";
  MinecraftBlockTypes2["OrangeStainedGlass"] = "minecraft:orange_stained_glass";
  MinecraftBlockTypes2["OrangeStainedGlassPane"] = "minecraft:orange_stained_glass_pane";
  MinecraftBlockTypes2["OrangeTerracotta"] = "minecraft:orange_terracotta";
  MinecraftBlockTypes2["OrangeTulip"] = "minecraft:orange_tulip";
  MinecraftBlockTypes2["OrangeWool"] = "minecraft:orange_wool";
  MinecraftBlockTypes2["OxeyeDaisy"] = "minecraft:oxeye_daisy";
  MinecraftBlockTypes2["OxidizedChiseledCopper"] = "minecraft:oxidized_chiseled_copper";
  MinecraftBlockTypes2["OxidizedCopper"] = "minecraft:oxidized_copper";
  MinecraftBlockTypes2["OxidizedCopperBulb"] = "minecraft:oxidized_copper_bulb";
  MinecraftBlockTypes2["OxidizedCopperDoor"] = "minecraft:oxidized_copper_door";
  MinecraftBlockTypes2["OxidizedCopperGrate"] = "minecraft:oxidized_copper_grate";
  MinecraftBlockTypes2["OxidizedCopperTrapdoor"] = "minecraft:oxidized_copper_trapdoor";
  MinecraftBlockTypes2["OxidizedCutCopper"] = "minecraft:oxidized_cut_copper";
  MinecraftBlockTypes2["OxidizedCutCopperSlab"] = "minecraft:oxidized_cut_copper_slab";
  MinecraftBlockTypes2["OxidizedCutCopperStairs"] = "minecraft:oxidized_cut_copper_stairs";
  MinecraftBlockTypes2["OxidizedDoubleCutCopperSlab"] = "minecraft:oxidized_double_cut_copper_slab";
  MinecraftBlockTypes2["PackedIce"] = "minecraft:packed_ice";
  MinecraftBlockTypes2["PackedMud"] = "minecraft:packed_mud";
  MinecraftBlockTypes2["PearlescentFroglight"] = "minecraft:pearlescent_froglight";
  MinecraftBlockTypes2["Peony"] = "minecraft:peony";
  MinecraftBlockTypes2["PetrifiedOakDoubleSlab"] = "minecraft:petrified_oak_double_slab";
  MinecraftBlockTypes2["PetrifiedOakSlab"] = "minecraft:petrified_oak_slab";
  MinecraftBlockTypes2["PinkCandle"] = "minecraft:pink_candle";
  MinecraftBlockTypes2["PinkCandleCake"] = "minecraft:pink_candle_cake";
  MinecraftBlockTypes2["PinkCarpet"] = "minecraft:pink_carpet";
  MinecraftBlockTypes2["PinkConcrete"] = "minecraft:pink_concrete";
  MinecraftBlockTypes2["PinkConcretePowder"] = "minecraft:pink_concrete_powder";
  MinecraftBlockTypes2["PinkGlazedTerracotta"] = "minecraft:pink_glazed_terracotta";
  MinecraftBlockTypes2["PinkPetals"] = "minecraft:pink_petals";
  MinecraftBlockTypes2["PinkShulkerBox"] = "minecraft:pink_shulker_box";
  MinecraftBlockTypes2["PinkStainedGlass"] = "minecraft:pink_stained_glass";
  MinecraftBlockTypes2["PinkStainedGlassPane"] = "minecraft:pink_stained_glass_pane";
  MinecraftBlockTypes2["PinkTerracotta"] = "minecraft:pink_terracotta";
  MinecraftBlockTypes2["PinkTulip"] = "minecraft:pink_tulip";
  MinecraftBlockTypes2["PinkWool"] = "minecraft:pink_wool";
  MinecraftBlockTypes2["Piston"] = "minecraft:piston";
  MinecraftBlockTypes2["PistonArmCollision"] = "minecraft:piston_arm_collision";
  MinecraftBlockTypes2["PitcherCrop"] = "minecraft:pitcher_crop";
  MinecraftBlockTypes2["PitcherPlant"] = "minecraft:pitcher_plant";
  MinecraftBlockTypes2["Podzol"] = "minecraft:podzol";
  MinecraftBlockTypes2["PointedDripstone"] = "minecraft:pointed_dripstone";
  MinecraftBlockTypes2["PolishedAndesite"] = "minecraft:polished_andesite";
  MinecraftBlockTypes2["PolishedAndesiteDoubleSlab"] = "minecraft:polished_andesite_double_slab";
  MinecraftBlockTypes2["PolishedAndesiteSlab"] = "minecraft:polished_andesite_slab";
  MinecraftBlockTypes2["PolishedAndesiteStairs"] = "minecraft:polished_andesite_stairs";
  MinecraftBlockTypes2["PolishedBasalt"] = "minecraft:polished_basalt";
  MinecraftBlockTypes2["PolishedBlackstone"] = "minecraft:polished_blackstone";
  MinecraftBlockTypes2["PolishedBlackstoneBrickDoubleSlab"] = "minecraft:polished_blackstone_brick_double_slab";
  MinecraftBlockTypes2["PolishedBlackstoneBrickSlab"] = "minecraft:polished_blackstone_brick_slab";
  MinecraftBlockTypes2["PolishedBlackstoneBrickStairs"] = "minecraft:polished_blackstone_brick_stairs";
  MinecraftBlockTypes2["PolishedBlackstoneBrickWall"] = "minecraft:polished_blackstone_brick_wall";
  MinecraftBlockTypes2["PolishedBlackstoneBricks"] = "minecraft:polished_blackstone_bricks";
  MinecraftBlockTypes2["PolishedBlackstoneButton"] = "minecraft:polished_blackstone_button";
  MinecraftBlockTypes2["PolishedBlackstoneDoubleSlab"] = "minecraft:polished_blackstone_double_slab";
  MinecraftBlockTypes2["PolishedBlackstonePressurePlate"] = "minecraft:polished_blackstone_pressure_plate";
  MinecraftBlockTypes2["PolishedBlackstoneSlab"] = "minecraft:polished_blackstone_slab";
  MinecraftBlockTypes2["PolishedBlackstoneStairs"] = "minecraft:polished_blackstone_stairs";
  MinecraftBlockTypes2["PolishedBlackstoneWall"] = "minecraft:polished_blackstone_wall";
  MinecraftBlockTypes2["PolishedDeepslate"] = "minecraft:polished_deepslate";
  MinecraftBlockTypes2["PolishedDeepslateDoubleSlab"] = "minecraft:polished_deepslate_double_slab";
  MinecraftBlockTypes2["PolishedDeepslateSlab"] = "minecraft:polished_deepslate_slab";
  MinecraftBlockTypes2["PolishedDeepslateStairs"] = "minecraft:polished_deepslate_stairs";
  MinecraftBlockTypes2["PolishedDeepslateWall"] = "minecraft:polished_deepslate_wall";
  MinecraftBlockTypes2["PolishedDiorite"] = "minecraft:polished_diorite";
  MinecraftBlockTypes2["PolishedDioriteDoubleSlab"] = "minecraft:polished_diorite_double_slab";
  MinecraftBlockTypes2["PolishedDioriteSlab"] = "minecraft:polished_diorite_slab";
  MinecraftBlockTypes2["PolishedDioriteStairs"] = "minecraft:polished_diorite_stairs";
  MinecraftBlockTypes2["PolishedGranite"] = "minecraft:polished_granite";
  MinecraftBlockTypes2["PolishedGraniteDoubleSlab"] = "minecraft:polished_granite_double_slab";
  MinecraftBlockTypes2["PolishedGraniteSlab"] = "minecraft:polished_granite_slab";
  MinecraftBlockTypes2["PolishedGraniteStairs"] = "minecraft:polished_granite_stairs";
  MinecraftBlockTypes2["PolishedTuff"] = "minecraft:polished_tuff";
  MinecraftBlockTypes2["PolishedTuffDoubleSlab"] = "minecraft:polished_tuff_double_slab";
  MinecraftBlockTypes2["PolishedTuffSlab"] = "minecraft:polished_tuff_slab";
  MinecraftBlockTypes2["PolishedTuffStairs"] = "minecraft:polished_tuff_stairs";
  MinecraftBlockTypes2["PolishedTuffWall"] = "minecraft:polished_tuff_wall";
  MinecraftBlockTypes2["Poppy"] = "minecraft:poppy";
  MinecraftBlockTypes2["Portal"] = "minecraft:portal";
  MinecraftBlockTypes2["Potatoes"] = "minecraft:potatoes";
  MinecraftBlockTypes2["PowderSnow"] = "minecraft:powder_snow";
  MinecraftBlockTypes2["PoweredComparator"] = "minecraft:powered_comparator";
  MinecraftBlockTypes2["PoweredRepeater"] = "minecraft:powered_repeater";
  MinecraftBlockTypes2["Prismarine"] = "minecraft:prismarine";
  MinecraftBlockTypes2["PrismarineBrickDoubleSlab"] = "minecraft:prismarine_brick_double_slab";
  MinecraftBlockTypes2["PrismarineBrickSlab"] = "minecraft:prismarine_brick_slab";
  MinecraftBlockTypes2["PrismarineBricks"] = "minecraft:prismarine_bricks";
  MinecraftBlockTypes2["PrismarineBricksStairs"] = "minecraft:prismarine_bricks_stairs";
  MinecraftBlockTypes2["PrismarineDoubleSlab"] = "minecraft:prismarine_double_slab";
  MinecraftBlockTypes2["PrismarineSlab"] = "minecraft:prismarine_slab";
  MinecraftBlockTypes2["PrismarineStairs"] = "minecraft:prismarine_stairs";
  MinecraftBlockTypes2["Pumpkin"] = "minecraft:pumpkin";
  MinecraftBlockTypes2["PumpkinStem"] = "minecraft:pumpkin_stem";
  MinecraftBlockTypes2["PurpleCandle"] = "minecraft:purple_candle";
  MinecraftBlockTypes2["PurpleCandleCake"] = "minecraft:purple_candle_cake";
  MinecraftBlockTypes2["PurpleCarpet"] = "minecraft:purple_carpet";
  MinecraftBlockTypes2["PurpleConcrete"] = "minecraft:purple_concrete";
  MinecraftBlockTypes2["PurpleConcretePowder"] = "minecraft:purple_concrete_powder";
  MinecraftBlockTypes2["PurpleGlazedTerracotta"] = "minecraft:purple_glazed_terracotta";
  MinecraftBlockTypes2["PurpleShulkerBox"] = "minecraft:purple_shulker_box";
  MinecraftBlockTypes2["PurpleStainedGlass"] = "minecraft:purple_stained_glass";
  MinecraftBlockTypes2["PurpleStainedGlassPane"] = "minecraft:purple_stained_glass_pane";
  MinecraftBlockTypes2["PurpleTerracotta"] = "minecraft:purple_terracotta";
  MinecraftBlockTypes2["PurpleWool"] = "minecraft:purple_wool";
  MinecraftBlockTypes2["PurpurBlock"] = "minecraft:purpur_block";
  MinecraftBlockTypes2["PurpurDoubleSlab"] = "minecraft:purpur_double_slab";
  MinecraftBlockTypes2["PurpurSlab"] = "minecraft:purpur_slab";
  MinecraftBlockTypes2["PurpurStairs"] = "minecraft:purpur_stairs";
  MinecraftBlockTypes2["QuartzBlock"] = "minecraft:quartz_block";
  MinecraftBlockTypes2["QuartzBricks"] = "minecraft:quartz_bricks";
  MinecraftBlockTypes2["QuartzDoubleSlab"] = "minecraft:quartz_double_slab";
  MinecraftBlockTypes2["QuartzOre"] = "minecraft:quartz_ore";
  MinecraftBlockTypes2["QuartzPillar"] = "minecraft:quartz_pillar";
  MinecraftBlockTypes2["QuartzSlab"] = "minecraft:quartz_slab";
  MinecraftBlockTypes2["QuartzStairs"] = "minecraft:quartz_stairs";
  MinecraftBlockTypes2["Rail"] = "minecraft:rail";
  MinecraftBlockTypes2["RawCopperBlock"] = "minecraft:raw_copper_block";
  MinecraftBlockTypes2["RawGoldBlock"] = "minecraft:raw_gold_block";
  MinecraftBlockTypes2["RawIronBlock"] = "minecraft:raw_iron_block";
  MinecraftBlockTypes2["RedCandle"] = "minecraft:red_candle";
  MinecraftBlockTypes2["RedCandleCake"] = "minecraft:red_candle_cake";
  MinecraftBlockTypes2["RedCarpet"] = "minecraft:red_carpet";
  MinecraftBlockTypes2["RedConcrete"] = "minecraft:red_concrete";
  MinecraftBlockTypes2["RedConcretePowder"] = "minecraft:red_concrete_powder";
  MinecraftBlockTypes2["RedGlazedTerracotta"] = "minecraft:red_glazed_terracotta";
  MinecraftBlockTypes2["RedMushroom"] = "minecraft:red_mushroom";
  MinecraftBlockTypes2["RedMushroomBlock"] = "minecraft:red_mushroom_block";
  MinecraftBlockTypes2["RedNetherBrick"] = "minecraft:red_nether_brick";
  MinecraftBlockTypes2["RedNetherBrickDoubleSlab"] = "minecraft:red_nether_brick_double_slab";
  MinecraftBlockTypes2["RedNetherBrickSlab"] = "minecraft:red_nether_brick_slab";
  MinecraftBlockTypes2["RedNetherBrickStairs"] = "minecraft:red_nether_brick_stairs";
  MinecraftBlockTypes2["RedSand"] = "minecraft:red_sand";
  MinecraftBlockTypes2["RedSandstone"] = "minecraft:red_sandstone";
  MinecraftBlockTypes2["RedSandstoneDoubleSlab"] = "minecraft:red_sandstone_double_slab";
  MinecraftBlockTypes2["RedSandstoneSlab"] = "minecraft:red_sandstone_slab";
  MinecraftBlockTypes2["RedSandstoneStairs"] = "minecraft:red_sandstone_stairs";
  MinecraftBlockTypes2["RedShulkerBox"] = "minecraft:red_shulker_box";
  MinecraftBlockTypes2["RedStainedGlass"] = "minecraft:red_stained_glass";
  MinecraftBlockTypes2["RedStainedGlassPane"] = "minecraft:red_stained_glass_pane";
  MinecraftBlockTypes2["RedTerracotta"] = "minecraft:red_terracotta";
  MinecraftBlockTypes2["RedTulip"] = "minecraft:red_tulip";
  MinecraftBlockTypes2["RedWool"] = "minecraft:red_wool";
  MinecraftBlockTypes2["RedstoneBlock"] = "minecraft:redstone_block";
  MinecraftBlockTypes2["RedstoneLamp"] = "minecraft:redstone_lamp";
  MinecraftBlockTypes2["RedstoneOre"] = "minecraft:redstone_ore";
  MinecraftBlockTypes2["RedstoneTorch"] = "minecraft:redstone_torch";
  MinecraftBlockTypes2["RedstoneWire"] = "minecraft:redstone_wire";
  MinecraftBlockTypes2["Reeds"] = "minecraft:reeds";
  MinecraftBlockTypes2["ReinforcedDeepslate"] = "minecraft:reinforced_deepslate";
  MinecraftBlockTypes2["RepeatingCommandBlock"] = "minecraft:repeating_command_block";
  MinecraftBlockTypes2["Reserved6"] = "minecraft:reserved6";
  MinecraftBlockTypes2["RespawnAnchor"] = "minecraft:respawn_anchor";
  MinecraftBlockTypes2["RoseBush"] = "minecraft:rose_bush";
  MinecraftBlockTypes2["Sand"] = "minecraft:sand";
  MinecraftBlockTypes2["Sandstone"] = "minecraft:sandstone";
  MinecraftBlockTypes2["SandstoneDoubleSlab"] = "minecraft:sandstone_double_slab";
  MinecraftBlockTypes2["SandstoneSlab"] = "minecraft:sandstone_slab";
  MinecraftBlockTypes2["SandstoneStairs"] = "minecraft:sandstone_stairs";
  MinecraftBlockTypes2["Scaffolding"] = "minecraft:scaffolding";
  MinecraftBlockTypes2["Sculk"] = "minecraft:sculk";
  MinecraftBlockTypes2["SculkCatalyst"] = "minecraft:sculk_catalyst";
  MinecraftBlockTypes2["SculkSensor"] = "minecraft:sculk_sensor";
  MinecraftBlockTypes2["SculkShrieker"] = "minecraft:sculk_shrieker";
  MinecraftBlockTypes2["SculkVein"] = "minecraft:sculk_vein";
  MinecraftBlockTypes2["SeaLantern"] = "minecraft:sea_lantern";
  MinecraftBlockTypes2["SeaPickle"] = "minecraft:sea_pickle";
  MinecraftBlockTypes2["Seagrass"] = "minecraft:seagrass";
  MinecraftBlockTypes2["ShortGrass"] = "minecraft:short_grass";
  MinecraftBlockTypes2["Shroomlight"] = "minecraft:shroomlight";
  MinecraftBlockTypes2["SilverGlazedTerracotta"] = "minecraft:silver_glazed_terracotta";
  MinecraftBlockTypes2["Skull"] = "minecraft:skull";
  MinecraftBlockTypes2["Slime"] = "minecraft:slime";
  MinecraftBlockTypes2["SmallAmethystBud"] = "minecraft:small_amethyst_bud";
  MinecraftBlockTypes2["SmallDripleafBlock"] = "minecraft:small_dripleaf_block";
  MinecraftBlockTypes2["SmithingTable"] = "minecraft:smithing_table";
  MinecraftBlockTypes2["Smoker"] = "minecraft:smoker";
  MinecraftBlockTypes2["SmoothBasalt"] = "minecraft:smooth_basalt";
  MinecraftBlockTypes2["SmoothQuartz"] = "minecraft:smooth_quartz";
  MinecraftBlockTypes2["SmoothQuartzDoubleSlab"] = "minecraft:smooth_quartz_double_slab";
  MinecraftBlockTypes2["SmoothQuartzSlab"] = "minecraft:smooth_quartz_slab";
  MinecraftBlockTypes2["SmoothQuartzStairs"] = "minecraft:smooth_quartz_stairs";
  MinecraftBlockTypes2["SmoothRedSandstone"] = "minecraft:smooth_red_sandstone";
  MinecraftBlockTypes2["SmoothRedSandstoneDoubleSlab"] = "minecraft:smooth_red_sandstone_double_slab";
  MinecraftBlockTypes2["SmoothRedSandstoneSlab"] = "minecraft:smooth_red_sandstone_slab";
  MinecraftBlockTypes2["SmoothRedSandstoneStairs"] = "minecraft:smooth_red_sandstone_stairs";
  MinecraftBlockTypes2["SmoothSandstone"] = "minecraft:smooth_sandstone";
  MinecraftBlockTypes2["SmoothSandstoneDoubleSlab"] = "minecraft:smooth_sandstone_double_slab";
  MinecraftBlockTypes2["SmoothSandstoneSlab"] = "minecraft:smooth_sandstone_slab";
  MinecraftBlockTypes2["SmoothSandstoneStairs"] = "minecraft:smooth_sandstone_stairs";
  MinecraftBlockTypes2["SmoothStone"] = "minecraft:smooth_stone";
  MinecraftBlockTypes2["SmoothStoneDoubleSlab"] = "minecraft:smooth_stone_double_slab";
  MinecraftBlockTypes2["SmoothStoneSlab"] = "minecraft:smooth_stone_slab";
  MinecraftBlockTypes2["SnifferEgg"] = "minecraft:sniffer_egg";
  MinecraftBlockTypes2["Snow"] = "minecraft:snow";
  MinecraftBlockTypes2["SnowLayer"] = "minecraft:snow_layer";
  MinecraftBlockTypes2["SoulCampfire"] = "minecraft:soul_campfire";
  MinecraftBlockTypes2["SoulFire"] = "minecraft:soul_fire";
  MinecraftBlockTypes2["SoulLantern"] = "minecraft:soul_lantern";
  MinecraftBlockTypes2["SoulSand"] = "minecraft:soul_sand";
  MinecraftBlockTypes2["SoulSoil"] = "minecraft:soul_soil";
  MinecraftBlockTypes2["SoulTorch"] = "minecraft:soul_torch";
  MinecraftBlockTypes2["Sponge"] = "minecraft:sponge";
  MinecraftBlockTypes2["SporeBlossom"] = "minecraft:spore_blossom";
  MinecraftBlockTypes2["SpruceButton"] = "minecraft:spruce_button";
  MinecraftBlockTypes2["SpruceDoor"] = "minecraft:spruce_door";
  MinecraftBlockTypes2["SpruceDoubleSlab"] = "minecraft:spruce_double_slab";
  MinecraftBlockTypes2["SpruceFence"] = "minecraft:spruce_fence";
  MinecraftBlockTypes2["SpruceFenceGate"] = "minecraft:spruce_fence_gate";
  MinecraftBlockTypes2["SpruceHangingSign"] = "minecraft:spruce_hanging_sign";
  MinecraftBlockTypes2["SpruceLeaves"] = "minecraft:spruce_leaves";
  MinecraftBlockTypes2["SpruceLog"] = "minecraft:spruce_log";
  MinecraftBlockTypes2["SprucePlanks"] = "minecraft:spruce_planks";
  MinecraftBlockTypes2["SprucePressurePlate"] = "minecraft:spruce_pressure_plate";
  MinecraftBlockTypes2["SpruceSapling"] = "minecraft:spruce_sapling";
  MinecraftBlockTypes2["SpruceSlab"] = "minecraft:spruce_slab";
  MinecraftBlockTypes2["SpruceStairs"] = "minecraft:spruce_stairs";
  MinecraftBlockTypes2["SpruceStandingSign"] = "minecraft:spruce_standing_sign";
  MinecraftBlockTypes2["SpruceTrapdoor"] = "minecraft:spruce_trapdoor";
  MinecraftBlockTypes2["SpruceWallSign"] = "minecraft:spruce_wall_sign";
  MinecraftBlockTypes2["SpruceWood"] = "minecraft:spruce_wood";
  MinecraftBlockTypes2["StandingBanner"] = "minecraft:standing_banner";
  MinecraftBlockTypes2["StandingSign"] = "minecraft:standing_sign";
  MinecraftBlockTypes2["StickyPiston"] = "minecraft:sticky_piston";
  MinecraftBlockTypes2["StickyPistonArmCollision"] = "minecraft:sticky_piston_arm_collision";
  MinecraftBlockTypes2["Stone"] = "minecraft:stone";
  MinecraftBlockTypes2["StoneBrickDoubleSlab"] = "minecraft:stone_brick_double_slab";
  MinecraftBlockTypes2["StoneBrickSlab"] = "minecraft:stone_brick_slab";
  MinecraftBlockTypes2["StoneBrickStairs"] = "minecraft:stone_brick_stairs";
  MinecraftBlockTypes2["StoneBricks"] = "minecraft:stone_bricks";
  MinecraftBlockTypes2["StoneButton"] = "minecraft:stone_button";
  MinecraftBlockTypes2["StonePressurePlate"] = "minecraft:stone_pressure_plate";
  MinecraftBlockTypes2["StoneStairs"] = "minecraft:stone_stairs";
  MinecraftBlockTypes2["Stonecutter"] = "minecraft:stonecutter";
  MinecraftBlockTypes2["StonecutterBlock"] = "minecraft:stonecutter_block";
  MinecraftBlockTypes2["StrippedAcaciaLog"] = "minecraft:stripped_acacia_log";
  MinecraftBlockTypes2["StrippedAcaciaWood"] = "minecraft:stripped_acacia_wood";
  MinecraftBlockTypes2["StrippedBambooBlock"] = "minecraft:stripped_bamboo_block";
  MinecraftBlockTypes2["StrippedBirchLog"] = "minecraft:stripped_birch_log";
  MinecraftBlockTypes2["StrippedBirchWood"] = "minecraft:stripped_birch_wood";
  MinecraftBlockTypes2["StrippedCherryLog"] = "minecraft:stripped_cherry_log";
  MinecraftBlockTypes2["StrippedCherryWood"] = "minecraft:stripped_cherry_wood";
  MinecraftBlockTypes2["StrippedCrimsonHyphae"] = "minecraft:stripped_crimson_hyphae";
  MinecraftBlockTypes2["StrippedCrimsonStem"] = "minecraft:stripped_crimson_stem";
  MinecraftBlockTypes2["StrippedDarkOakLog"] = "minecraft:stripped_dark_oak_log";
  MinecraftBlockTypes2["StrippedDarkOakWood"] = "minecraft:stripped_dark_oak_wood";
  MinecraftBlockTypes2["StrippedJungleLog"] = "minecraft:stripped_jungle_log";
  MinecraftBlockTypes2["StrippedJungleWood"] = "minecraft:stripped_jungle_wood";
  MinecraftBlockTypes2["StrippedMangroveLog"] = "minecraft:stripped_mangrove_log";
  MinecraftBlockTypes2["StrippedMangroveWood"] = "minecraft:stripped_mangrove_wood";
  MinecraftBlockTypes2["StrippedOakLog"] = "minecraft:stripped_oak_log";
  MinecraftBlockTypes2["StrippedOakWood"] = "minecraft:stripped_oak_wood";
  MinecraftBlockTypes2["StrippedSpruceLog"] = "minecraft:stripped_spruce_log";
  MinecraftBlockTypes2["StrippedSpruceWood"] = "minecraft:stripped_spruce_wood";
  MinecraftBlockTypes2["StrippedWarpedHyphae"] = "minecraft:stripped_warped_hyphae";
  MinecraftBlockTypes2["StrippedWarpedStem"] = "minecraft:stripped_warped_stem";
  MinecraftBlockTypes2["StructureBlock"] = "minecraft:structure_block";
  MinecraftBlockTypes2["StructureVoid"] = "minecraft:structure_void";
  MinecraftBlockTypes2["Sunflower"] = "minecraft:sunflower";
  MinecraftBlockTypes2["SuspiciousGravel"] = "minecraft:suspicious_gravel";
  MinecraftBlockTypes2["SuspiciousSand"] = "minecraft:suspicious_sand";
  MinecraftBlockTypes2["SweetBerryBush"] = "minecraft:sweet_berry_bush";
  MinecraftBlockTypes2["TallGrass"] = "minecraft:tall_grass";
  MinecraftBlockTypes2["Target"] = "minecraft:target";
  MinecraftBlockTypes2["TintedGlass"] = "minecraft:tinted_glass";
  MinecraftBlockTypes2["Tnt"] = "minecraft:tnt";
  MinecraftBlockTypes2["Torch"] = "minecraft:torch";
  MinecraftBlockTypes2["Torchflower"] = "minecraft:torchflower";
  MinecraftBlockTypes2["TorchflowerCrop"] = "minecraft:torchflower_crop";
  MinecraftBlockTypes2["Trapdoor"] = "minecraft:trapdoor";
  MinecraftBlockTypes2["TrappedChest"] = "minecraft:trapped_chest";
  MinecraftBlockTypes2["TrialSpawner"] = "minecraft:trial_spawner";
  MinecraftBlockTypes2["TripWire"] = "minecraft:trip_wire";
  MinecraftBlockTypes2["TripwireHook"] = "minecraft:tripwire_hook";
  MinecraftBlockTypes2["TubeCoral"] = "minecraft:tube_coral";
  MinecraftBlockTypes2["TubeCoralBlock"] = "minecraft:tube_coral_block";
  MinecraftBlockTypes2["TubeCoralFan"] = "minecraft:tube_coral_fan";
  MinecraftBlockTypes2["TubeCoralWallFan"] = "minecraft:tube_coral_wall_fan";
  MinecraftBlockTypes2["Tuff"] = "minecraft:tuff";
  MinecraftBlockTypes2["TuffBrickDoubleSlab"] = "minecraft:tuff_brick_double_slab";
  MinecraftBlockTypes2["TuffBrickSlab"] = "minecraft:tuff_brick_slab";
  MinecraftBlockTypes2["TuffBrickStairs"] = "minecraft:tuff_brick_stairs";
  MinecraftBlockTypes2["TuffBrickWall"] = "minecraft:tuff_brick_wall";
  MinecraftBlockTypes2["TuffBricks"] = "minecraft:tuff_bricks";
  MinecraftBlockTypes2["TuffDoubleSlab"] = "minecraft:tuff_double_slab";
  MinecraftBlockTypes2["TuffSlab"] = "minecraft:tuff_slab";
  MinecraftBlockTypes2["TuffStairs"] = "minecraft:tuff_stairs";
  MinecraftBlockTypes2["TuffWall"] = "minecraft:tuff_wall";
  MinecraftBlockTypes2["TurtleEgg"] = "minecraft:turtle_egg";
  MinecraftBlockTypes2["TwistingVines"] = "minecraft:twisting_vines";
  MinecraftBlockTypes2["UnderwaterTorch"] = "minecraft:underwater_torch";
  MinecraftBlockTypes2["UndyedShulkerBox"] = "minecraft:undyed_shulker_box";
  MinecraftBlockTypes2["Unknown"] = "minecraft:unknown";
  MinecraftBlockTypes2["UnlitRedstoneTorch"] = "minecraft:unlit_redstone_torch";
  MinecraftBlockTypes2["UnpoweredComparator"] = "minecraft:unpowered_comparator";
  MinecraftBlockTypes2["UnpoweredRepeater"] = "minecraft:unpowered_repeater";
  MinecraftBlockTypes2["Vault"] = "minecraft:vault";
  MinecraftBlockTypes2["VerdantFroglight"] = "minecraft:verdant_froglight";
  MinecraftBlockTypes2["Vine"] = "minecraft:vine";
  MinecraftBlockTypes2["WallBanner"] = "minecraft:wall_banner";
  MinecraftBlockTypes2["WallSign"] = "minecraft:wall_sign";
  MinecraftBlockTypes2["WarpedButton"] = "minecraft:warped_button";
  MinecraftBlockTypes2["WarpedDoor"] = "minecraft:warped_door";
  MinecraftBlockTypes2["WarpedDoubleSlab"] = "minecraft:warped_double_slab";
  MinecraftBlockTypes2["WarpedFence"] = "minecraft:warped_fence";
  MinecraftBlockTypes2["WarpedFenceGate"] = "minecraft:warped_fence_gate";
  MinecraftBlockTypes2["WarpedFungus"] = "minecraft:warped_fungus";
  MinecraftBlockTypes2["WarpedHangingSign"] = "minecraft:warped_hanging_sign";
  MinecraftBlockTypes2["WarpedHyphae"] = "minecraft:warped_hyphae";
  MinecraftBlockTypes2["WarpedNylium"] = "minecraft:warped_nylium";
  MinecraftBlockTypes2["WarpedPlanks"] = "minecraft:warped_planks";
  MinecraftBlockTypes2["WarpedPressurePlate"] = "minecraft:warped_pressure_plate";
  MinecraftBlockTypes2["WarpedRoots"] = "minecraft:warped_roots";
  MinecraftBlockTypes2["WarpedSlab"] = "minecraft:warped_slab";
  MinecraftBlockTypes2["WarpedStairs"] = "minecraft:warped_stairs";
  MinecraftBlockTypes2["WarpedStandingSign"] = "minecraft:warped_standing_sign";
  MinecraftBlockTypes2["WarpedStem"] = "minecraft:warped_stem";
  MinecraftBlockTypes2["WarpedTrapdoor"] = "minecraft:warped_trapdoor";
  MinecraftBlockTypes2["WarpedWallSign"] = "minecraft:warped_wall_sign";
  MinecraftBlockTypes2["WarpedWartBlock"] = "minecraft:warped_wart_block";
  MinecraftBlockTypes2["Water"] = "minecraft:water";
  MinecraftBlockTypes2["Waterlily"] = "minecraft:waterlily";
  MinecraftBlockTypes2["WaxedChiseledCopper"] = "minecraft:waxed_chiseled_copper";
  MinecraftBlockTypes2["WaxedCopper"] = "minecraft:waxed_copper";
  MinecraftBlockTypes2["WaxedCopperBulb"] = "minecraft:waxed_copper_bulb";
  MinecraftBlockTypes2["WaxedCopperDoor"] = "minecraft:waxed_copper_door";
  MinecraftBlockTypes2["WaxedCopperGrate"] = "minecraft:waxed_copper_grate";
  MinecraftBlockTypes2["WaxedCopperTrapdoor"] = "minecraft:waxed_copper_trapdoor";
  MinecraftBlockTypes2["WaxedCutCopper"] = "minecraft:waxed_cut_copper";
  MinecraftBlockTypes2["WaxedCutCopperSlab"] = "minecraft:waxed_cut_copper_slab";
  MinecraftBlockTypes2["WaxedCutCopperStairs"] = "minecraft:waxed_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedDoubleCutCopperSlab"] = "minecraft:waxed_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedExposedChiseledCopper"] = "minecraft:waxed_exposed_chiseled_copper";
  MinecraftBlockTypes2["WaxedExposedCopper"] = "minecraft:waxed_exposed_copper";
  MinecraftBlockTypes2["WaxedExposedCopperBulb"] = "minecraft:waxed_exposed_copper_bulb";
  MinecraftBlockTypes2["WaxedExposedCopperDoor"] = "minecraft:waxed_exposed_copper_door";
  MinecraftBlockTypes2["WaxedExposedCopperGrate"] = "minecraft:waxed_exposed_copper_grate";
  MinecraftBlockTypes2["WaxedExposedCopperTrapdoor"] = "minecraft:waxed_exposed_copper_trapdoor";
  MinecraftBlockTypes2["WaxedExposedCutCopper"] = "minecraft:waxed_exposed_cut_copper";
  MinecraftBlockTypes2["WaxedExposedCutCopperSlab"] = "minecraft:waxed_exposed_cut_copper_slab";
  MinecraftBlockTypes2["WaxedExposedCutCopperStairs"] = "minecraft:waxed_exposed_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedExposedDoubleCutCopperSlab"] = "minecraft:waxed_exposed_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedOxidizedChiseledCopper"] = "minecraft:waxed_oxidized_chiseled_copper";
  MinecraftBlockTypes2["WaxedOxidizedCopper"] = "minecraft:waxed_oxidized_copper";
  MinecraftBlockTypes2["WaxedOxidizedCopperBulb"] = "minecraft:waxed_oxidized_copper_bulb";
  MinecraftBlockTypes2["WaxedOxidizedCopperDoor"] = "minecraft:waxed_oxidized_copper_door";
  MinecraftBlockTypes2["WaxedOxidizedCopperGrate"] = "minecraft:waxed_oxidized_copper_grate";
  MinecraftBlockTypes2["WaxedOxidizedCopperTrapdoor"] = "minecraft:waxed_oxidized_copper_trapdoor";
  MinecraftBlockTypes2["WaxedOxidizedCutCopper"] = "minecraft:waxed_oxidized_cut_copper";
  MinecraftBlockTypes2["WaxedOxidizedCutCopperSlab"] = "minecraft:waxed_oxidized_cut_copper_slab";
  MinecraftBlockTypes2["WaxedOxidizedCutCopperStairs"] = "minecraft:waxed_oxidized_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedOxidizedDoubleCutCopperSlab"] = "minecraft:waxed_oxidized_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedWeatheredChiseledCopper"] = "minecraft:waxed_weathered_chiseled_copper";
  MinecraftBlockTypes2["WaxedWeatheredCopper"] = "minecraft:waxed_weathered_copper";
  MinecraftBlockTypes2["WaxedWeatheredCopperBulb"] = "minecraft:waxed_weathered_copper_bulb";
  MinecraftBlockTypes2["WaxedWeatheredCopperDoor"] = "minecraft:waxed_weathered_copper_door";
  MinecraftBlockTypes2["WaxedWeatheredCopperGrate"] = "minecraft:waxed_weathered_copper_grate";
  MinecraftBlockTypes2["WaxedWeatheredCopperTrapdoor"] = "minecraft:waxed_weathered_copper_trapdoor";
  MinecraftBlockTypes2["WaxedWeatheredCutCopper"] = "minecraft:waxed_weathered_cut_copper";
  MinecraftBlockTypes2["WaxedWeatheredCutCopperSlab"] = "minecraft:waxed_weathered_cut_copper_slab";
  MinecraftBlockTypes2["WaxedWeatheredCutCopperStairs"] = "minecraft:waxed_weathered_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedWeatheredDoubleCutCopperSlab"] = "minecraft:waxed_weathered_double_cut_copper_slab";
  MinecraftBlockTypes2["WeatheredChiseledCopper"] = "minecraft:weathered_chiseled_copper";
  MinecraftBlockTypes2["WeatheredCopper"] = "minecraft:weathered_copper";
  MinecraftBlockTypes2["WeatheredCopperBulb"] = "minecraft:weathered_copper_bulb";
  MinecraftBlockTypes2["WeatheredCopperDoor"] = "minecraft:weathered_copper_door";
  MinecraftBlockTypes2["WeatheredCopperGrate"] = "minecraft:weathered_copper_grate";
  MinecraftBlockTypes2["WeatheredCopperTrapdoor"] = "minecraft:weathered_copper_trapdoor";
  MinecraftBlockTypes2["WeatheredCutCopper"] = "minecraft:weathered_cut_copper";
  MinecraftBlockTypes2["WeatheredCutCopperSlab"] = "minecraft:weathered_cut_copper_slab";
  MinecraftBlockTypes2["WeatheredCutCopperStairs"] = "minecraft:weathered_cut_copper_stairs";
  MinecraftBlockTypes2["WeatheredDoubleCutCopperSlab"] = "minecraft:weathered_double_cut_copper_slab";
  MinecraftBlockTypes2["Web"] = "minecraft:web";
  MinecraftBlockTypes2["WeepingVines"] = "minecraft:weeping_vines";
  MinecraftBlockTypes2["Wheat"] = "minecraft:wheat";
  MinecraftBlockTypes2["WhiteCandle"] = "minecraft:white_candle";
  MinecraftBlockTypes2["WhiteCandleCake"] = "minecraft:white_candle_cake";
  MinecraftBlockTypes2["WhiteCarpet"] = "minecraft:white_carpet";
  MinecraftBlockTypes2["WhiteConcrete"] = "minecraft:white_concrete";
  MinecraftBlockTypes2["WhiteConcretePowder"] = "minecraft:white_concrete_powder";
  MinecraftBlockTypes2["WhiteGlazedTerracotta"] = "minecraft:white_glazed_terracotta";
  MinecraftBlockTypes2["WhiteShulkerBox"] = "minecraft:white_shulker_box";
  MinecraftBlockTypes2["WhiteStainedGlass"] = "minecraft:white_stained_glass";
  MinecraftBlockTypes2["WhiteStainedGlassPane"] = "minecraft:white_stained_glass_pane";
  MinecraftBlockTypes2["WhiteTerracotta"] = "minecraft:white_terracotta";
  MinecraftBlockTypes2["WhiteTulip"] = "minecraft:white_tulip";
  MinecraftBlockTypes2["WhiteWool"] = "minecraft:white_wool";
  MinecraftBlockTypes2["WitherRose"] = "minecraft:wither_rose";
  MinecraftBlockTypes2["WoodenButton"] = "minecraft:wooden_button";
  MinecraftBlockTypes2["WoodenDoor"] = "minecraft:wooden_door";
  MinecraftBlockTypes2["WoodenPressurePlate"] = "minecraft:wooden_pressure_plate";
  MinecraftBlockTypes2["YellowCandle"] = "minecraft:yellow_candle";
  MinecraftBlockTypes2["YellowCandleCake"] = "minecraft:yellow_candle_cake";
  MinecraftBlockTypes2["YellowCarpet"] = "minecraft:yellow_carpet";
  MinecraftBlockTypes2["YellowConcrete"] = "minecraft:yellow_concrete";
  MinecraftBlockTypes2["YellowConcretePowder"] = "minecraft:yellow_concrete_powder";
  MinecraftBlockTypes2["YellowGlazedTerracotta"] = "minecraft:yellow_glazed_terracotta";
  MinecraftBlockTypes2["YellowShulkerBox"] = "minecraft:yellow_shulker_box";
  MinecraftBlockTypes2["YellowStainedGlass"] = "minecraft:yellow_stained_glass";
  MinecraftBlockTypes2["YellowStainedGlassPane"] = "minecraft:yellow_stained_glass_pane";
  MinecraftBlockTypes2["YellowTerracotta"] = "minecraft:yellow_terracotta";
  MinecraftBlockTypes2["YellowWool"] = "minecraft:yellow_wool";
  return MinecraftBlockTypes2;
})(MinecraftBlockTypes || {});
var MinecraftCameraPresetsTypes = ((MinecraftCameraPresetsTypes2) => {
  MinecraftCameraPresetsTypes2["FirstPerson"] = "minecraft:first_person";
  MinecraftCameraPresetsTypes2["FollowOrbit"] = "minecraft:follow_orbit";
  MinecraftCameraPresetsTypes2["Free"] = "minecraft:free";
  MinecraftCameraPresetsTypes2["ThirdPerson"] = "minecraft:third_person";
  MinecraftCameraPresetsTypes2["ThirdPersonFront"] = "minecraft:third_person_front";
  return MinecraftCameraPresetsTypes2;
})(MinecraftCameraPresetsTypes || {});
var MinecraftCooldownCategoryTypes = ((MinecraftCooldownCategoryTypes2) => {
  MinecraftCooldownCategoryTypes2["Chorusfruit"] = "minecraft:chorusfruit";
  MinecraftCooldownCategoryTypes2["EnderPearl"] = "minecraft:ender_pearl";
  MinecraftCooldownCategoryTypes2["GoatHorn"] = "minecraft:goat_horn";
  MinecraftCooldownCategoryTypes2["Shield"] = "minecraft:shield";
  MinecraftCooldownCategoryTypes2["WindCharge"] = "minecraft:wind_charge";
  return MinecraftCooldownCategoryTypes2;
})(MinecraftCooldownCategoryTypes || {});
var MinecraftDimensionTypes = ((MinecraftDimensionTypes2) => {
  MinecraftDimensionTypes2["Nether"] = "minecraft:nether";
  MinecraftDimensionTypes2["Overworld"] = "minecraft:overworld";
  MinecraftDimensionTypes2["TheEnd"] = "minecraft:the_end";
  return MinecraftDimensionTypes2;
})(MinecraftDimensionTypes || {});
var MinecraftEffectTypes = ((MinecraftEffectTypes2) => {
  MinecraftEffectTypes2["Absorption"] = "minecraft:absorption";
  MinecraftEffectTypes2["BadOmen"] = "minecraft:bad_omen";
  MinecraftEffectTypes2["Blindness"] = "minecraft:blindness";
  MinecraftEffectTypes2["ConduitPower"] = "minecraft:conduit_power";
  MinecraftEffectTypes2["Darkness"] = "minecraft:darkness";
  MinecraftEffectTypes2["FatalPoison"] = "minecraft:fatal_poison";
  MinecraftEffectTypes2["FireResistance"] = "minecraft:fire_resistance";
  MinecraftEffectTypes2["Haste"] = "minecraft:haste";
  MinecraftEffectTypes2["HealthBoost"] = "minecraft:health_boost";
  MinecraftEffectTypes2["Hunger"] = "minecraft:hunger";
  MinecraftEffectTypes2["Infested"] = "minecraft:infested";
  MinecraftEffectTypes2["InstantDamage"] = "minecraft:instant_damage";
  MinecraftEffectTypes2["InstantHealth"] = "minecraft:instant_health";
  MinecraftEffectTypes2["Invisibility"] = "minecraft:invisibility";
  MinecraftEffectTypes2["JumpBoost"] = "minecraft:jump_boost";
  MinecraftEffectTypes2["Levitation"] = "minecraft:levitation";
  MinecraftEffectTypes2["MiningFatigue"] = "minecraft:mining_fatigue";
  MinecraftEffectTypes2["Nausea"] = "minecraft:nausea";
  MinecraftEffectTypes2["NightVision"] = "minecraft:night_vision";
  MinecraftEffectTypes2["Oozing"] = "minecraft:oozing";
  MinecraftEffectTypes2["Poison"] = "minecraft:poison";
  MinecraftEffectTypes2["RaidOmen"] = "minecraft:raid_omen";
  MinecraftEffectTypes2["Regeneration"] = "minecraft:regeneration";
  MinecraftEffectTypes2["Resistance"] = "minecraft:resistance";
  MinecraftEffectTypes2["Saturation"] = "minecraft:saturation";
  MinecraftEffectTypes2["SlowFalling"] = "minecraft:slow_falling";
  MinecraftEffectTypes2["Slowness"] = "minecraft:slowness";
  MinecraftEffectTypes2["Speed"] = "minecraft:speed";
  MinecraftEffectTypes2["Strength"] = "minecraft:strength";
  MinecraftEffectTypes2["TrialOmen"] = "minecraft:trial_omen";
  MinecraftEffectTypes2["VillageHero"] = "minecraft:village_hero";
  MinecraftEffectTypes2["WaterBreathing"] = "minecraft:water_breathing";
  MinecraftEffectTypes2["Weakness"] = "minecraft:weakness";
  MinecraftEffectTypes2["Weaving"] = "minecraft:weaving";
  MinecraftEffectTypes2["WindCharged"] = "minecraft:wind_charged";
  MinecraftEffectTypes2["Wither"] = "minecraft:wither";
  return MinecraftEffectTypes2;
})(MinecraftEffectTypes || {});
var MinecraftEnchantmentTypes = ((MinecraftEnchantmentTypes2) => {
  MinecraftEnchantmentTypes2["AquaAffinity"] = "minecraft:aqua_affinity";
  MinecraftEnchantmentTypes2["BaneOfArthropods"] = "minecraft:bane_of_arthropods";
  MinecraftEnchantmentTypes2["Binding"] = "minecraft:binding";
  MinecraftEnchantmentTypes2["BlastProtection"] = "minecraft:blast_protection";
  MinecraftEnchantmentTypes2["BowInfinity"] = "minecraft:infinity";
  MinecraftEnchantmentTypes2["Breach"] = "minecraft:breach";
  MinecraftEnchantmentTypes2["Channeling"] = "minecraft:channeling";
  MinecraftEnchantmentTypes2["Density"] = "minecraft:density";
  MinecraftEnchantmentTypes2["DepthStrider"] = "minecraft:depth_strider";
  MinecraftEnchantmentTypes2["Efficiency"] = "minecraft:efficiency";
  MinecraftEnchantmentTypes2["FeatherFalling"] = "minecraft:feather_falling";
  MinecraftEnchantmentTypes2["FireAspect"] = "minecraft:fire_aspect";
  MinecraftEnchantmentTypes2["FireProtection"] = "minecraft:fire_protection";
  MinecraftEnchantmentTypes2["Flame"] = "minecraft:flame";
  MinecraftEnchantmentTypes2["Fortune"] = "minecraft:fortune";
  MinecraftEnchantmentTypes2["FrostWalker"] = "minecraft:frost_walker";
  MinecraftEnchantmentTypes2["Impaling"] = "minecraft:impaling";
  MinecraftEnchantmentTypes2["Knockback"] = "minecraft:knockback";
  MinecraftEnchantmentTypes2["Looting"] = "minecraft:looting";
  MinecraftEnchantmentTypes2["Loyalty"] = "minecraft:loyalty";
  MinecraftEnchantmentTypes2["LuckOfTheSea"] = "minecraft:luck_of_the_sea";
  MinecraftEnchantmentTypes2["Lure"] = "minecraft:lure";
  MinecraftEnchantmentTypes2["Mending"] = "minecraft:mending";
  MinecraftEnchantmentTypes2["Multishot"] = "minecraft:multishot";
  MinecraftEnchantmentTypes2["Piercing"] = "minecraft:piercing";
  MinecraftEnchantmentTypes2["Power"] = "minecraft:power";
  MinecraftEnchantmentTypes2["ProjectileProtection"] = "minecraft:projectile_protection";
  MinecraftEnchantmentTypes2["Protection"] = "minecraft:protection";
  MinecraftEnchantmentTypes2["Punch"] = "minecraft:punch";
  MinecraftEnchantmentTypes2["QuickCharge"] = "minecraft:quick_charge";
  MinecraftEnchantmentTypes2["Respiration"] = "minecraft:respiration";
  MinecraftEnchantmentTypes2["Riptide"] = "minecraft:riptide";
  MinecraftEnchantmentTypes2["Sharpness"] = "minecraft:sharpness";
  MinecraftEnchantmentTypes2["SilkTouch"] = "minecraft:silk_touch";
  MinecraftEnchantmentTypes2["Smite"] = "minecraft:smite";
  MinecraftEnchantmentTypes2["SoulSpeed"] = "minecraft:soul_speed";
  MinecraftEnchantmentTypes2["SwiftSneak"] = "minecraft:swift_sneak";
  MinecraftEnchantmentTypes2["Thorns"] = "minecraft:thorns";
  MinecraftEnchantmentTypes2["Unbreaking"] = "minecraft:unbreaking";
  MinecraftEnchantmentTypes2["Vanishing"] = "minecraft:vanishing";
  MinecraftEnchantmentTypes2["WindBurst"] = "minecraft:wind_burst";
  return MinecraftEnchantmentTypes2;
})(MinecraftEnchantmentTypes || {});
var MinecraftEntityTypes = ((MinecraftEntityTypes2) => {
  MinecraftEntityTypes2["Agent"] = "minecraft:agent";
  MinecraftEntityTypes2["Allay"] = "minecraft:allay";
  MinecraftEntityTypes2["AreaEffectCloud"] = "minecraft:area_effect_cloud";
  MinecraftEntityTypes2["Armadillo"] = "minecraft:armadillo";
  MinecraftEntityTypes2["ArmorStand"] = "minecraft:armor_stand";
  MinecraftEntityTypes2["Arrow"] = "minecraft:arrow";
  MinecraftEntityTypes2["Axolotl"] = "minecraft:axolotl";
  MinecraftEntityTypes2["Bat"] = "minecraft:bat";
  MinecraftEntityTypes2["Bee"] = "minecraft:bee";
  MinecraftEntityTypes2["Blaze"] = "minecraft:blaze";
  MinecraftEntityTypes2["Boat"] = "minecraft:boat";
  MinecraftEntityTypes2["Bogged"] = "minecraft:bogged";
  MinecraftEntityTypes2["Breeze"] = "minecraft:breeze";
  MinecraftEntityTypes2["BreezeWindChargeProjectile"] = "minecraft:breeze_wind_charge_projectile";
  MinecraftEntityTypes2["Camel"] = "minecraft:camel";
  MinecraftEntityTypes2["Cat"] = "minecraft:cat";
  MinecraftEntityTypes2["CaveSpider"] = "minecraft:cave_spider";
  MinecraftEntityTypes2["ChestBoat"] = "minecraft:chest_boat";
  MinecraftEntityTypes2["ChestMinecart"] = "minecraft:chest_minecart";
  MinecraftEntityTypes2["Chicken"] = "minecraft:chicken";
  MinecraftEntityTypes2["Cod"] = "minecraft:cod";
  MinecraftEntityTypes2["CommandBlockMinecart"] = "minecraft:command_block_minecart";
  MinecraftEntityTypes2["Cow"] = "minecraft:cow";
  MinecraftEntityTypes2["Creeper"] = "minecraft:creeper";
  MinecraftEntityTypes2["Dolphin"] = "minecraft:dolphin";
  MinecraftEntityTypes2["Donkey"] = "minecraft:donkey";
  MinecraftEntityTypes2["DragonFireball"] = "minecraft:dragon_fireball";
  MinecraftEntityTypes2["Drowned"] = "minecraft:drowned";
  MinecraftEntityTypes2["Egg"] = "minecraft:egg";
  MinecraftEntityTypes2["ElderGuardian"] = "minecraft:elder_guardian";
  MinecraftEntityTypes2["EnderCrystal"] = "minecraft:ender_crystal";
  MinecraftEntityTypes2["EnderDragon"] = "minecraft:ender_dragon";
  MinecraftEntityTypes2["EnderPearl"] = "minecraft:ender_pearl";
  MinecraftEntityTypes2["Enderman"] = "minecraft:enderman";
  MinecraftEntityTypes2["Endermite"] = "minecraft:endermite";
  MinecraftEntityTypes2["EvocationIllager"] = "minecraft:evocation_illager";
  MinecraftEntityTypes2["EyeOfEnderSignal"] = "minecraft:eye_of_ender_signal";
  MinecraftEntityTypes2["Fireball"] = "minecraft:fireball";
  MinecraftEntityTypes2["FireworksRocket"] = "minecraft:fireworks_rocket";
  MinecraftEntityTypes2["FishingHook"] = "minecraft:fishing_hook";
  MinecraftEntityTypes2["Fox"] = "minecraft:fox";
  MinecraftEntityTypes2["Frog"] = "minecraft:frog";
  MinecraftEntityTypes2["Ghast"] = "minecraft:ghast";
  MinecraftEntityTypes2["GlowSquid"] = "minecraft:glow_squid";
  MinecraftEntityTypes2["Goat"] = "minecraft:goat";
  MinecraftEntityTypes2["Guardian"] = "minecraft:guardian";
  MinecraftEntityTypes2["Hoglin"] = "minecraft:hoglin";
  MinecraftEntityTypes2["HopperMinecart"] = "minecraft:hopper_minecart";
  MinecraftEntityTypes2["Horse"] = "minecraft:horse";
  MinecraftEntityTypes2["Husk"] = "minecraft:husk";
  MinecraftEntityTypes2["IronGolem"] = "minecraft:iron_golem";
  MinecraftEntityTypes2["LightningBolt"] = "minecraft:lightning_bolt";
  MinecraftEntityTypes2["LingeringPotion"] = "minecraft:lingering_potion";
  MinecraftEntityTypes2["Llama"] = "minecraft:llama";
  MinecraftEntityTypes2["LlamaSpit"] = "minecraft:llama_spit";
  MinecraftEntityTypes2["MagmaCube"] = "minecraft:magma_cube";
  MinecraftEntityTypes2["Minecart"] = "minecraft:minecart";
  MinecraftEntityTypes2["Mooshroom"] = "minecraft:mooshroom";
  MinecraftEntityTypes2["Mule"] = "minecraft:mule";
  MinecraftEntityTypes2["Npc"] = "minecraft:npc";
  MinecraftEntityTypes2["Ocelot"] = "minecraft:ocelot";
  MinecraftEntityTypes2["OminousItemSpawner"] = "minecraft:ominous_item_spawner";
  MinecraftEntityTypes2["Panda"] = "minecraft:panda";
  MinecraftEntityTypes2["Parrot"] = "minecraft:parrot";
  MinecraftEntityTypes2["Phantom"] = "minecraft:phantom";
  MinecraftEntityTypes2["Pig"] = "minecraft:pig";
  MinecraftEntityTypes2["Piglin"] = "minecraft:piglin";
  MinecraftEntityTypes2["PiglinBrute"] = "minecraft:piglin_brute";
  MinecraftEntityTypes2["Pillager"] = "minecraft:pillager";
  MinecraftEntityTypes2["Player"] = "minecraft:player";
  MinecraftEntityTypes2["PolarBear"] = "minecraft:polar_bear";
  MinecraftEntityTypes2["Pufferfish"] = "minecraft:pufferfish";
  MinecraftEntityTypes2["Rabbit"] = "minecraft:rabbit";
  MinecraftEntityTypes2["Ravager"] = "minecraft:ravager";
  MinecraftEntityTypes2["Salmon"] = "minecraft:salmon";
  MinecraftEntityTypes2["Sheep"] = "minecraft:sheep";
  MinecraftEntityTypes2["Shulker"] = "minecraft:shulker";
  MinecraftEntityTypes2["ShulkerBullet"] = "minecraft:shulker_bullet";
  MinecraftEntityTypes2["Silverfish"] = "minecraft:silverfish";
  MinecraftEntityTypes2["Skeleton"] = "minecraft:skeleton";
  MinecraftEntityTypes2["SkeletonHorse"] = "minecraft:skeleton_horse";
  MinecraftEntityTypes2["Slime"] = "minecraft:slime";
  MinecraftEntityTypes2["SmallFireball"] = "minecraft:small_fireball";
  MinecraftEntityTypes2["Sniffer"] = "minecraft:sniffer";
  MinecraftEntityTypes2["SnowGolem"] = "minecraft:snow_golem";
  MinecraftEntityTypes2["Snowball"] = "minecraft:snowball";
  MinecraftEntityTypes2["Spider"] = "minecraft:spider";
  MinecraftEntityTypes2["SplashPotion"] = "minecraft:splash_potion";
  MinecraftEntityTypes2["Squid"] = "minecraft:squid";
  MinecraftEntityTypes2["Stray"] = "minecraft:stray";
  MinecraftEntityTypes2["Strider"] = "minecraft:strider";
  MinecraftEntityTypes2["Tadpole"] = "minecraft:tadpole";
  MinecraftEntityTypes2["ThrownTrident"] = "minecraft:thrown_trident";
  MinecraftEntityTypes2["Tnt"] = "minecraft:tnt";
  MinecraftEntityTypes2["TntMinecart"] = "minecraft:tnt_minecart";
  MinecraftEntityTypes2["TraderLlama"] = "minecraft:trader_llama";
  MinecraftEntityTypes2["TripodCamera"] = "minecraft:tripod_camera";
  MinecraftEntityTypes2["Tropicalfish"] = "minecraft:tropicalfish";
  MinecraftEntityTypes2["Turtle"] = "minecraft:turtle";
  MinecraftEntityTypes2["Vex"] = "minecraft:vex";
  MinecraftEntityTypes2["Villager"] = "minecraft:villager";
  MinecraftEntityTypes2["VillagerV2"] = "minecraft:villager_v2";
  MinecraftEntityTypes2["Vindicator"] = "minecraft:vindicator";
  MinecraftEntityTypes2["WanderingTrader"] = "minecraft:wandering_trader";
  MinecraftEntityTypes2["Warden"] = "minecraft:warden";
  MinecraftEntityTypes2["WindChargeProjectile"] = "minecraft:wind_charge_projectile";
  MinecraftEntityTypes2["Witch"] = "minecraft:witch";
  MinecraftEntityTypes2["Wither"] = "minecraft:wither";
  MinecraftEntityTypes2["WitherSkeleton"] = "minecraft:wither_skeleton";
  MinecraftEntityTypes2["WitherSkull"] = "minecraft:wither_skull";
  MinecraftEntityTypes2["WitherSkullDangerous"] = "minecraft:wither_skull_dangerous";
  MinecraftEntityTypes2["Wolf"] = "minecraft:wolf";
  MinecraftEntityTypes2["XpBottle"] = "minecraft:xp_bottle";
  MinecraftEntityTypes2["XpOrb"] = "minecraft:xp_orb";
  MinecraftEntityTypes2["Zoglin"] = "minecraft:zoglin";
  MinecraftEntityTypes2["Zombie"] = "minecraft:zombie";
  MinecraftEntityTypes2["ZombieHorse"] = "minecraft:zombie_horse";
  MinecraftEntityTypes2["ZombiePigman"] = "minecraft:zombie_pigman";
  MinecraftEntityTypes2["ZombieVillager"] = "minecraft:zombie_villager";
  MinecraftEntityTypes2["ZombieVillagerV2"] = "minecraft:zombie_villager_v2";
  return MinecraftEntityTypes2;
})(MinecraftEntityTypes || {});
var MinecraftFeatureTypes = ((MinecraftFeatureTypes2) => {
  MinecraftFeatureTypes2["AncientCity"] = "minecraft:ancient_city";
  MinecraftFeatureTypes2["BastionRemnant"] = "minecraft:bastion_remnant";
  MinecraftFeatureTypes2["BuriedTreasure"] = "minecraft:buried_treasure";
  MinecraftFeatureTypes2["EndCity"] = "minecraft:end_city";
  MinecraftFeatureTypes2["Fortress"] = "minecraft:fortress";
  MinecraftFeatureTypes2["Mansion"] = "minecraft:mansion";
  MinecraftFeatureTypes2["Mineshaft"] = "minecraft:mineshaft";
  MinecraftFeatureTypes2["Monument"] = "minecraft:monument";
  MinecraftFeatureTypes2["PillagerOutpost"] = "minecraft:pillager_outpost";
  MinecraftFeatureTypes2["RuinedPortal"] = "minecraft:ruined_portal";
  MinecraftFeatureTypes2["Ruins"] = "minecraft:ruins";
  MinecraftFeatureTypes2["Shipwreck"] = "minecraft:shipwreck";
  MinecraftFeatureTypes2["Stronghold"] = "minecraft:stronghold";
  MinecraftFeatureTypes2["Temple"] = "minecraft:temple";
  MinecraftFeatureTypes2["TrailRuins"] = "minecraft:trail_ruins";
  MinecraftFeatureTypes2["TrialChambers"] = "minecraft:trial_chambers";
  MinecraftFeatureTypes2["Village"] = "minecraft:village";
  return MinecraftFeatureTypes2;
})(MinecraftFeatureTypes || {});
var MinecraftItemTypes = ((MinecraftItemTypes2) => {
  MinecraftItemTypes2["AcaciaBoat"] = "minecraft:acacia_boat";
  MinecraftItemTypes2["AcaciaButton"] = "minecraft:acacia_button";
  MinecraftItemTypes2["AcaciaChestBoat"] = "minecraft:acacia_chest_boat";
  MinecraftItemTypes2["AcaciaDoor"] = "minecraft:acacia_door";
  MinecraftItemTypes2["AcaciaFence"] = "minecraft:acacia_fence";
  MinecraftItemTypes2["AcaciaFenceGate"] = "minecraft:acacia_fence_gate";
  MinecraftItemTypes2["AcaciaHangingSign"] = "minecraft:acacia_hanging_sign";
  MinecraftItemTypes2["AcaciaLeaves"] = "minecraft:acacia_leaves";
  MinecraftItemTypes2["AcaciaLog"] = "minecraft:acacia_log";
  MinecraftItemTypes2["AcaciaPlanks"] = "minecraft:acacia_planks";
  MinecraftItemTypes2["AcaciaPressurePlate"] = "minecraft:acacia_pressure_plate";
  MinecraftItemTypes2["AcaciaSapling"] = "minecraft:acacia_sapling";
  MinecraftItemTypes2["AcaciaSign"] = "minecraft:acacia_sign";
  MinecraftItemTypes2["AcaciaSlab"] = "minecraft:acacia_slab";
  MinecraftItemTypes2["AcaciaStairs"] = "minecraft:acacia_stairs";
  MinecraftItemTypes2["AcaciaTrapdoor"] = "minecraft:acacia_trapdoor";
  MinecraftItemTypes2["AcaciaWood"] = "minecraft:acacia_wood";
  MinecraftItemTypes2["ActivatorRail"] = "minecraft:activator_rail";
  MinecraftItemTypes2["Air"] = "minecraft:air";
  MinecraftItemTypes2["AllaySpawnEgg"] = "minecraft:allay_spawn_egg";
  MinecraftItemTypes2["Allium"] = "minecraft:allium";
  MinecraftItemTypes2["Allow"] = "minecraft:allow";
  MinecraftItemTypes2["AmethystBlock"] = "minecraft:amethyst_block";
  MinecraftItemTypes2["AmethystCluster"] = "minecraft:amethyst_cluster";
  MinecraftItemTypes2["AmethystShard"] = "minecraft:amethyst_shard";
  MinecraftItemTypes2["AncientDebris"] = "minecraft:ancient_debris";
  MinecraftItemTypes2["Andesite"] = "minecraft:andesite";
  MinecraftItemTypes2["AndesiteSlab"] = "minecraft:andesite_slab";
  MinecraftItemTypes2["AndesiteStairs"] = "minecraft:andesite_stairs";
  MinecraftItemTypes2["AnglerPotterySherd"] = "minecraft:angler_pottery_sherd";
  MinecraftItemTypes2["Anvil"] = "minecraft:anvil";
  MinecraftItemTypes2["Apple"] = "minecraft:apple";
  MinecraftItemTypes2["ArcherPotterySherd"] = "minecraft:archer_pottery_sherd";
  MinecraftItemTypes2["ArmadilloScute"] = "minecraft:armadillo_scute";
  MinecraftItemTypes2["ArmadilloSpawnEgg"] = "minecraft:armadillo_spawn_egg";
  MinecraftItemTypes2["ArmorStand"] = "minecraft:armor_stand";
  MinecraftItemTypes2["ArmsUpPotterySherd"] = "minecraft:arms_up_pottery_sherd";
  MinecraftItemTypes2["Arrow"] = "minecraft:arrow";
  MinecraftItemTypes2["AxolotlBucket"] = "minecraft:axolotl_bucket";
  MinecraftItemTypes2["AxolotlSpawnEgg"] = "minecraft:axolotl_spawn_egg";
  MinecraftItemTypes2["Azalea"] = "minecraft:azalea";
  MinecraftItemTypes2["AzaleaLeaves"] = "minecraft:azalea_leaves";
  MinecraftItemTypes2["AzaleaLeavesFlowered"] = "minecraft:azalea_leaves_flowered";
  MinecraftItemTypes2["AzureBluet"] = "minecraft:azure_bluet";
  MinecraftItemTypes2["BakedPotato"] = "minecraft:baked_potato";
  MinecraftItemTypes2["Bamboo"] = "minecraft:bamboo";
  MinecraftItemTypes2["BambooBlock"] = "minecraft:bamboo_block";
  MinecraftItemTypes2["BambooButton"] = "minecraft:bamboo_button";
  MinecraftItemTypes2["BambooChestRaft"] = "minecraft:bamboo_chest_raft";
  MinecraftItemTypes2["BambooDoor"] = "minecraft:bamboo_door";
  MinecraftItemTypes2["BambooFence"] = "minecraft:bamboo_fence";
  MinecraftItemTypes2["BambooFenceGate"] = "minecraft:bamboo_fence_gate";
  MinecraftItemTypes2["BambooHangingSign"] = "minecraft:bamboo_hanging_sign";
  MinecraftItemTypes2["BambooMosaic"] = "minecraft:bamboo_mosaic";
  MinecraftItemTypes2["BambooMosaicSlab"] = "minecraft:bamboo_mosaic_slab";
  MinecraftItemTypes2["BambooMosaicStairs"] = "minecraft:bamboo_mosaic_stairs";
  MinecraftItemTypes2["BambooPlanks"] = "minecraft:bamboo_planks";
  MinecraftItemTypes2["BambooPressurePlate"] = "minecraft:bamboo_pressure_plate";
  MinecraftItemTypes2["BambooRaft"] = "minecraft:bamboo_raft";
  MinecraftItemTypes2["BambooSign"] = "minecraft:bamboo_sign";
  MinecraftItemTypes2["BambooSlab"] = "minecraft:bamboo_slab";
  MinecraftItemTypes2["BambooStairs"] = "minecraft:bamboo_stairs";
  MinecraftItemTypes2["BambooTrapdoor"] = "minecraft:bamboo_trapdoor";
  MinecraftItemTypes2["Banner"] = "minecraft:banner";
  MinecraftItemTypes2["Barrel"] = "minecraft:barrel";
  MinecraftItemTypes2["Barrier"] = "minecraft:barrier";
  MinecraftItemTypes2["Basalt"] = "minecraft:basalt";
  MinecraftItemTypes2["BatSpawnEgg"] = "minecraft:bat_spawn_egg";
  MinecraftItemTypes2["Beacon"] = "minecraft:beacon";
  MinecraftItemTypes2["Bed"] = "minecraft:bed";
  MinecraftItemTypes2["Bedrock"] = "minecraft:bedrock";
  MinecraftItemTypes2["BeeNest"] = "minecraft:bee_nest";
  MinecraftItemTypes2["BeeSpawnEgg"] = "minecraft:bee_spawn_egg";
  MinecraftItemTypes2["Beef"] = "minecraft:beef";
  MinecraftItemTypes2["Beehive"] = "minecraft:beehive";
  MinecraftItemTypes2["Beetroot"] = "minecraft:beetroot";
  MinecraftItemTypes2["BeetrootSeeds"] = "minecraft:beetroot_seeds";
  MinecraftItemTypes2["BeetrootSoup"] = "minecraft:beetroot_soup";
  MinecraftItemTypes2["Bell"] = "minecraft:bell";
  MinecraftItemTypes2["BigDripleaf"] = "minecraft:big_dripleaf";
  MinecraftItemTypes2["BirchBoat"] = "minecraft:birch_boat";
  MinecraftItemTypes2["BirchButton"] = "minecraft:birch_button";
  MinecraftItemTypes2["BirchChestBoat"] = "minecraft:birch_chest_boat";
  MinecraftItemTypes2["BirchDoor"] = "minecraft:birch_door";
  MinecraftItemTypes2["BirchFence"] = "minecraft:birch_fence";
  MinecraftItemTypes2["BirchFenceGate"] = "minecraft:birch_fence_gate";
  MinecraftItemTypes2["BirchHangingSign"] = "minecraft:birch_hanging_sign";
  MinecraftItemTypes2["BirchLeaves"] = "minecraft:birch_leaves";
  MinecraftItemTypes2["BirchLog"] = "minecraft:birch_log";
  MinecraftItemTypes2["BirchPlanks"] = "minecraft:birch_planks";
  MinecraftItemTypes2["BirchPressurePlate"] = "minecraft:birch_pressure_plate";
  MinecraftItemTypes2["BirchSapling"] = "minecraft:birch_sapling";
  MinecraftItemTypes2["BirchSign"] = "minecraft:birch_sign";
  MinecraftItemTypes2["BirchSlab"] = "minecraft:birch_slab";
  MinecraftItemTypes2["BirchStairs"] = "minecraft:birch_stairs";
  MinecraftItemTypes2["BirchTrapdoor"] = "minecraft:birch_trapdoor";
  MinecraftItemTypes2["BirchWood"] = "minecraft:birch_wood";
  MinecraftItemTypes2["BlackCandle"] = "minecraft:black_candle";
  MinecraftItemTypes2["BlackCarpet"] = "minecraft:black_carpet";
  MinecraftItemTypes2["BlackConcrete"] = "minecraft:black_concrete";
  MinecraftItemTypes2["BlackConcretePowder"] = "minecraft:black_concrete_powder";
  MinecraftItemTypes2["BlackDye"] = "minecraft:black_dye";
  MinecraftItemTypes2["BlackGlazedTerracotta"] = "minecraft:black_glazed_terracotta";
  MinecraftItemTypes2["BlackShulkerBox"] = "minecraft:black_shulker_box";
  MinecraftItemTypes2["BlackStainedGlass"] = "minecraft:black_stained_glass";
  MinecraftItemTypes2["BlackStainedGlassPane"] = "minecraft:black_stained_glass_pane";
  MinecraftItemTypes2["BlackTerracotta"] = "minecraft:black_terracotta";
  MinecraftItemTypes2["BlackWool"] = "minecraft:black_wool";
  MinecraftItemTypes2["Blackstone"] = "minecraft:blackstone";
  MinecraftItemTypes2["BlackstoneSlab"] = "minecraft:blackstone_slab";
  MinecraftItemTypes2["BlackstoneStairs"] = "minecraft:blackstone_stairs";
  MinecraftItemTypes2["BlackstoneWall"] = "minecraft:blackstone_wall";
  MinecraftItemTypes2["BladePotterySherd"] = "minecraft:blade_pottery_sherd";
  MinecraftItemTypes2["BlastFurnace"] = "minecraft:blast_furnace";
  MinecraftItemTypes2["BlazePowder"] = "minecraft:blaze_powder";
  MinecraftItemTypes2["BlazeRod"] = "minecraft:blaze_rod";
  MinecraftItemTypes2["BlazeSpawnEgg"] = "minecraft:blaze_spawn_egg";
  MinecraftItemTypes2["BlueCandle"] = "minecraft:blue_candle";
  MinecraftItemTypes2["BlueCarpet"] = "minecraft:blue_carpet";
  MinecraftItemTypes2["BlueConcrete"] = "minecraft:blue_concrete";
  MinecraftItemTypes2["BlueConcretePowder"] = "minecraft:blue_concrete_powder";
  MinecraftItemTypes2["BlueDye"] = "minecraft:blue_dye";
  MinecraftItemTypes2["BlueGlazedTerracotta"] = "minecraft:blue_glazed_terracotta";
  MinecraftItemTypes2["BlueIce"] = "minecraft:blue_ice";
  MinecraftItemTypes2["BlueOrchid"] = "minecraft:blue_orchid";
  MinecraftItemTypes2["BlueShulkerBox"] = "minecraft:blue_shulker_box";
  MinecraftItemTypes2["BlueStainedGlass"] = "minecraft:blue_stained_glass";
  MinecraftItemTypes2["BlueStainedGlassPane"] = "minecraft:blue_stained_glass_pane";
  MinecraftItemTypes2["BlueTerracotta"] = "minecraft:blue_terracotta";
  MinecraftItemTypes2["BlueWool"] = "minecraft:blue_wool";
  MinecraftItemTypes2["BoggedSpawnEgg"] = "minecraft:bogged_spawn_egg";
  MinecraftItemTypes2["BoltArmorTrimSmithingTemplate"] = "minecraft:bolt_armor_trim_smithing_template";
  MinecraftItemTypes2["Bone"] = "minecraft:bone";
  MinecraftItemTypes2["BoneBlock"] = "minecraft:bone_block";
  MinecraftItemTypes2["BoneMeal"] = "minecraft:bone_meal";
  MinecraftItemTypes2["Book"] = "minecraft:book";
  MinecraftItemTypes2["Bookshelf"] = "minecraft:bookshelf";
  MinecraftItemTypes2["BorderBlock"] = "minecraft:border_block";
  MinecraftItemTypes2["BordureIndentedBannerPattern"] = "minecraft:bordure_indented_banner_pattern";
  MinecraftItemTypes2["Bow"] = "minecraft:bow";
  MinecraftItemTypes2["Bowl"] = "minecraft:bowl";
  MinecraftItemTypes2["BrainCoral"] = "minecraft:brain_coral";
  MinecraftItemTypes2["BrainCoralBlock"] = "minecraft:brain_coral_block";
  MinecraftItemTypes2["BrainCoralFan"] = "minecraft:brain_coral_fan";
  MinecraftItemTypes2["Bread"] = "minecraft:bread";
  MinecraftItemTypes2["BreezeRod"] = "minecraft:breeze_rod";
  MinecraftItemTypes2["BreezeSpawnEgg"] = "minecraft:breeze_spawn_egg";
  MinecraftItemTypes2["BrewerPotterySherd"] = "minecraft:brewer_pottery_sherd";
  MinecraftItemTypes2["BrewingStand"] = "minecraft:brewing_stand";
  MinecraftItemTypes2["Brick"] = "minecraft:brick";
  MinecraftItemTypes2["BrickBlock"] = "minecraft:brick_block";
  MinecraftItemTypes2["BrickSlab"] = "minecraft:brick_slab";
  MinecraftItemTypes2["BrickStairs"] = "minecraft:brick_stairs";
  MinecraftItemTypes2["BrownCandle"] = "minecraft:brown_candle";
  MinecraftItemTypes2["BrownCarpet"] = "minecraft:brown_carpet";
  MinecraftItemTypes2["BrownConcrete"] = "minecraft:brown_concrete";
  MinecraftItemTypes2["BrownConcretePowder"] = "minecraft:brown_concrete_powder";
  MinecraftItemTypes2["BrownDye"] = "minecraft:brown_dye";
  MinecraftItemTypes2["BrownGlazedTerracotta"] = "minecraft:brown_glazed_terracotta";
  MinecraftItemTypes2["BrownMushroom"] = "minecraft:brown_mushroom";
  MinecraftItemTypes2["BrownMushroomBlock"] = "minecraft:brown_mushroom_block";
  MinecraftItemTypes2["BrownShulkerBox"] = "minecraft:brown_shulker_box";
  MinecraftItemTypes2["BrownStainedGlass"] = "minecraft:brown_stained_glass";
  MinecraftItemTypes2["BrownStainedGlassPane"] = "minecraft:brown_stained_glass_pane";
  MinecraftItemTypes2["BrownTerracotta"] = "minecraft:brown_terracotta";
  MinecraftItemTypes2["BrownWool"] = "minecraft:brown_wool";
  MinecraftItemTypes2["Brush"] = "minecraft:brush";
  MinecraftItemTypes2["BubbleCoral"] = "minecraft:bubble_coral";
  MinecraftItemTypes2["BubbleCoralBlock"] = "minecraft:bubble_coral_block";
  MinecraftItemTypes2["BubbleCoralFan"] = "minecraft:bubble_coral_fan";
  MinecraftItemTypes2["Bucket"] = "minecraft:bucket";
  MinecraftItemTypes2["BuddingAmethyst"] = "minecraft:budding_amethyst";
  MinecraftItemTypes2["BurnPotterySherd"] = "minecraft:burn_pottery_sherd";
  MinecraftItemTypes2["Cactus"] = "minecraft:cactus";
  MinecraftItemTypes2["Cake"] = "minecraft:cake";
  MinecraftItemTypes2["Calcite"] = "minecraft:calcite";
  MinecraftItemTypes2["CalibratedSculkSensor"] = "minecraft:calibrated_sculk_sensor";
  MinecraftItemTypes2["CamelSpawnEgg"] = "minecraft:camel_spawn_egg";
  MinecraftItemTypes2["Campfire"] = "minecraft:campfire";
  MinecraftItemTypes2["Candle"] = "minecraft:candle";
  MinecraftItemTypes2["Carrot"] = "minecraft:carrot";
  MinecraftItemTypes2["CarrotOnAStick"] = "minecraft:carrot_on_a_stick";
  MinecraftItemTypes2["CartographyTable"] = "minecraft:cartography_table";
  MinecraftItemTypes2["CarvedPumpkin"] = "minecraft:carved_pumpkin";
  MinecraftItemTypes2["CatSpawnEgg"] = "minecraft:cat_spawn_egg";
  MinecraftItemTypes2["Cauldron"] = "minecraft:cauldron";
  MinecraftItemTypes2["CaveSpiderSpawnEgg"] = "minecraft:cave_spider_spawn_egg";
  MinecraftItemTypes2["Chain"] = "minecraft:chain";
  MinecraftItemTypes2["ChainCommandBlock"] = "minecraft:chain_command_block";
  MinecraftItemTypes2["ChainmailBoots"] = "minecraft:chainmail_boots";
  MinecraftItemTypes2["ChainmailChestplate"] = "minecraft:chainmail_chestplate";
  MinecraftItemTypes2["ChainmailHelmet"] = "minecraft:chainmail_helmet";
  MinecraftItemTypes2["ChainmailLeggings"] = "minecraft:chainmail_leggings";
  MinecraftItemTypes2["Charcoal"] = "minecraft:charcoal";
  MinecraftItemTypes2["CherryBoat"] = "minecraft:cherry_boat";
  MinecraftItemTypes2["CherryButton"] = "minecraft:cherry_button";
  MinecraftItemTypes2["CherryChestBoat"] = "minecraft:cherry_chest_boat";
  MinecraftItemTypes2["CherryDoor"] = "minecraft:cherry_door";
  MinecraftItemTypes2["CherryFence"] = "minecraft:cherry_fence";
  MinecraftItemTypes2["CherryFenceGate"] = "minecraft:cherry_fence_gate";
  MinecraftItemTypes2["CherryHangingSign"] = "minecraft:cherry_hanging_sign";
  MinecraftItemTypes2["CherryLeaves"] = "minecraft:cherry_leaves";
  MinecraftItemTypes2["CherryLog"] = "minecraft:cherry_log";
  MinecraftItemTypes2["CherryPlanks"] = "minecraft:cherry_planks";
  MinecraftItemTypes2["CherryPressurePlate"] = "minecraft:cherry_pressure_plate";
  MinecraftItemTypes2["CherrySapling"] = "minecraft:cherry_sapling";
  MinecraftItemTypes2["CherrySign"] = "minecraft:cherry_sign";
  MinecraftItemTypes2["CherrySlab"] = "minecraft:cherry_slab";
  MinecraftItemTypes2["CherryStairs"] = "minecraft:cherry_stairs";
  MinecraftItemTypes2["CherryTrapdoor"] = "minecraft:cherry_trapdoor";
  MinecraftItemTypes2["CherryWood"] = "minecraft:cherry_wood";
  MinecraftItemTypes2["Chest"] = "minecraft:chest";
  MinecraftItemTypes2["ChestMinecart"] = "minecraft:chest_minecart";
  MinecraftItemTypes2["Chicken"] = "minecraft:chicken";
  MinecraftItemTypes2["ChickenSpawnEgg"] = "minecraft:chicken_spawn_egg";
  MinecraftItemTypes2["ChippedAnvil"] = "minecraft:chipped_anvil";
  MinecraftItemTypes2["ChiseledBookshelf"] = "minecraft:chiseled_bookshelf";
  MinecraftItemTypes2["ChiseledCopper"] = "minecraft:chiseled_copper";
  MinecraftItemTypes2["ChiseledDeepslate"] = "minecraft:chiseled_deepslate";
  MinecraftItemTypes2["ChiseledNetherBricks"] = "minecraft:chiseled_nether_bricks";
  MinecraftItemTypes2["ChiseledPolishedBlackstone"] = "minecraft:chiseled_polished_blackstone";
  MinecraftItemTypes2["ChiseledQuartzBlock"] = "minecraft:chiseled_quartz_block";
  MinecraftItemTypes2["ChiseledRedSandstone"] = "minecraft:chiseled_red_sandstone";
  MinecraftItemTypes2["ChiseledSandstone"] = "minecraft:chiseled_sandstone";
  MinecraftItemTypes2["ChiseledStoneBricks"] = "minecraft:chiseled_stone_bricks";
  MinecraftItemTypes2["ChiseledTuff"] = "minecraft:chiseled_tuff";
  MinecraftItemTypes2["ChiseledTuffBricks"] = "minecraft:chiseled_tuff_bricks";
  MinecraftItemTypes2["ChorusFlower"] = "minecraft:chorus_flower";
  MinecraftItemTypes2["ChorusFruit"] = "minecraft:chorus_fruit";
  MinecraftItemTypes2["ChorusPlant"] = "minecraft:chorus_plant";
  MinecraftItemTypes2["Clay"] = "minecraft:clay";
  MinecraftItemTypes2["ClayBall"] = "minecraft:clay_ball";
  MinecraftItemTypes2["Clock"] = "minecraft:clock";
  MinecraftItemTypes2["Coal"] = "minecraft:coal";
  MinecraftItemTypes2["CoalBlock"] = "minecraft:coal_block";
  MinecraftItemTypes2["CoalOre"] = "minecraft:coal_ore";
  MinecraftItemTypes2["CoarseDirt"] = "minecraft:coarse_dirt";
  MinecraftItemTypes2["CoastArmorTrimSmithingTemplate"] = "minecraft:coast_armor_trim_smithing_template";
  MinecraftItemTypes2["CobbledDeepslate"] = "minecraft:cobbled_deepslate";
  MinecraftItemTypes2["CobbledDeepslateSlab"] = "minecraft:cobbled_deepslate_slab";
  MinecraftItemTypes2["CobbledDeepslateStairs"] = "minecraft:cobbled_deepslate_stairs";
  MinecraftItemTypes2["CobbledDeepslateWall"] = "minecraft:cobbled_deepslate_wall";
  MinecraftItemTypes2["Cobblestone"] = "minecraft:cobblestone";
  MinecraftItemTypes2["CobblestoneSlab"] = "minecraft:cobblestone_slab";
  MinecraftItemTypes2["CobblestoneWall"] = "minecraft:cobblestone_wall";
  MinecraftItemTypes2["CocoaBeans"] = "minecraft:cocoa_beans";
  MinecraftItemTypes2["Cod"] = "minecraft:cod";
  MinecraftItemTypes2["CodBucket"] = "minecraft:cod_bucket";
  MinecraftItemTypes2["CodSpawnEgg"] = "minecraft:cod_spawn_egg";
  MinecraftItemTypes2["CommandBlock"] = "minecraft:command_block";
  MinecraftItemTypes2["CommandBlockMinecart"] = "minecraft:command_block_minecart";
  MinecraftItemTypes2["Comparator"] = "minecraft:comparator";
  MinecraftItemTypes2["Compass"] = "minecraft:compass";
  MinecraftItemTypes2["Composter"] = "minecraft:composter";
  MinecraftItemTypes2["Conduit"] = "minecraft:conduit";
  MinecraftItemTypes2["CookedBeef"] = "minecraft:cooked_beef";
  MinecraftItemTypes2["CookedChicken"] = "minecraft:cooked_chicken";
  MinecraftItemTypes2["CookedCod"] = "minecraft:cooked_cod";
  MinecraftItemTypes2["CookedMutton"] = "minecraft:cooked_mutton";
  MinecraftItemTypes2["CookedPorkchop"] = "minecraft:cooked_porkchop";
  MinecraftItemTypes2["CookedRabbit"] = "minecraft:cooked_rabbit";
  MinecraftItemTypes2["CookedSalmon"] = "minecraft:cooked_salmon";
  MinecraftItemTypes2["Cookie"] = "minecraft:cookie";
  MinecraftItemTypes2["CopperBlock"] = "minecraft:copper_block";
  MinecraftItemTypes2["CopperBulb"] = "minecraft:copper_bulb";
  MinecraftItemTypes2["CopperDoor"] = "minecraft:copper_door";
  MinecraftItemTypes2["CopperGrate"] = "minecraft:copper_grate";
  MinecraftItemTypes2["CopperIngot"] = "minecraft:copper_ingot";
  MinecraftItemTypes2["CopperOre"] = "minecraft:copper_ore";
  MinecraftItemTypes2["CopperTrapdoor"] = "minecraft:copper_trapdoor";
  MinecraftItemTypes2["Cornflower"] = "minecraft:cornflower";
  MinecraftItemTypes2["CowSpawnEgg"] = "minecraft:cow_spawn_egg";
  MinecraftItemTypes2["CrackedDeepslateBricks"] = "minecraft:cracked_deepslate_bricks";
  MinecraftItemTypes2["CrackedDeepslateTiles"] = "minecraft:cracked_deepslate_tiles";
  MinecraftItemTypes2["CrackedNetherBricks"] = "minecraft:cracked_nether_bricks";
  MinecraftItemTypes2["CrackedPolishedBlackstoneBricks"] = "minecraft:cracked_polished_blackstone_bricks";
  MinecraftItemTypes2["CrackedStoneBricks"] = "minecraft:cracked_stone_bricks";
  MinecraftItemTypes2["Crafter"] = "minecraft:crafter";
  MinecraftItemTypes2["CraftingTable"] = "minecraft:crafting_table";
  MinecraftItemTypes2["CreeperBannerPattern"] = "minecraft:creeper_banner_pattern";
  MinecraftItemTypes2["CreeperSpawnEgg"] = "minecraft:creeper_spawn_egg";
  MinecraftItemTypes2["CrimsonButton"] = "minecraft:crimson_button";
  MinecraftItemTypes2["CrimsonDoor"] = "minecraft:crimson_door";
  MinecraftItemTypes2["CrimsonFence"] = "minecraft:crimson_fence";
  MinecraftItemTypes2["CrimsonFenceGate"] = "minecraft:crimson_fence_gate";
  MinecraftItemTypes2["CrimsonFungus"] = "minecraft:crimson_fungus";
  MinecraftItemTypes2["CrimsonHangingSign"] = "minecraft:crimson_hanging_sign";
  MinecraftItemTypes2["CrimsonHyphae"] = "minecraft:crimson_hyphae";
  MinecraftItemTypes2["CrimsonNylium"] = "minecraft:crimson_nylium";
  MinecraftItemTypes2["CrimsonPlanks"] = "minecraft:crimson_planks";
  MinecraftItemTypes2["CrimsonPressurePlate"] = "minecraft:crimson_pressure_plate";
  MinecraftItemTypes2["CrimsonRoots"] = "minecraft:crimson_roots";
  MinecraftItemTypes2["CrimsonSign"] = "minecraft:crimson_sign";
  MinecraftItemTypes2["CrimsonSlab"] = "minecraft:crimson_slab";
  MinecraftItemTypes2["CrimsonStairs"] = "minecraft:crimson_stairs";
  MinecraftItemTypes2["CrimsonStem"] = "minecraft:crimson_stem";
  MinecraftItemTypes2["CrimsonTrapdoor"] = "minecraft:crimson_trapdoor";
  MinecraftItemTypes2["Crossbow"] = "minecraft:crossbow";
  MinecraftItemTypes2["CryingObsidian"] = "minecraft:crying_obsidian";
  MinecraftItemTypes2["CutCopper"] = "minecraft:cut_copper";
  MinecraftItemTypes2["CutCopperSlab"] = "minecraft:cut_copper_slab";
  MinecraftItemTypes2["CutCopperStairs"] = "minecraft:cut_copper_stairs";
  MinecraftItemTypes2["CutRedSandstone"] = "minecraft:cut_red_sandstone";
  MinecraftItemTypes2["CutRedSandstoneSlab"] = "minecraft:cut_red_sandstone_slab";
  MinecraftItemTypes2["CutSandstone"] = "minecraft:cut_sandstone";
  MinecraftItemTypes2["CutSandstoneSlab"] = "minecraft:cut_sandstone_slab";
  MinecraftItemTypes2["CyanCandle"] = "minecraft:cyan_candle";
  MinecraftItemTypes2["CyanCarpet"] = "minecraft:cyan_carpet";
  MinecraftItemTypes2["CyanConcrete"] = "minecraft:cyan_concrete";
  MinecraftItemTypes2["CyanConcretePowder"] = "minecraft:cyan_concrete_powder";
  MinecraftItemTypes2["CyanDye"] = "minecraft:cyan_dye";
  MinecraftItemTypes2["CyanGlazedTerracotta"] = "minecraft:cyan_glazed_terracotta";
  MinecraftItemTypes2["CyanShulkerBox"] = "minecraft:cyan_shulker_box";
  MinecraftItemTypes2["CyanStainedGlass"] = "minecraft:cyan_stained_glass";
  MinecraftItemTypes2["CyanStainedGlassPane"] = "minecraft:cyan_stained_glass_pane";
  MinecraftItemTypes2["CyanTerracotta"] = "minecraft:cyan_terracotta";
  MinecraftItemTypes2["CyanWool"] = "minecraft:cyan_wool";
  MinecraftItemTypes2["DamagedAnvil"] = "minecraft:damaged_anvil";
  MinecraftItemTypes2["Dandelion"] = "minecraft:dandelion";
  MinecraftItemTypes2["DangerPotterySherd"] = "minecraft:danger_pottery_sherd";
  MinecraftItemTypes2["DarkOakBoat"] = "minecraft:dark_oak_boat";
  MinecraftItemTypes2["DarkOakButton"] = "minecraft:dark_oak_button";
  MinecraftItemTypes2["DarkOakChestBoat"] = "minecraft:dark_oak_chest_boat";
  MinecraftItemTypes2["DarkOakDoor"] = "minecraft:dark_oak_door";
  MinecraftItemTypes2["DarkOakFence"] = "minecraft:dark_oak_fence";
  MinecraftItemTypes2["DarkOakFenceGate"] = "minecraft:dark_oak_fence_gate";
  MinecraftItemTypes2["DarkOakHangingSign"] = "minecraft:dark_oak_hanging_sign";
  MinecraftItemTypes2["DarkOakLeaves"] = "minecraft:dark_oak_leaves";
  MinecraftItemTypes2["DarkOakLog"] = "minecraft:dark_oak_log";
  MinecraftItemTypes2["DarkOakPlanks"] = "minecraft:dark_oak_planks";
  MinecraftItemTypes2["DarkOakPressurePlate"] = "minecraft:dark_oak_pressure_plate";
  MinecraftItemTypes2["DarkOakSapling"] = "minecraft:dark_oak_sapling";
  MinecraftItemTypes2["DarkOakSign"] = "minecraft:dark_oak_sign";
  MinecraftItemTypes2["DarkOakSlab"] = "minecraft:dark_oak_slab";
  MinecraftItemTypes2["DarkOakStairs"] = "minecraft:dark_oak_stairs";
  MinecraftItemTypes2["DarkOakTrapdoor"] = "minecraft:dark_oak_trapdoor";
  MinecraftItemTypes2["DarkOakWood"] = "minecraft:dark_oak_wood";
  MinecraftItemTypes2["DarkPrismarine"] = "minecraft:dark_prismarine";
  MinecraftItemTypes2["DarkPrismarineSlab"] = "minecraft:dark_prismarine_slab";
  MinecraftItemTypes2["DarkPrismarineStairs"] = "minecraft:dark_prismarine_stairs";
  MinecraftItemTypes2["DaylightDetector"] = "minecraft:daylight_detector";
  MinecraftItemTypes2["DeadBrainCoral"] = "minecraft:dead_brain_coral";
  MinecraftItemTypes2["DeadBrainCoralBlock"] = "minecraft:dead_brain_coral_block";
  MinecraftItemTypes2["DeadBrainCoralFan"] = "minecraft:dead_brain_coral_fan";
  MinecraftItemTypes2["DeadBubbleCoral"] = "minecraft:dead_bubble_coral";
  MinecraftItemTypes2["DeadBubbleCoralBlock"] = "minecraft:dead_bubble_coral_block";
  MinecraftItemTypes2["DeadBubbleCoralFan"] = "minecraft:dead_bubble_coral_fan";
  MinecraftItemTypes2["DeadFireCoral"] = "minecraft:dead_fire_coral";
  MinecraftItemTypes2["DeadFireCoralBlock"] = "minecraft:dead_fire_coral_block";
  MinecraftItemTypes2["DeadFireCoralFan"] = "minecraft:dead_fire_coral_fan";
  MinecraftItemTypes2["DeadHornCoral"] = "minecraft:dead_horn_coral";
  MinecraftItemTypes2["DeadHornCoralBlock"] = "minecraft:dead_horn_coral_block";
  MinecraftItemTypes2["DeadHornCoralFan"] = "minecraft:dead_horn_coral_fan";
  MinecraftItemTypes2["DeadTubeCoral"] = "minecraft:dead_tube_coral";
  MinecraftItemTypes2["DeadTubeCoralBlock"] = "minecraft:dead_tube_coral_block";
  MinecraftItemTypes2["DeadTubeCoralFan"] = "minecraft:dead_tube_coral_fan";
  MinecraftItemTypes2["Deadbush"] = "minecraft:deadbush";
  MinecraftItemTypes2["DecoratedPot"] = "minecraft:decorated_pot";
  MinecraftItemTypes2["Deepslate"] = "minecraft:deepslate";
  MinecraftItemTypes2["DeepslateBrickSlab"] = "minecraft:deepslate_brick_slab";
  MinecraftItemTypes2["DeepslateBrickStairs"] = "minecraft:deepslate_brick_stairs";
  MinecraftItemTypes2["DeepslateBrickWall"] = "minecraft:deepslate_brick_wall";
  MinecraftItemTypes2["DeepslateBricks"] = "minecraft:deepslate_bricks";
  MinecraftItemTypes2["DeepslateCoalOre"] = "minecraft:deepslate_coal_ore";
  MinecraftItemTypes2["DeepslateCopperOre"] = "minecraft:deepslate_copper_ore";
  MinecraftItemTypes2["DeepslateDiamondOre"] = "minecraft:deepslate_diamond_ore";
  MinecraftItemTypes2["DeepslateEmeraldOre"] = "minecraft:deepslate_emerald_ore";
  MinecraftItemTypes2["DeepslateGoldOre"] = "minecraft:deepslate_gold_ore";
  MinecraftItemTypes2["DeepslateIronOre"] = "minecraft:deepslate_iron_ore";
  MinecraftItemTypes2["DeepslateLapisOre"] = "minecraft:deepslate_lapis_ore";
  MinecraftItemTypes2["DeepslateRedstoneOre"] = "minecraft:deepslate_redstone_ore";
  MinecraftItemTypes2["DeepslateTileSlab"] = "minecraft:deepslate_tile_slab";
  MinecraftItemTypes2["DeepslateTileStairs"] = "minecraft:deepslate_tile_stairs";
  MinecraftItemTypes2["DeepslateTileWall"] = "minecraft:deepslate_tile_wall";
  MinecraftItemTypes2["DeepslateTiles"] = "minecraft:deepslate_tiles";
  MinecraftItemTypes2["Deny"] = "minecraft:deny";
  MinecraftItemTypes2["DetectorRail"] = "minecraft:detector_rail";
  MinecraftItemTypes2["Diamond"] = "minecraft:diamond";
  MinecraftItemTypes2["DiamondAxe"] = "minecraft:diamond_axe";
  MinecraftItemTypes2["DiamondBlock"] = "minecraft:diamond_block";
  MinecraftItemTypes2["DiamondBoots"] = "minecraft:diamond_boots";
  MinecraftItemTypes2["DiamondChestplate"] = "minecraft:diamond_chestplate";
  MinecraftItemTypes2["DiamondHelmet"] = "minecraft:diamond_helmet";
  MinecraftItemTypes2["DiamondHoe"] = "minecraft:diamond_hoe";
  MinecraftItemTypes2["DiamondHorseArmor"] = "minecraft:diamond_horse_armor";
  MinecraftItemTypes2["DiamondLeggings"] = "minecraft:diamond_leggings";
  MinecraftItemTypes2["DiamondOre"] = "minecraft:diamond_ore";
  MinecraftItemTypes2["DiamondPickaxe"] = "minecraft:diamond_pickaxe";
  MinecraftItemTypes2["DiamondShovel"] = "minecraft:diamond_shovel";
  MinecraftItemTypes2["DiamondSword"] = "minecraft:diamond_sword";
  MinecraftItemTypes2["Diorite"] = "minecraft:diorite";
  MinecraftItemTypes2["DioriteSlab"] = "minecraft:diorite_slab";
  MinecraftItemTypes2["DioriteStairs"] = "minecraft:diorite_stairs";
  MinecraftItemTypes2["Dirt"] = "minecraft:dirt";
  MinecraftItemTypes2["DirtWithRoots"] = "minecraft:dirt_with_roots";
  MinecraftItemTypes2["DiscFragment5"] = "minecraft:disc_fragment_5";
  MinecraftItemTypes2["Dispenser"] = "minecraft:dispenser";
  MinecraftItemTypes2["DolphinSpawnEgg"] = "minecraft:dolphin_spawn_egg";
  MinecraftItemTypes2["DonkeySpawnEgg"] = "minecraft:donkey_spawn_egg";
  MinecraftItemTypes2["DragonBreath"] = "minecraft:dragon_breath";
  MinecraftItemTypes2["DragonEgg"] = "minecraft:dragon_egg";
  MinecraftItemTypes2["DriedKelp"] = "minecraft:dried_kelp";
  MinecraftItemTypes2["DriedKelpBlock"] = "minecraft:dried_kelp_block";
  MinecraftItemTypes2["DripstoneBlock"] = "minecraft:dripstone_block";
  MinecraftItemTypes2["Dropper"] = "minecraft:dropper";
  MinecraftItemTypes2["DrownedSpawnEgg"] = "minecraft:drowned_spawn_egg";
  MinecraftItemTypes2["DuneArmorTrimSmithingTemplate"] = "minecraft:dune_armor_trim_smithing_template";
  MinecraftItemTypes2["EchoShard"] = "minecraft:echo_shard";
  MinecraftItemTypes2["Egg"] = "minecraft:egg";
  MinecraftItemTypes2["ElderGuardianSpawnEgg"] = "minecraft:elder_guardian_spawn_egg";
  MinecraftItemTypes2["Elytra"] = "minecraft:elytra";
  MinecraftItemTypes2["Emerald"] = "minecraft:emerald";
  MinecraftItemTypes2["EmeraldBlock"] = "minecraft:emerald_block";
  MinecraftItemTypes2["EmeraldOre"] = "minecraft:emerald_ore";
  MinecraftItemTypes2["EmptyMap"] = "minecraft:empty_map";
  MinecraftItemTypes2["EnchantedBook"] = "minecraft:enchanted_book";
  MinecraftItemTypes2["EnchantedGoldenApple"] = "minecraft:enchanted_golden_apple";
  MinecraftItemTypes2["EnchantingTable"] = "minecraft:enchanting_table";
  MinecraftItemTypes2["EndBrickStairs"] = "minecraft:end_brick_stairs";
  MinecraftItemTypes2["EndBricks"] = "minecraft:end_bricks";
  MinecraftItemTypes2["EndCrystal"] = "minecraft:end_crystal";
  MinecraftItemTypes2["EndPortalFrame"] = "minecraft:end_portal_frame";
  MinecraftItemTypes2["EndRod"] = "minecraft:end_rod";
  MinecraftItemTypes2["EndStone"] = "minecraft:end_stone";
  MinecraftItemTypes2["EndStoneBrickSlab"] = "minecraft:end_stone_brick_slab";
  MinecraftItemTypes2["EnderChest"] = "minecraft:ender_chest";
  MinecraftItemTypes2["EnderDragonSpawnEgg"] = "minecraft:ender_dragon_spawn_egg";
  MinecraftItemTypes2["EnderEye"] = "minecraft:ender_eye";
  MinecraftItemTypes2["EnderPearl"] = "minecraft:ender_pearl";
  MinecraftItemTypes2["EndermanSpawnEgg"] = "minecraft:enderman_spawn_egg";
  MinecraftItemTypes2["EndermiteSpawnEgg"] = "minecraft:endermite_spawn_egg";
  MinecraftItemTypes2["EvokerSpawnEgg"] = "minecraft:evoker_spawn_egg";
  MinecraftItemTypes2["ExperienceBottle"] = "minecraft:experience_bottle";
  MinecraftItemTypes2["ExplorerPotterySherd"] = "minecraft:explorer_pottery_sherd";
  MinecraftItemTypes2["ExposedChiseledCopper"] = "minecraft:exposed_chiseled_copper";
  MinecraftItemTypes2["ExposedCopper"] = "minecraft:exposed_copper";
  MinecraftItemTypes2["ExposedCopperBulb"] = "minecraft:exposed_copper_bulb";
  MinecraftItemTypes2["ExposedCopperDoor"] = "minecraft:exposed_copper_door";
  MinecraftItemTypes2["ExposedCopperGrate"] = "minecraft:exposed_copper_grate";
  MinecraftItemTypes2["ExposedCopperTrapdoor"] = "minecraft:exposed_copper_trapdoor";
  MinecraftItemTypes2["ExposedCutCopper"] = "minecraft:exposed_cut_copper";
  MinecraftItemTypes2["ExposedCutCopperSlab"] = "minecraft:exposed_cut_copper_slab";
  MinecraftItemTypes2["ExposedCutCopperStairs"] = "minecraft:exposed_cut_copper_stairs";
  MinecraftItemTypes2["EyeArmorTrimSmithingTemplate"] = "minecraft:eye_armor_trim_smithing_template";
  MinecraftItemTypes2["Farmland"] = "minecraft:farmland";
  MinecraftItemTypes2["Feather"] = "minecraft:feather";
  MinecraftItemTypes2["FenceGate"] = "minecraft:fence_gate";
  MinecraftItemTypes2["FermentedSpiderEye"] = "minecraft:fermented_spider_eye";
  MinecraftItemTypes2["Fern"] = "minecraft:fern";
  MinecraftItemTypes2["FieldMasonedBannerPattern"] = "minecraft:field_masoned_banner_pattern";
  MinecraftItemTypes2["FilledMap"] = "minecraft:filled_map";
  MinecraftItemTypes2["FireCharge"] = "minecraft:fire_charge";
  MinecraftItemTypes2["FireCoral"] = "minecraft:fire_coral";
  MinecraftItemTypes2["FireCoralBlock"] = "minecraft:fire_coral_block";
  MinecraftItemTypes2["FireCoralFan"] = "minecraft:fire_coral_fan";
  MinecraftItemTypes2["FireworkRocket"] = "minecraft:firework_rocket";
  MinecraftItemTypes2["FireworkStar"] = "minecraft:firework_star";
  MinecraftItemTypes2["FishingRod"] = "minecraft:fishing_rod";
  MinecraftItemTypes2["FletchingTable"] = "minecraft:fletching_table";
  MinecraftItemTypes2["Flint"] = "minecraft:flint";
  MinecraftItemTypes2["FlintAndSteel"] = "minecraft:flint_and_steel";
  MinecraftItemTypes2["FlowArmorTrimSmithingTemplate"] = "minecraft:flow_armor_trim_smithing_template";
  MinecraftItemTypes2["FlowBannerPattern"] = "minecraft:flow_banner_pattern";
  MinecraftItemTypes2["FlowPotterySherd"] = "minecraft:flow_pottery_sherd";
  MinecraftItemTypes2["FlowerBannerPattern"] = "minecraft:flower_banner_pattern";
  MinecraftItemTypes2["FlowerPot"] = "minecraft:flower_pot";
  MinecraftItemTypes2["FloweringAzalea"] = "minecraft:flowering_azalea";
  MinecraftItemTypes2["FoxSpawnEgg"] = "minecraft:fox_spawn_egg";
  MinecraftItemTypes2["Frame"] = "minecraft:frame";
  MinecraftItemTypes2["FriendPotterySherd"] = "minecraft:friend_pottery_sherd";
  MinecraftItemTypes2["FrogSpawn"] = "minecraft:frog_spawn";
  MinecraftItemTypes2["FrogSpawnEgg"] = "minecraft:frog_spawn_egg";
  MinecraftItemTypes2["FrostedIce"] = "minecraft:frosted_ice";
  MinecraftItemTypes2["Furnace"] = "minecraft:furnace";
  MinecraftItemTypes2["GhastSpawnEgg"] = "minecraft:ghast_spawn_egg";
  MinecraftItemTypes2["GhastTear"] = "minecraft:ghast_tear";
  MinecraftItemTypes2["GildedBlackstone"] = "minecraft:gilded_blackstone";
  MinecraftItemTypes2["Glass"] = "minecraft:glass";
  MinecraftItemTypes2["GlassBottle"] = "minecraft:glass_bottle";
  MinecraftItemTypes2["GlassPane"] = "minecraft:glass_pane";
  MinecraftItemTypes2["GlisteringMelonSlice"] = "minecraft:glistering_melon_slice";
  MinecraftItemTypes2["GlobeBannerPattern"] = "minecraft:globe_banner_pattern";
  MinecraftItemTypes2["GlowBerries"] = "minecraft:glow_berries";
  MinecraftItemTypes2["GlowFrame"] = "minecraft:glow_frame";
  MinecraftItemTypes2["GlowInkSac"] = "minecraft:glow_ink_sac";
  MinecraftItemTypes2["GlowLichen"] = "minecraft:glow_lichen";
  MinecraftItemTypes2["GlowSquidSpawnEgg"] = "minecraft:glow_squid_spawn_egg";
  MinecraftItemTypes2["Glowstone"] = "minecraft:glowstone";
  MinecraftItemTypes2["GlowstoneDust"] = "minecraft:glowstone_dust";
  MinecraftItemTypes2["GoatHorn"] = "minecraft:goat_horn";
  MinecraftItemTypes2["GoatSpawnEgg"] = "minecraft:goat_spawn_egg";
  MinecraftItemTypes2["GoldBlock"] = "minecraft:gold_block";
  MinecraftItemTypes2["GoldIngot"] = "minecraft:gold_ingot";
  MinecraftItemTypes2["GoldNugget"] = "minecraft:gold_nugget";
  MinecraftItemTypes2["GoldOre"] = "minecraft:gold_ore";
  MinecraftItemTypes2["GoldenApple"] = "minecraft:golden_apple";
  MinecraftItemTypes2["GoldenAxe"] = "minecraft:golden_axe";
  MinecraftItemTypes2["GoldenBoots"] = "minecraft:golden_boots";
  MinecraftItemTypes2["GoldenCarrot"] = "minecraft:golden_carrot";
  MinecraftItemTypes2["GoldenChestplate"] = "minecraft:golden_chestplate";
  MinecraftItemTypes2["GoldenHelmet"] = "minecraft:golden_helmet";
  MinecraftItemTypes2["GoldenHoe"] = "minecraft:golden_hoe";
  MinecraftItemTypes2["GoldenHorseArmor"] = "minecraft:golden_horse_armor";
  MinecraftItemTypes2["GoldenLeggings"] = "minecraft:golden_leggings";
  MinecraftItemTypes2["GoldenPickaxe"] = "minecraft:golden_pickaxe";
  MinecraftItemTypes2["GoldenRail"] = "minecraft:golden_rail";
  MinecraftItemTypes2["GoldenShovel"] = "minecraft:golden_shovel";
  MinecraftItemTypes2["GoldenSword"] = "minecraft:golden_sword";
  MinecraftItemTypes2["Granite"] = "minecraft:granite";
  MinecraftItemTypes2["GraniteSlab"] = "minecraft:granite_slab";
  MinecraftItemTypes2["GraniteStairs"] = "minecraft:granite_stairs";
  MinecraftItemTypes2["GrassBlock"] = "minecraft:grass_block";
  MinecraftItemTypes2["GrassPath"] = "minecraft:grass_path";
  MinecraftItemTypes2["Gravel"] = "minecraft:gravel";
  MinecraftItemTypes2["GrayCandle"] = "minecraft:gray_candle";
  MinecraftItemTypes2["GrayCarpet"] = "minecraft:gray_carpet";
  MinecraftItemTypes2["GrayConcrete"] = "minecraft:gray_concrete";
  MinecraftItemTypes2["GrayConcretePowder"] = "minecraft:gray_concrete_powder";
  MinecraftItemTypes2["GrayDye"] = "minecraft:gray_dye";
  MinecraftItemTypes2["GrayGlazedTerracotta"] = "minecraft:gray_glazed_terracotta";
  MinecraftItemTypes2["GrayShulkerBox"] = "minecraft:gray_shulker_box";
  MinecraftItemTypes2["GrayStainedGlass"] = "minecraft:gray_stained_glass";
  MinecraftItemTypes2["GrayStainedGlassPane"] = "minecraft:gray_stained_glass_pane";
  MinecraftItemTypes2["GrayTerracotta"] = "minecraft:gray_terracotta";
  MinecraftItemTypes2["GrayWool"] = "minecraft:gray_wool";
  MinecraftItemTypes2["GreenCandle"] = "minecraft:green_candle";
  MinecraftItemTypes2["GreenCarpet"] = "minecraft:green_carpet";
  MinecraftItemTypes2["GreenConcrete"] = "minecraft:green_concrete";
  MinecraftItemTypes2["GreenConcretePowder"] = "minecraft:green_concrete_powder";
  MinecraftItemTypes2["GreenDye"] = "minecraft:green_dye";
  MinecraftItemTypes2["GreenGlazedTerracotta"] = "minecraft:green_glazed_terracotta";
  MinecraftItemTypes2["GreenShulkerBox"] = "minecraft:green_shulker_box";
  MinecraftItemTypes2["GreenStainedGlass"] = "minecraft:green_stained_glass";
  MinecraftItemTypes2["GreenStainedGlassPane"] = "minecraft:green_stained_glass_pane";
  MinecraftItemTypes2["GreenTerracotta"] = "minecraft:green_terracotta";
  MinecraftItemTypes2["GreenWool"] = "minecraft:green_wool";
  MinecraftItemTypes2["Grindstone"] = "minecraft:grindstone";
  MinecraftItemTypes2["GuardianSpawnEgg"] = "minecraft:guardian_spawn_egg";
  MinecraftItemTypes2["Gunpowder"] = "minecraft:gunpowder";
  MinecraftItemTypes2["GusterBannerPattern"] = "minecraft:guster_banner_pattern";
  MinecraftItemTypes2["GusterPotterySherd"] = "minecraft:guster_pottery_sherd";
  MinecraftItemTypes2["HangingRoots"] = "minecraft:hanging_roots";
  MinecraftItemTypes2["HardenedClay"] = "minecraft:hardened_clay";
  MinecraftItemTypes2["HayBlock"] = "minecraft:hay_block";
  MinecraftItemTypes2["HeartOfTheSea"] = "minecraft:heart_of_the_sea";
  MinecraftItemTypes2["HeartPotterySherd"] = "minecraft:heart_pottery_sherd";
  MinecraftItemTypes2["HeartbreakPotterySherd"] = "minecraft:heartbreak_pottery_sherd";
  MinecraftItemTypes2["HeavyCore"] = "minecraft:heavy_core";
  MinecraftItemTypes2["HeavyWeightedPressurePlate"] = "minecraft:heavy_weighted_pressure_plate";
  MinecraftItemTypes2["HoglinSpawnEgg"] = "minecraft:hoglin_spawn_egg";
  MinecraftItemTypes2["HoneyBlock"] = "minecraft:honey_block";
  MinecraftItemTypes2["HoneyBottle"] = "minecraft:honey_bottle";
  MinecraftItemTypes2["Honeycomb"] = "minecraft:honeycomb";
  MinecraftItemTypes2["HoneycombBlock"] = "minecraft:honeycomb_block";
  MinecraftItemTypes2["Hopper"] = "minecraft:hopper";
  MinecraftItemTypes2["HopperMinecart"] = "minecraft:hopper_minecart";
  MinecraftItemTypes2["HornCoral"] = "minecraft:horn_coral";
  MinecraftItemTypes2["HornCoralBlock"] = "minecraft:horn_coral_block";
  MinecraftItemTypes2["HornCoralFan"] = "minecraft:horn_coral_fan";
  MinecraftItemTypes2["HorseSpawnEgg"] = "minecraft:horse_spawn_egg";
  MinecraftItemTypes2["HostArmorTrimSmithingTemplate"] = "minecraft:host_armor_trim_smithing_template";
  MinecraftItemTypes2["HowlPotterySherd"] = "minecraft:howl_pottery_sherd";
  MinecraftItemTypes2["HuskSpawnEgg"] = "minecraft:husk_spawn_egg";
  MinecraftItemTypes2["Ice"] = "minecraft:ice";
  MinecraftItemTypes2["InfestedChiseledStoneBricks"] = "minecraft:infested_chiseled_stone_bricks";
  MinecraftItemTypes2["InfestedCobblestone"] = "minecraft:infested_cobblestone";
  MinecraftItemTypes2["InfestedCrackedStoneBricks"] = "minecraft:infested_cracked_stone_bricks";
  MinecraftItemTypes2["InfestedDeepslate"] = "minecraft:infested_deepslate";
  MinecraftItemTypes2["InfestedMossyStoneBricks"] = "minecraft:infested_mossy_stone_bricks";
  MinecraftItemTypes2["InfestedStone"] = "minecraft:infested_stone";
  MinecraftItemTypes2["InfestedStoneBricks"] = "minecraft:infested_stone_bricks";
  MinecraftItemTypes2["InkSac"] = "minecraft:ink_sac";
  MinecraftItemTypes2["IronAxe"] = "minecraft:iron_axe";
  MinecraftItemTypes2["IronBars"] = "minecraft:iron_bars";
  MinecraftItemTypes2["IronBlock"] = "minecraft:iron_block";
  MinecraftItemTypes2["IronBoots"] = "minecraft:iron_boots";
  MinecraftItemTypes2["IronChestplate"] = "minecraft:iron_chestplate";
  MinecraftItemTypes2["IronDoor"] = "minecraft:iron_door";
  MinecraftItemTypes2["IronGolemSpawnEgg"] = "minecraft:iron_golem_spawn_egg";
  MinecraftItemTypes2["IronHelmet"] = "minecraft:iron_helmet";
  MinecraftItemTypes2["IronHoe"] = "minecraft:iron_hoe";
  MinecraftItemTypes2["IronHorseArmor"] = "minecraft:iron_horse_armor";
  MinecraftItemTypes2["IronIngot"] = "minecraft:iron_ingot";
  MinecraftItemTypes2["IronLeggings"] = "minecraft:iron_leggings";
  MinecraftItemTypes2["IronNugget"] = "minecraft:iron_nugget";
  MinecraftItemTypes2["IronOre"] = "minecraft:iron_ore";
  MinecraftItemTypes2["IronPickaxe"] = "minecraft:iron_pickaxe";
  MinecraftItemTypes2["IronShovel"] = "minecraft:iron_shovel";
  MinecraftItemTypes2["IronSword"] = "minecraft:iron_sword";
  MinecraftItemTypes2["IronTrapdoor"] = "minecraft:iron_trapdoor";
  MinecraftItemTypes2["Jigsaw"] = "minecraft:jigsaw";
  MinecraftItemTypes2["Jukebox"] = "minecraft:jukebox";
  MinecraftItemTypes2["JungleBoat"] = "minecraft:jungle_boat";
  MinecraftItemTypes2["JungleButton"] = "minecraft:jungle_button";
  MinecraftItemTypes2["JungleChestBoat"] = "minecraft:jungle_chest_boat";
  MinecraftItemTypes2["JungleDoor"] = "minecraft:jungle_door";
  MinecraftItemTypes2["JungleFence"] = "minecraft:jungle_fence";
  MinecraftItemTypes2["JungleFenceGate"] = "minecraft:jungle_fence_gate";
  MinecraftItemTypes2["JungleHangingSign"] = "minecraft:jungle_hanging_sign";
  MinecraftItemTypes2["JungleLeaves"] = "minecraft:jungle_leaves";
  MinecraftItemTypes2["JungleLog"] = "minecraft:jungle_log";
  MinecraftItemTypes2["JunglePlanks"] = "minecraft:jungle_planks";
  MinecraftItemTypes2["JunglePressurePlate"] = "minecraft:jungle_pressure_plate";
  MinecraftItemTypes2["JungleSapling"] = "minecraft:jungle_sapling";
  MinecraftItemTypes2["JungleSign"] = "minecraft:jungle_sign";
  MinecraftItemTypes2["JungleSlab"] = "minecraft:jungle_slab";
  MinecraftItemTypes2["JungleStairs"] = "minecraft:jungle_stairs";
  MinecraftItemTypes2["JungleTrapdoor"] = "minecraft:jungle_trapdoor";
  MinecraftItemTypes2["JungleWood"] = "minecraft:jungle_wood";
  MinecraftItemTypes2["Kelp"] = "minecraft:kelp";
  MinecraftItemTypes2["Ladder"] = "minecraft:ladder";
  MinecraftItemTypes2["Lantern"] = "minecraft:lantern";
  MinecraftItemTypes2["LapisBlock"] = "minecraft:lapis_block";
  MinecraftItemTypes2["LapisLazuli"] = "minecraft:lapis_lazuli";
  MinecraftItemTypes2["LapisOre"] = "minecraft:lapis_ore";
  MinecraftItemTypes2["LargeAmethystBud"] = "minecraft:large_amethyst_bud";
  MinecraftItemTypes2["LargeFern"] = "minecraft:large_fern";
  MinecraftItemTypes2["LavaBucket"] = "minecraft:lava_bucket";
  MinecraftItemTypes2["Lead"] = "minecraft:lead";
  MinecraftItemTypes2["Leather"] = "minecraft:leather";
  MinecraftItemTypes2["LeatherBoots"] = "minecraft:leather_boots";
  MinecraftItemTypes2["LeatherChestplate"] = "minecraft:leather_chestplate";
  MinecraftItemTypes2["LeatherHelmet"] = "minecraft:leather_helmet";
  MinecraftItemTypes2["LeatherHorseArmor"] = "minecraft:leather_horse_armor";
  MinecraftItemTypes2["LeatherLeggings"] = "minecraft:leather_leggings";
  MinecraftItemTypes2["Lectern"] = "minecraft:lectern";
  MinecraftItemTypes2["Lever"] = "minecraft:lever";
  MinecraftItemTypes2["LightBlock0"] = "minecraft:light_block_0";
  MinecraftItemTypes2["LightBlock1"] = "minecraft:light_block_1";
  MinecraftItemTypes2["LightBlock10"] = "minecraft:light_block_10";
  MinecraftItemTypes2["LightBlock11"] = "minecraft:light_block_11";
  MinecraftItemTypes2["LightBlock12"] = "minecraft:light_block_12";
  MinecraftItemTypes2["LightBlock13"] = "minecraft:light_block_13";
  MinecraftItemTypes2["LightBlock14"] = "minecraft:light_block_14";
  MinecraftItemTypes2["LightBlock15"] = "minecraft:light_block_15";
  MinecraftItemTypes2["LightBlock2"] = "minecraft:light_block_2";
  MinecraftItemTypes2["LightBlock3"] = "minecraft:light_block_3";
  MinecraftItemTypes2["LightBlock4"] = "minecraft:light_block_4";
  MinecraftItemTypes2["LightBlock5"] = "minecraft:light_block_5";
  MinecraftItemTypes2["LightBlock6"] = "minecraft:light_block_6";
  MinecraftItemTypes2["LightBlock7"] = "minecraft:light_block_7";
  MinecraftItemTypes2["LightBlock8"] = "minecraft:light_block_8";
  MinecraftItemTypes2["LightBlock9"] = "minecraft:light_block_9";
  MinecraftItemTypes2["LightBlueCandle"] = "minecraft:light_blue_candle";
  MinecraftItemTypes2["LightBlueCarpet"] = "minecraft:light_blue_carpet";
  MinecraftItemTypes2["LightBlueConcrete"] = "minecraft:light_blue_concrete";
  MinecraftItemTypes2["LightBlueConcretePowder"] = "minecraft:light_blue_concrete_powder";
  MinecraftItemTypes2["LightBlueDye"] = "minecraft:light_blue_dye";
  MinecraftItemTypes2["LightBlueGlazedTerracotta"] = "minecraft:light_blue_glazed_terracotta";
  MinecraftItemTypes2["LightBlueShulkerBox"] = "minecraft:light_blue_shulker_box";
  MinecraftItemTypes2["LightBlueStainedGlass"] = "minecraft:light_blue_stained_glass";
  MinecraftItemTypes2["LightBlueStainedGlassPane"] = "minecraft:light_blue_stained_glass_pane";
  MinecraftItemTypes2["LightBlueTerracotta"] = "minecraft:light_blue_terracotta";
  MinecraftItemTypes2["LightBlueWool"] = "minecraft:light_blue_wool";
  MinecraftItemTypes2["LightGrayCandle"] = "minecraft:light_gray_candle";
  MinecraftItemTypes2["LightGrayCarpet"] = "minecraft:light_gray_carpet";
  MinecraftItemTypes2["LightGrayConcrete"] = "minecraft:light_gray_concrete";
  MinecraftItemTypes2["LightGrayConcretePowder"] = "minecraft:light_gray_concrete_powder";
  MinecraftItemTypes2["LightGrayDye"] = "minecraft:light_gray_dye";
  MinecraftItemTypes2["LightGrayShulkerBox"] = "minecraft:light_gray_shulker_box";
  MinecraftItemTypes2["LightGrayStainedGlass"] = "minecraft:light_gray_stained_glass";
  MinecraftItemTypes2["LightGrayStainedGlassPane"] = "minecraft:light_gray_stained_glass_pane";
  MinecraftItemTypes2["LightGrayTerracotta"] = "minecraft:light_gray_terracotta";
  MinecraftItemTypes2["LightGrayWool"] = "minecraft:light_gray_wool";
  MinecraftItemTypes2["LightWeightedPressurePlate"] = "minecraft:light_weighted_pressure_plate";
  MinecraftItemTypes2["LightningRod"] = "minecraft:lightning_rod";
  MinecraftItemTypes2["Lilac"] = "minecraft:lilac";
  MinecraftItemTypes2["LilyOfTheValley"] = "minecraft:lily_of_the_valley";
  MinecraftItemTypes2["LimeCandle"] = "minecraft:lime_candle";
  MinecraftItemTypes2["LimeCarpet"] = "minecraft:lime_carpet";
  MinecraftItemTypes2["LimeConcrete"] = "minecraft:lime_concrete";
  MinecraftItemTypes2["LimeConcretePowder"] = "minecraft:lime_concrete_powder";
  MinecraftItemTypes2["LimeDye"] = "minecraft:lime_dye";
  MinecraftItemTypes2["LimeGlazedTerracotta"] = "minecraft:lime_glazed_terracotta";
  MinecraftItemTypes2["LimeShulkerBox"] = "minecraft:lime_shulker_box";
  MinecraftItemTypes2["LimeStainedGlass"] = "minecraft:lime_stained_glass";
  MinecraftItemTypes2["LimeStainedGlassPane"] = "minecraft:lime_stained_glass_pane";
  MinecraftItemTypes2["LimeTerracotta"] = "minecraft:lime_terracotta";
  MinecraftItemTypes2["LimeWool"] = "minecraft:lime_wool";
  MinecraftItemTypes2["LingeringPotion"] = "minecraft:lingering_potion";
  MinecraftItemTypes2["LitPumpkin"] = "minecraft:lit_pumpkin";
  MinecraftItemTypes2["LlamaSpawnEgg"] = "minecraft:llama_spawn_egg";
  MinecraftItemTypes2["Lodestone"] = "minecraft:lodestone";
  MinecraftItemTypes2["LodestoneCompass"] = "minecraft:lodestone_compass";
  MinecraftItemTypes2["Loom"] = "minecraft:loom";
  MinecraftItemTypes2["Mace"] = "minecraft:mace";
  MinecraftItemTypes2["MagentaCandle"] = "minecraft:magenta_candle";
  MinecraftItemTypes2["MagentaCarpet"] = "minecraft:magenta_carpet";
  MinecraftItemTypes2["MagentaConcrete"] = "minecraft:magenta_concrete";
  MinecraftItemTypes2["MagentaConcretePowder"] = "minecraft:magenta_concrete_powder";
  MinecraftItemTypes2["MagentaDye"] = "minecraft:magenta_dye";
  MinecraftItemTypes2["MagentaGlazedTerracotta"] = "minecraft:magenta_glazed_terracotta";
  MinecraftItemTypes2["MagentaShulkerBox"] = "minecraft:magenta_shulker_box";
  MinecraftItemTypes2["MagentaStainedGlass"] = "minecraft:magenta_stained_glass";
  MinecraftItemTypes2["MagentaStainedGlassPane"] = "minecraft:magenta_stained_glass_pane";
  MinecraftItemTypes2["MagentaTerracotta"] = "minecraft:magenta_terracotta";
  MinecraftItemTypes2["MagentaWool"] = "minecraft:magenta_wool";
  MinecraftItemTypes2["Magma"] = "minecraft:magma";
  MinecraftItemTypes2["MagmaCream"] = "minecraft:magma_cream";
  MinecraftItemTypes2["MagmaCubeSpawnEgg"] = "minecraft:magma_cube_spawn_egg";
  MinecraftItemTypes2["MangroveBoat"] = "minecraft:mangrove_boat";
  MinecraftItemTypes2["MangroveButton"] = "minecraft:mangrove_button";
  MinecraftItemTypes2["MangroveChestBoat"] = "minecraft:mangrove_chest_boat";
  MinecraftItemTypes2["MangroveDoor"] = "minecraft:mangrove_door";
  MinecraftItemTypes2["MangroveFence"] = "minecraft:mangrove_fence";
  MinecraftItemTypes2["MangroveFenceGate"] = "minecraft:mangrove_fence_gate";
  MinecraftItemTypes2["MangroveHangingSign"] = "minecraft:mangrove_hanging_sign";
  MinecraftItemTypes2["MangroveLeaves"] = "minecraft:mangrove_leaves";
  MinecraftItemTypes2["MangroveLog"] = "minecraft:mangrove_log";
  MinecraftItemTypes2["MangrovePlanks"] = "minecraft:mangrove_planks";
  MinecraftItemTypes2["MangrovePressurePlate"] = "minecraft:mangrove_pressure_plate";
  MinecraftItemTypes2["MangrovePropagule"] = "minecraft:mangrove_propagule";
  MinecraftItemTypes2["MangroveRoots"] = "minecraft:mangrove_roots";
  MinecraftItemTypes2["MangroveSign"] = "minecraft:mangrove_sign";
  MinecraftItemTypes2["MangroveSlab"] = "minecraft:mangrove_slab";
  MinecraftItemTypes2["MangroveStairs"] = "minecraft:mangrove_stairs";
  MinecraftItemTypes2["MangroveTrapdoor"] = "minecraft:mangrove_trapdoor";
  MinecraftItemTypes2["MangroveWood"] = "minecraft:mangrove_wood";
  MinecraftItemTypes2["MediumAmethystBud"] = "minecraft:medium_amethyst_bud";
  MinecraftItemTypes2["MelonBlock"] = "minecraft:melon_block";
  MinecraftItemTypes2["MelonSeeds"] = "minecraft:melon_seeds";
  MinecraftItemTypes2["MelonSlice"] = "minecraft:melon_slice";
  MinecraftItemTypes2["MilkBucket"] = "minecraft:milk_bucket";
  MinecraftItemTypes2["Minecart"] = "minecraft:minecart";
  MinecraftItemTypes2["MinerPotterySherd"] = "minecraft:miner_pottery_sherd";
  MinecraftItemTypes2["MobSpawner"] = "minecraft:mob_spawner";
  MinecraftItemTypes2["MojangBannerPattern"] = "minecraft:mojang_banner_pattern";
  MinecraftItemTypes2["MooshroomSpawnEgg"] = "minecraft:mooshroom_spawn_egg";
  MinecraftItemTypes2["MossBlock"] = "minecraft:moss_block";
  MinecraftItemTypes2["MossCarpet"] = "minecraft:moss_carpet";
  MinecraftItemTypes2["MossyCobblestone"] = "minecraft:mossy_cobblestone";
  MinecraftItemTypes2["MossyCobblestoneSlab"] = "minecraft:mossy_cobblestone_slab";
  MinecraftItemTypes2["MossyCobblestoneStairs"] = "minecraft:mossy_cobblestone_stairs";
  MinecraftItemTypes2["MossyStoneBrickSlab"] = "minecraft:mossy_stone_brick_slab";
  MinecraftItemTypes2["MossyStoneBrickStairs"] = "minecraft:mossy_stone_brick_stairs";
  MinecraftItemTypes2["MossyStoneBricks"] = "minecraft:mossy_stone_bricks";
  MinecraftItemTypes2["MournerPotterySherd"] = "minecraft:mourner_pottery_sherd";
  MinecraftItemTypes2["Mud"] = "minecraft:mud";
  MinecraftItemTypes2["MudBrickSlab"] = "minecraft:mud_brick_slab";
  MinecraftItemTypes2["MudBrickStairs"] = "minecraft:mud_brick_stairs";
  MinecraftItemTypes2["MudBrickWall"] = "minecraft:mud_brick_wall";
  MinecraftItemTypes2["MudBricks"] = "minecraft:mud_bricks";
  MinecraftItemTypes2["MuddyMangroveRoots"] = "minecraft:muddy_mangrove_roots";
  MinecraftItemTypes2["MuleSpawnEgg"] = "minecraft:mule_spawn_egg";
  MinecraftItemTypes2["MushroomStew"] = "minecraft:mushroom_stew";
  MinecraftItemTypes2["MusicDisc11"] = "minecraft:music_disc_11";
  MinecraftItemTypes2["MusicDisc13"] = "minecraft:music_disc_13";
  MinecraftItemTypes2["MusicDisc5"] = "minecraft:music_disc_5";
  MinecraftItemTypes2["MusicDiscBlocks"] = "minecraft:music_disc_blocks";
  MinecraftItemTypes2["MusicDiscCat"] = "minecraft:music_disc_cat";
  MinecraftItemTypes2["MusicDiscChirp"] = "minecraft:music_disc_chirp";
  MinecraftItemTypes2["MusicDiscCreator"] = "minecraft:music_disc_creator";
  MinecraftItemTypes2["MusicDiscCreatorMusicBox"] = "minecraft:music_disc_creator_music_box";
  MinecraftItemTypes2["MusicDiscFar"] = "minecraft:music_disc_far";
  MinecraftItemTypes2["MusicDiscMall"] = "minecraft:music_disc_mall";
  MinecraftItemTypes2["MusicDiscMellohi"] = "minecraft:music_disc_mellohi";
  MinecraftItemTypes2["MusicDiscOtherside"] = "minecraft:music_disc_otherside";
  MinecraftItemTypes2["MusicDiscPigstep"] = "minecraft:music_disc_pigstep";
  MinecraftItemTypes2["MusicDiscPrecipice"] = "minecraft:music_disc_precipice";
  MinecraftItemTypes2["MusicDiscRelic"] = "minecraft:music_disc_relic";
  MinecraftItemTypes2["MusicDiscStal"] = "minecraft:music_disc_stal";
  MinecraftItemTypes2["MusicDiscStrad"] = "minecraft:music_disc_strad";
  MinecraftItemTypes2["MusicDiscWait"] = "minecraft:music_disc_wait";
  MinecraftItemTypes2["MusicDiscWard"] = "minecraft:music_disc_ward";
  MinecraftItemTypes2["Mutton"] = "minecraft:mutton";
  MinecraftItemTypes2["Mycelium"] = "minecraft:mycelium";
  MinecraftItemTypes2["NameTag"] = "minecraft:name_tag";
  MinecraftItemTypes2["NautilusShell"] = "minecraft:nautilus_shell";
  MinecraftItemTypes2["NetherBrick"] = "minecraft:nether_brick";
  MinecraftItemTypes2["NetherBrickFence"] = "minecraft:nether_brick_fence";
  MinecraftItemTypes2["NetherBrickSlab"] = "minecraft:nether_brick_slab";
  MinecraftItemTypes2["NetherBrickStairs"] = "minecraft:nether_brick_stairs";
  MinecraftItemTypes2["NetherGoldOre"] = "minecraft:nether_gold_ore";
  MinecraftItemTypes2["NetherSprouts"] = "minecraft:nether_sprouts";
  MinecraftItemTypes2["NetherStar"] = "minecraft:nether_star";
  MinecraftItemTypes2["NetherWart"] = "minecraft:nether_wart";
  MinecraftItemTypes2["NetherWartBlock"] = "minecraft:nether_wart_block";
  MinecraftItemTypes2["Netherbrick"] = "minecraft:netherbrick";
  MinecraftItemTypes2["NetheriteAxe"] = "minecraft:netherite_axe";
  MinecraftItemTypes2["NetheriteBlock"] = "minecraft:netherite_block";
  MinecraftItemTypes2["NetheriteBoots"] = "minecraft:netherite_boots";
  MinecraftItemTypes2["NetheriteChestplate"] = "minecraft:netherite_chestplate";
  MinecraftItemTypes2["NetheriteHelmet"] = "minecraft:netherite_helmet";
  MinecraftItemTypes2["NetheriteHoe"] = "minecraft:netherite_hoe";
  MinecraftItemTypes2["NetheriteIngot"] = "minecraft:netherite_ingot";
  MinecraftItemTypes2["NetheriteLeggings"] = "minecraft:netherite_leggings";
  MinecraftItemTypes2["NetheritePickaxe"] = "minecraft:netherite_pickaxe";
  MinecraftItemTypes2["NetheriteScrap"] = "minecraft:netherite_scrap";
  MinecraftItemTypes2["NetheriteShovel"] = "minecraft:netherite_shovel";
  MinecraftItemTypes2["NetheriteSword"] = "minecraft:netherite_sword";
  MinecraftItemTypes2["NetheriteUpgradeSmithingTemplate"] = "minecraft:netherite_upgrade_smithing_template";
  MinecraftItemTypes2["Netherrack"] = "minecraft:netherrack";
  MinecraftItemTypes2["NormalStoneSlab"] = "minecraft:normal_stone_slab";
  MinecraftItemTypes2["NormalStoneStairs"] = "minecraft:normal_stone_stairs";
  MinecraftItemTypes2["Noteblock"] = "minecraft:noteblock";
  MinecraftItemTypes2["OakBoat"] = "minecraft:oak_boat";
  MinecraftItemTypes2["OakChestBoat"] = "minecraft:oak_chest_boat";
  MinecraftItemTypes2["OakFence"] = "minecraft:oak_fence";
  MinecraftItemTypes2["OakHangingSign"] = "minecraft:oak_hanging_sign";
  MinecraftItemTypes2["OakLeaves"] = "minecraft:oak_leaves";
  MinecraftItemTypes2["OakLog"] = "minecraft:oak_log";
  MinecraftItemTypes2["OakPlanks"] = "minecraft:oak_planks";
  MinecraftItemTypes2["OakSapling"] = "minecraft:oak_sapling";
  MinecraftItemTypes2["OakSign"] = "minecraft:oak_sign";
  MinecraftItemTypes2["OakSlab"] = "minecraft:oak_slab";
  MinecraftItemTypes2["OakStairs"] = "minecraft:oak_stairs";
  MinecraftItemTypes2["OakWood"] = "minecraft:oak_wood";
  MinecraftItemTypes2["Observer"] = "minecraft:observer";
  MinecraftItemTypes2["Obsidian"] = "minecraft:obsidian";
  MinecraftItemTypes2["OcelotSpawnEgg"] = "minecraft:ocelot_spawn_egg";
  MinecraftItemTypes2["OchreFroglight"] = "minecraft:ochre_froglight";
  MinecraftItemTypes2["OminousBottle"] = "minecraft:ominous_bottle";
  MinecraftItemTypes2["OminousTrialKey"] = "minecraft:ominous_trial_key";
  MinecraftItemTypes2["OrangeCandle"] = "minecraft:orange_candle";
  MinecraftItemTypes2["OrangeCarpet"] = "minecraft:orange_carpet";
  MinecraftItemTypes2["OrangeConcrete"] = "minecraft:orange_concrete";
  MinecraftItemTypes2["OrangeConcretePowder"] = "minecraft:orange_concrete_powder";
  MinecraftItemTypes2["OrangeDye"] = "minecraft:orange_dye";
  MinecraftItemTypes2["OrangeGlazedTerracotta"] = "minecraft:orange_glazed_terracotta";
  MinecraftItemTypes2["OrangeShulkerBox"] = "minecraft:orange_shulker_box";
  MinecraftItemTypes2["OrangeStainedGlass"] = "minecraft:orange_stained_glass";
  MinecraftItemTypes2["OrangeStainedGlassPane"] = "minecraft:orange_stained_glass_pane";
  MinecraftItemTypes2["OrangeTerracotta"] = "minecraft:orange_terracotta";
  MinecraftItemTypes2["OrangeTulip"] = "minecraft:orange_tulip";
  MinecraftItemTypes2["OrangeWool"] = "minecraft:orange_wool";
  MinecraftItemTypes2["OxeyeDaisy"] = "minecraft:oxeye_daisy";
  MinecraftItemTypes2["OxidizedChiseledCopper"] = "minecraft:oxidized_chiseled_copper";
  MinecraftItemTypes2["OxidizedCopper"] = "minecraft:oxidized_copper";
  MinecraftItemTypes2["OxidizedCopperBulb"] = "minecraft:oxidized_copper_bulb";
  MinecraftItemTypes2["OxidizedCopperDoor"] = "minecraft:oxidized_copper_door";
  MinecraftItemTypes2["OxidizedCopperGrate"] = "minecraft:oxidized_copper_grate";
  MinecraftItemTypes2["OxidizedCopperTrapdoor"] = "minecraft:oxidized_copper_trapdoor";
  MinecraftItemTypes2["OxidizedCutCopper"] = "minecraft:oxidized_cut_copper";
  MinecraftItemTypes2["OxidizedCutCopperSlab"] = "minecraft:oxidized_cut_copper_slab";
  MinecraftItemTypes2["OxidizedCutCopperStairs"] = "minecraft:oxidized_cut_copper_stairs";
  MinecraftItemTypes2["PackedIce"] = "minecraft:packed_ice";
  MinecraftItemTypes2["PackedMud"] = "minecraft:packed_mud";
  MinecraftItemTypes2["Painting"] = "minecraft:painting";
  MinecraftItemTypes2["PandaSpawnEgg"] = "minecraft:panda_spawn_egg";
  MinecraftItemTypes2["Paper"] = "minecraft:paper";
  MinecraftItemTypes2["ParrotSpawnEgg"] = "minecraft:parrot_spawn_egg";
  MinecraftItemTypes2["PearlescentFroglight"] = "minecraft:pearlescent_froglight";
  MinecraftItemTypes2["Peony"] = "minecraft:peony";
  MinecraftItemTypes2["PetrifiedOakSlab"] = "minecraft:petrified_oak_slab";
  MinecraftItemTypes2["PhantomMembrane"] = "minecraft:phantom_membrane";
  MinecraftItemTypes2["PhantomSpawnEgg"] = "minecraft:phantom_spawn_egg";
  MinecraftItemTypes2["PigSpawnEgg"] = "minecraft:pig_spawn_egg";
  MinecraftItemTypes2["PiglinBannerPattern"] = "minecraft:piglin_banner_pattern";
  MinecraftItemTypes2["PiglinBruteSpawnEgg"] = "minecraft:piglin_brute_spawn_egg";
  MinecraftItemTypes2["PiglinSpawnEgg"] = "minecraft:piglin_spawn_egg";
  MinecraftItemTypes2["PillagerSpawnEgg"] = "minecraft:pillager_spawn_egg";
  MinecraftItemTypes2["PinkCandle"] = "minecraft:pink_candle";
  MinecraftItemTypes2["PinkCarpet"] = "minecraft:pink_carpet";
  MinecraftItemTypes2["PinkConcrete"] = "minecraft:pink_concrete";
  MinecraftItemTypes2["PinkConcretePowder"] = "minecraft:pink_concrete_powder";
  MinecraftItemTypes2["PinkDye"] = "minecraft:pink_dye";
  MinecraftItemTypes2["PinkGlazedTerracotta"] = "minecraft:pink_glazed_terracotta";
  MinecraftItemTypes2["PinkPetals"] = "minecraft:pink_petals";
  MinecraftItemTypes2["PinkShulkerBox"] = "minecraft:pink_shulker_box";
  MinecraftItemTypes2["PinkStainedGlass"] = "minecraft:pink_stained_glass";
  MinecraftItemTypes2["PinkStainedGlassPane"] = "minecraft:pink_stained_glass_pane";
  MinecraftItemTypes2["PinkTerracotta"] = "minecraft:pink_terracotta";
  MinecraftItemTypes2["PinkTulip"] = "minecraft:pink_tulip";
  MinecraftItemTypes2["PinkWool"] = "minecraft:pink_wool";
  MinecraftItemTypes2["Piston"] = "minecraft:piston";
  MinecraftItemTypes2["PitcherPlant"] = "minecraft:pitcher_plant";
  MinecraftItemTypes2["PitcherPod"] = "minecraft:pitcher_pod";
  MinecraftItemTypes2["PlentyPotterySherd"] = "minecraft:plenty_pottery_sherd";
  MinecraftItemTypes2["Podzol"] = "minecraft:podzol";
  MinecraftItemTypes2["PointedDripstone"] = "minecraft:pointed_dripstone";
  MinecraftItemTypes2["PoisonousPotato"] = "minecraft:poisonous_potato";
  MinecraftItemTypes2["PolarBearSpawnEgg"] = "minecraft:polar_bear_spawn_egg";
  MinecraftItemTypes2["PolishedAndesite"] = "minecraft:polished_andesite";
  MinecraftItemTypes2["PolishedAndesiteSlab"] = "minecraft:polished_andesite_slab";
  MinecraftItemTypes2["PolishedAndesiteStairs"] = "minecraft:polished_andesite_stairs";
  MinecraftItemTypes2["PolishedBasalt"] = "minecraft:polished_basalt";
  MinecraftItemTypes2["PolishedBlackstone"] = "minecraft:polished_blackstone";
  MinecraftItemTypes2["PolishedBlackstoneBrickSlab"] = "minecraft:polished_blackstone_brick_slab";
  MinecraftItemTypes2["PolishedBlackstoneBrickStairs"] = "minecraft:polished_blackstone_brick_stairs";
  MinecraftItemTypes2["PolishedBlackstoneBrickWall"] = "minecraft:polished_blackstone_brick_wall";
  MinecraftItemTypes2["PolishedBlackstoneBricks"] = "minecraft:polished_blackstone_bricks";
  MinecraftItemTypes2["PolishedBlackstoneButton"] = "minecraft:polished_blackstone_button";
  MinecraftItemTypes2["PolishedBlackstonePressurePlate"] = "minecraft:polished_blackstone_pressure_plate";
  MinecraftItemTypes2["PolishedBlackstoneSlab"] = "minecraft:polished_blackstone_slab";
  MinecraftItemTypes2["PolishedBlackstoneStairs"] = "minecraft:polished_blackstone_stairs";
  MinecraftItemTypes2["PolishedBlackstoneWall"] = "minecraft:polished_blackstone_wall";
  MinecraftItemTypes2["PolishedDeepslate"] = "minecraft:polished_deepslate";
  MinecraftItemTypes2["PolishedDeepslateSlab"] = "minecraft:polished_deepslate_slab";
  MinecraftItemTypes2["PolishedDeepslateStairs"] = "minecraft:polished_deepslate_stairs";
  MinecraftItemTypes2["PolishedDeepslateWall"] = "minecraft:polished_deepslate_wall";
  MinecraftItemTypes2["PolishedDiorite"] = "minecraft:polished_diorite";
  MinecraftItemTypes2["PolishedDioriteSlab"] = "minecraft:polished_diorite_slab";
  MinecraftItemTypes2["PolishedDioriteStairs"] = "minecraft:polished_diorite_stairs";
  MinecraftItemTypes2["PolishedGranite"] = "minecraft:polished_granite";
  MinecraftItemTypes2["PolishedGraniteSlab"] = "minecraft:polished_granite_slab";
  MinecraftItemTypes2["PolishedGraniteStairs"] = "minecraft:polished_granite_stairs";
  MinecraftItemTypes2["PolishedTuff"] = "minecraft:polished_tuff";
  MinecraftItemTypes2["PolishedTuffSlab"] = "minecraft:polished_tuff_slab";
  MinecraftItemTypes2["PolishedTuffStairs"] = "minecraft:polished_tuff_stairs";
  MinecraftItemTypes2["PolishedTuffWall"] = "minecraft:polished_tuff_wall";
  MinecraftItemTypes2["PoppedChorusFruit"] = "minecraft:popped_chorus_fruit";
  MinecraftItemTypes2["Poppy"] = "minecraft:poppy";
  MinecraftItemTypes2["Porkchop"] = "minecraft:porkchop";
  MinecraftItemTypes2["Potato"] = "minecraft:potato";
  MinecraftItemTypes2["Potion"] = "minecraft:potion";
  MinecraftItemTypes2["PowderSnowBucket"] = "minecraft:powder_snow_bucket";
  MinecraftItemTypes2["Prismarine"] = "minecraft:prismarine";
  MinecraftItemTypes2["PrismarineBrickSlab"] = "minecraft:prismarine_brick_slab";
  MinecraftItemTypes2["PrismarineBricks"] = "minecraft:prismarine_bricks";
  MinecraftItemTypes2["PrismarineBricksStairs"] = "minecraft:prismarine_bricks_stairs";
  MinecraftItemTypes2["PrismarineCrystals"] = "minecraft:prismarine_crystals";
  MinecraftItemTypes2["PrismarineShard"] = "minecraft:prismarine_shard";
  MinecraftItemTypes2["PrismarineSlab"] = "minecraft:prismarine_slab";
  MinecraftItemTypes2["PrismarineStairs"] = "minecraft:prismarine_stairs";
  MinecraftItemTypes2["PrizePotterySherd"] = "minecraft:prize_pottery_sherd";
  MinecraftItemTypes2["Pufferfish"] = "minecraft:pufferfish";
  MinecraftItemTypes2["PufferfishBucket"] = "minecraft:pufferfish_bucket";
  MinecraftItemTypes2["PufferfishSpawnEgg"] = "minecraft:pufferfish_spawn_egg";
  MinecraftItemTypes2["Pumpkin"] = "minecraft:pumpkin";
  MinecraftItemTypes2["PumpkinPie"] = "minecraft:pumpkin_pie";
  MinecraftItemTypes2["PumpkinSeeds"] = "minecraft:pumpkin_seeds";
  MinecraftItemTypes2["PurpleCandle"] = "minecraft:purple_candle";
  MinecraftItemTypes2["PurpleCarpet"] = "minecraft:purple_carpet";
  MinecraftItemTypes2["PurpleConcrete"] = "minecraft:purple_concrete";
  MinecraftItemTypes2["PurpleConcretePowder"] = "minecraft:purple_concrete_powder";
  MinecraftItemTypes2["PurpleDye"] = "minecraft:purple_dye";
  MinecraftItemTypes2["PurpleGlazedTerracotta"] = "minecraft:purple_glazed_terracotta";
  MinecraftItemTypes2["PurpleShulkerBox"] = "minecraft:purple_shulker_box";
  MinecraftItemTypes2["PurpleStainedGlass"] = "minecraft:purple_stained_glass";
  MinecraftItemTypes2["PurpleStainedGlassPane"] = "minecraft:purple_stained_glass_pane";
  MinecraftItemTypes2["PurpleTerracotta"] = "minecraft:purple_terracotta";
  MinecraftItemTypes2["PurpleWool"] = "minecraft:purple_wool";
  MinecraftItemTypes2["PurpurBlock"] = "minecraft:purpur_block";
  MinecraftItemTypes2["PurpurSlab"] = "minecraft:purpur_slab";
  MinecraftItemTypes2["PurpurStairs"] = "minecraft:purpur_stairs";
  MinecraftItemTypes2["Quartz"] = "minecraft:quartz";
  MinecraftItemTypes2["QuartzBlock"] = "minecraft:quartz_block";
  MinecraftItemTypes2["QuartzBricks"] = "minecraft:quartz_bricks";
  MinecraftItemTypes2["QuartzOre"] = "minecraft:quartz_ore";
  MinecraftItemTypes2["QuartzPillar"] = "minecraft:quartz_pillar";
  MinecraftItemTypes2["QuartzSlab"] = "minecraft:quartz_slab";
  MinecraftItemTypes2["QuartzStairs"] = "minecraft:quartz_stairs";
  MinecraftItemTypes2["Rabbit"] = "minecraft:rabbit";
  MinecraftItemTypes2["RabbitFoot"] = "minecraft:rabbit_foot";
  MinecraftItemTypes2["RabbitHide"] = "minecraft:rabbit_hide";
  MinecraftItemTypes2["RabbitSpawnEgg"] = "minecraft:rabbit_spawn_egg";
  MinecraftItemTypes2["RabbitStew"] = "minecraft:rabbit_stew";
  MinecraftItemTypes2["Rail"] = "minecraft:rail";
  MinecraftItemTypes2["RaiserArmorTrimSmithingTemplate"] = "minecraft:raiser_armor_trim_smithing_template";
  MinecraftItemTypes2["RavagerSpawnEgg"] = "minecraft:ravager_spawn_egg";
  MinecraftItemTypes2["RawCopper"] = "minecraft:raw_copper";
  MinecraftItemTypes2["RawCopperBlock"] = "minecraft:raw_copper_block";
  MinecraftItemTypes2["RawGold"] = "minecraft:raw_gold";
  MinecraftItemTypes2["RawGoldBlock"] = "minecraft:raw_gold_block";
  MinecraftItemTypes2["RawIron"] = "minecraft:raw_iron";
  MinecraftItemTypes2["RawIronBlock"] = "minecraft:raw_iron_block";
  MinecraftItemTypes2["RecoveryCompass"] = "minecraft:recovery_compass";
  MinecraftItemTypes2["RedCandle"] = "minecraft:red_candle";
  MinecraftItemTypes2["RedCarpet"] = "minecraft:red_carpet";
  MinecraftItemTypes2["RedConcrete"] = "minecraft:red_concrete";
  MinecraftItemTypes2["RedConcretePowder"] = "minecraft:red_concrete_powder";
  MinecraftItemTypes2["RedDye"] = "minecraft:red_dye";
  MinecraftItemTypes2["RedGlazedTerracotta"] = "minecraft:red_glazed_terracotta";
  MinecraftItemTypes2["RedMushroom"] = "minecraft:red_mushroom";
  MinecraftItemTypes2["RedMushroomBlock"] = "minecraft:red_mushroom_block";
  MinecraftItemTypes2["RedNetherBrick"] = "minecraft:red_nether_brick";
  MinecraftItemTypes2["RedNetherBrickSlab"] = "minecraft:red_nether_brick_slab";
  MinecraftItemTypes2["RedNetherBrickStairs"] = "minecraft:red_nether_brick_stairs";
  MinecraftItemTypes2["RedSand"] = "minecraft:red_sand";
  MinecraftItemTypes2["RedSandstone"] = "minecraft:red_sandstone";
  MinecraftItemTypes2["RedSandstoneSlab"] = "minecraft:red_sandstone_slab";
  MinecraftItemTypes2["RedSandstoneStairs"] = "minecraft:red_sandstone_stairs";
  MinecraftItemTypes2["RedShulkerBox"] = "minecraft:red_shulker_box";
  MinecraftItemTypes2["RedStainedGlass"] = "minecraft:red_stained_glass";
  MinecraftItemTypes2["RedStainedGlassPane"] = "minecraft:red_stained_glass_pane";
  MinecraftItemTypes2["RedTerracotta"] = "minecraft:red_terracotta";
  MinecraftItemTypes2["RedTulip"] = "minecraft:red_tulip";
  MinecraftItemTypes2["RedWool"] = "minecraft:red_wool";
  MinecraftItemTypes2["Redstone"] = "minecraft:redstone";
  MinecraftItemTypes2["RedstoneBlock"] = "minecraft:redstone_block";
  MinecraftItemTypes2["RedstoneLamp"] = "minecraft:redstone_lamp";
  MinecraftItemTypes2["RedstoneOre"] = "minecraft:redstone_ore";
  MinecraftItemTypes2["RedstoneTorch"] = "minecraft:redstone_torch";
  MinecraftItemTypes2["ReinforcedDeepslate"] = "minecraft:reinforced_deepslate";
  MinecraftItemTypes2["Repeater"] = "minecraft:repeater";
  MinecraftItemTypes2["RepeatingCommandBlock"] = "minecraft:repeating_command_block";
  MinecraftItemTypes2["RespawnAnchor"] = "minecraft:respawn_anchor";
  MinecraftItemTypes2["RibArmorTrimSmithingTemplate"] = "minecraft:rib_armor_trim_smithing_template";
  MinecraftItemTypes2["RoseBush"] = "minecraft:rose_bush";
  MinecraftItemTypes2["RottenFlesh"] = "minecraft:rotten_flesh";
  MinecraftItemTypes2["Saddle"] = "minecraft:saddle";
  MinecraftItemTypes2["Salmon"] = "minecraft:salmon";
  MinecraftItemTypes2["SalmonBucket"] = "minecraft:salmon_bucket";
  MinecraftItemTypes2["SalmonSpawnEgg"] = "minecraft:salmon_spawn_egg";
  MinecraftItemTypes2["Sand"] = "minecraft:sand";
  MinecraftItemTypes2["Sandstone"] = "minecraft:sandstone";
  MinecraftItemTypes2["SandstoneSlab"] = "minecraft:sandstone_slab";
  MinecraftItemTypes2["SandstoneStairs"] = "minecraft:sandstone_stairs";
  MinecraftItemTypes2["Scaffolding"] = "minecraft:scaffolding";
  MinecraftItemTypes2["ScrapePotterySherd"] = "minecraft:scrape_pottery_sherd";
  MinecraftItemTypes2["Sculk"] = "minecraft:sculk";
  MinecraftItemTypes2["SculkCatalyst"] = "minecraft:sculk_catalyst";
  MinecraftItemTypes2["SculkSensor"] = "minecraft:sculk_sensor";
  MinecraftItemTypes2["SculkShrieker"] = "minecraft:sculk_shrieker";
  MinecraftItemTypes2["SculkVein"] = "minecraft:sculk_vein";
  MinecraftItemTypes2["SeaLantern"] = "minecraft:sea_lantern";
  MinecraftItemTypes2["SeaPickle"] = "minecraft:sea_pickle";
  MinecraftItemTypes2["Seagrass"] = "minecraft:seagrass";
  MinecraftItemTypes2["SentryArmorTrimSmithingTemplate"] = "minecraft:sentry_armor_trim_smithing_template";
  MinecraftItemTypes2["ShaperArmorTrimSmithingTemplate"] = "minecraft:shaper_armor_trim_smithing_template";
  MinecraftItemTypes2["SheafPotterySherd"] = "minecraft:sheaf_pottery_sherd";
  MinecraftItemTypes2["Shears"] = "minecraft:shears";
  MinecraftItemTypes2["SheepSpawnEgg"] = "minecraft:sheep_spawn_egg";
  MinecraftItemTypes2["ShelterPotterySherd"] = "minecraft:shelter_pottery_sherd";
  MinecraftItemTypes2["Shield"] = "minecraft:shield";
  MinecraftItemTypes2["ShortGrass"] = "minecraft:short_grass";
  MinecraftItemTypes2["Shroomlight"] = "minecraft:shroomlight";
  MinecraftItemTypes2["ShulkerShell"] = "minecraft:shulker_shell";
  MinecraftItemTypes2["ShulkerSpawnEgg"] = "minecraft:shulker_spawn_egg";
  MinecraftItemTypes2["SilenceArmorTrimSmithingTemplate"] = "minecraft:silence_armor_trim_smithing_template";
  MinecraftItemTypes2["SilverGlazedTerracotta"] = "minecraft:silver_glazed_terracotta";
  MinecraftItemTypes2["SilverfishSpawnEgg"] = "minecraft:silverfish_spawn_egg";
  MinecraftItemTypes2["SkeletonHorseSpawnEgg"] = "minecraft:skeleton_horse_spawn_egg";
  MinecraftItemTypes2["SkeletonSpawnEgg"] = "minecraft:skeleton_spawn_egg";
  MinecraftItemTypes2["Skull"] = "minecraft:skull";
  MinecraftItemTypes2["SkullBannerPattern"] = "minecraft:skull_banner_pattern";
  MinecraftItemTypes2["SkullPotterySherd"] = "minecraft:skull_pottery_sherd";
  MinecraftItemTypes2["Slime"] = "minecraft:slime";
  MinecraftItemTypes2["SlimeBall"] = "minecraft:slime_ball";
  MinecraftItemTypes2["SlimeSpawnEgg"] = "minecraft:slime_spawn_egg";
  MinecraftItemTypes2["SmallAmethystBud"] = "minecraft:small_amethyst_bud";
  MinecraftItemTypes2["SmallDripleafBlock"] = "minecraft:small_dripleaf_block";
  MinecraftItemTypes2["SmithingTable"] = "minecraft:smithing_table";
  MinecraftItemTypes2["Smoker"] = "minecraft:smoker";
  MinecraftItemTypes2["SmoothBasalt"] = "minecraft:smooth_basalt";
  MinecraftItemTypes2["SmoothQuartz"] = "minecraft:smooth_quartz";
  MinecraftItemTypes2["SmoothQuartzSlab"] = "minecraft:smooth_quartz_slab";
  MinecraftItemTypes2["SmoothQuartzStairs"] = "minecraft:smooth_quartz_stairs";
  MinecraftItemTypes2["SmoothRedSandstone"] = "minecraft:smooth_red_sandstone";
  MinecraftItemTypes2["SmoothRedSandstoneSlab"] = "minecraft:smooth_red_sandstone_slab";
  MinecraftItemTypes2["SmoothRedSandstoneStairs"] = "minecraft:smooth_red_sandstone_stairs";
  MinecraftItemTypes2["SmoothSandstone"] = "minecraft:smooth_sandstone";
  MinecraftItemTypes2["SmoothSandstoneSlab"] = "minecraft:smooth_sandstone_slab";
  MinecraftItemTypes2["SmoothSandstoneStairs"] = "minecraft:smooth_sandstone_stairs";
  MinecraftItemTypes2["SmoothStone"] = "minecraft:smooth_stone";
  MinecraftItemTypes2["SmoothStoneSlab"] = "minecraft:smooth_stone_slab";
  MinecraftItemTypes2["SnifferEgg"] = "minecraft:sniffer_egg";
  MinecraftItemTypes2["SnifferSpawnEgg"] = "minecraft:sniffer_spawn_egg";
  MinecraftItemTypes2["SnortPotterySherd"] = "minecraft:snort_pottery_sherd";
  MinecraftItemTypes2["SnoutArmorTrimSmithingTemplate"] = "minecraft:snout_armor_trim_smithing_template";
  MinecraftItemTypes2["Snow"] = "minecraft:snow";
  MinecraftItemTypes2["SnowGolemSpawnEgg"] = "minecraft:snow_golem_spawn_egg";
  MinecraftItemTypes2["SnowLayer"] = "minecraft:snow_layer";
  MinecraftItemTypes2["Snowball"] = "minecraft:snowball";
  MinecraftItemTypes2["SoulCampfire"] = "minecraft:soul_campfire";
  MinecraftItemTypes2["SoulLantern"] = "minecraft:soul_lantern";
  MinecraftItemTypes2["SoulSand"] = "minecraft:soul_sand";
  MinecraftItemTypes2["SoulSoil"] = "minecraft:soul_soil";
  MinecraftItemTypes2["SoulTorch"] = "minecraft:soul_torch";
  MinecraftItemTypes2["SpiderEye"] = "minecraft:spider_eye";
  MinecraftItemTypes2["SpiderSpawnEgg"] = "minecraft:spider_spawn_egg";
  MinecraftItemTypes2["SpireArmorTrimSmithingTemplate"] = "minecraft:spire_armor_trim_smithing_template";
  MinecraftItemTypes2["SplashPotion"] = "minecraft:splash_potion";
  MinecraftItemTypes2["Sponge"] = "minecraft:sponge";
  MinecraftItemTypes2["SporeBlossom"] = "minecraft:spore_blossom";
  MinecraftItemTypes2["SpruceBoat"] = "minecraft:spruce_boat";
  MinecraftItemTypes2["SpruceButton"] = "minecraft:spruce_button";
  MinecraftItemTypes2["SpruceChestBoat"] = "minecraft:spruce_chest_boat";
  MinecraftItemTypes2["SpruceDoor"] = "minecraft:spruce_door";
  MinecraftItemTypes2["SpruceFence"] = "minecraft:spruce_fence";
  MinecraftItemTypes2["SpruceFenceGate"] = "minecraft:spruce_fence_gate";
  MinecraftItemTypes2["SpruceHangingSign"] = "minecraft:spruce_hanging_sign";
  MinecraftItemTypes2["SpruceLeaves"] = "minecraft:spruce_leaves";
  MinecraftItemTypes2["SpruceLog"] = "minecraft:spruce_log";
  MinecraftItemTypes2["SprucePlanks"] = "minecraft:spruce_planks";
  MinecraftItemTypes2["SprucePressurePlate"] = "minecraft:spruce_pressure_plate";
  MinecraftItemTypes2["SpruceSapling"] = "minecraft:spruce_sapling";
  MinecraftItemTypes2["SpruceSign"] = "minecraft:spruce_sign";
  MinecraftItemTypes2["SpruceSlab"] = "minecraft:spruce_slab";
  MinecraftItemTypes2["SpruceStairs"] = "minecraft:spruce_stairs";
  MinecraftItemTypes2["SpruceTrapdoor"] = "minecraft:spruce_trapdoor";
  MinecraftItemTypes2["SpruceWood"] = "minecraft:spruce_wood";
  MinecraftItemTypes2["Spyglass"] = "minecraft:spyglass";
  MinecraftItemTypes2["SquidSpawnEgg"] = "minecraft:squid_spawn_egg";
  MinecraftItemTypes2["Stick"] = "minecraft:stick";
  MinecraftItemTypes2["StickyPiston"] = "minecraft:sticky_piston";
  MinecraftItemTypes2["Stone"] = "minecraft:stone";
  MinecraftItemTypes2["StoneAxe"] = "minecraft:stone_axe";
  MinecraftItemTypes2["StoneBrickSlab"] = "minecraft:stone_brick_slab";
  MinecraftItemTypes2["StoneBrickStairs"] = "minecraft:stone_brick_stairs";
  MinecraftItemTypes2["StoneBricks"] = "minecraft:stone_bricks";
  MinecraftItemTypes2["StoneButton"] = "minecraft:stone_button";
  MinecraftItemTypes2["StoneHoe"] = "minecraft:stone_hoe";
  MinecraftItemTypes2["StonePickaxe"] = "minecraft:stone_pickaxe";
  MinecraftItemTypes2["StonePressurePlate"] = "minecraft:stone_pressure_plate";
  MinecraftItemTypes2["StoneShovel"] = "minecraft:stone_shovel";
  MinecraftItemTypes2["StoneStairs"] = "minecraft:stone_stairs";
  MinecraftItemTypes2["StoneSword"] = "minecraft:stone_sword";
  MinecraftItemTypes2["StonecutterBlock"] = "minecraft:stonecutter_block";
  MinecraftItemTypes2["StraySpawnEgg"] = "minecraft:stray_spawn_egg";
  MinecraftItemTypes2["StriderSpawnEgg"] = "minecraft:strider_spawn_egg";
  MinecraftItemTypes2["String"] = "minecraft:string";
  MinecraftItemTypes2["StrippedAcaciaLog"] = "minecraft:stripped_acacia_log";
  MinecraftItemTypes2["StrippedAcaciaWood"] = "minecraft:stripped_acacia_wood";
  MinecraftItemTypes2["StrippedBambooBlock"] = "minecraft:stripped_bamboo_block";
  MinecraftItemTypes2["StrippedBirchLog"] = "minecraft:stripped_birch_log";
  MinecraftItemTypes2["StrippedBirchWood"] = "minecraft:stripped_birch_wood";
  MinecraftItemTypes2["StrippedCherryLog"] = "minecraft:stripped_cherry_log";
  MinecraftItemTypes2["StrippedCherryWood"] = "minecraft:stripped_cherry_wood";
  MinecraftItemTypes2["StrippedCrimsonHyphae"] = "minecraft:stripped_crimson_hyphae";
  MinecraftItemTypes2["StrippedCrimsonStem"] = "minecraft:stripped_crimson_stem";
  MinecraftItemTypes2["StrippedDarkOakLog"] = "minecraft:stripped_dark_oak_log";
  MinecraftItemTypes2["StrippedDarkOakWood"] = "minecraft:stripped_dark_oak_wood";
  MinecraftItemTypes2["StrippedJungleLog"] = "minecraft:stripped_jungle_log";
  MinecraftItemTypes2["StrippedJungleWood"] = "minecraft:stripped_jungle_wood";
  MinecraftItemTypes2["StrippedMangroveLog"] = "minecraft:stripped_mangrove_log";
  MinecraftItemTypes2["StrippedMangroveWood"] = "minecraft:stripped_mangrove_wood";
  MinecraftItemTypes2["StrippedOakLog"] = "minecraft:stripped_oak_log";
  MinecraftItemTypes2["StrippedOakWood"] = "minecraft:stripped_oak_wood";
  MinecraftItemTypes2["StrippedSpruceLog"] = "minecraft:stripped_spruce_log";
  MinecraftItemTypes2["StrippedSpruceWood"] = "minecraft:stripped_spruce_wood";
  MinecraftItemTypes2["StrippedWarpedHyphae"] = "minecraft:stripped_warped_hyphae";
  MinecraftItemTypes2["StrippedWarpedStem"] = "minecraft:stripped_warped_stem";
  MinecraftItemTypes2["StructureBlock"] = "minecraft:structure_block";
  MinecraftItemTypes2["StructureVoid"] = "minecraft:structure_void";
  MinecraftItemTypes2["Sugar"] = "minecraft:sugar";
  MinecraftItemTypes2["SugarCane"] = "minecraft:sugar_cane";
  MinecraftItemTypes2["Sunflower"] = "minecraft:sunflower";
  MinecraftItemTypes2["SuspiciousGravel"] = "minecraft:suspicious_gravel";
  MinecraftItemTypes2["SuspiciousSand"] = "minecraft:suspicious_sand";
  MinecraftItemTypes2["SuspiciousStew"] = "minecraft:suspicious_stew";
  MinecraftItemTypes2["SweetBerries"] = "minecraft:sweet_berries";
  MinecraftItemTypes2["TadpoleBucket"] = "minecraft:tadpole_bucket";
  MinecraftItemTypes2["TadpoleSpawnEgg"] = "minecraft:tadpole_spawn_egg";
  MinecraftItemTypes2["TallGrass"] = "minecraft:tall_grass";
  MinecraftItemTypes2["Target"] = "minecraft:target";
  MinecraftItemTypes2["TideArmorTrimSmithingTemplate"] = "minecraft:tide_armor_trim_smithing_template";
  MinecraftItemTypes2["TintedGlass"] = "minecraft:tinted_glass";
  MinecraftItemTypes2["Tnt"] = "minecraft:tnt";
  MinecraftItemTypes2["TntMinecart"] = "minecraft:tnt_minecart";
  MinecraftItemTypes2["Torch"] = "minecraft:torch";
  MinecraftItemTypes2["Torchflower"] = "minecraft:torchflower";
  MinecraftItemTypes2["TorchflowerSeeds"] = "minecraft:torchflower_seeds";
  MinecraftItemTypes2["TotemOfUndying"] = "minecraft:totem_of_undying";
  MinecraftItemTypes2["TraderLlamaSpawnEgg"] = "minecraft:trader_llama_spawn_egg";
  MinecraftItemTypes2["Trapdoor"] = "minecraft:trapdoor";
  MinecraftItemTypes2["TrappedChest"] = "minecraft:trapped_chest";
  MinecraftItemTypes2["TrialKey"] = "minecraft:trial_key";
  MinecraftItemTypes2["TrialSpawner"] = "minecraft:trial_spawner";
  MinecraftItemTypes2["Trident"] = "minecraft:trident";
  MinecraftItemTypes2["TripwireHook"] = "minecraft:tripwire_hook";
  MinecraftItemTypes2["TropicalFish"] = "minecraft:tropical_fish";
  MinecraftItemTypes2["TropicalFishBucket"] = "minecraft:tropical_fish_bucket";
  MinecraftItemTypes2["TropicalFishSpawnEgg"] = "minecraft:tropical_fish_spawn_egg";
  MinecraftItemTypes2["TubeCoral"] = "minecraft:tube_coral";
  MinecraftItemTypes2["TubeCoralBlock"] = "minecraft:tube_coral_block";
  MinecraftItemTypes2["TubeCoralFan"] = "minecraft:tube_coral_fan";
  MinecraftItemTypes2["Tuff"] = "minecraft:tuff";
  MinecraftItemTypes2["TuffBrickSlab"] = "minecraft:tuff_brick_slab";
  MinecraftItemTypes2["TuffBrickStairs"] = "minecraft:tuff_brick_stairs";
  MinecraftItemTypes2["TuffBrickWall"] = "minecraft:tuff_brick_wall";
  MinecraftItemTypes2["TuffBricks"] = "minecraft:tuff_bricks";
  MinecraftItemTypes2["TuffSlab"] = "minecraft:tuff_slab";
  MinecraftItemTypes2["TuffStairs"] = "minecraft:tuff_stairs";
  MinecraftItemTypes2["TuffWall"] = "minecraft:tuff_wall";
  MinecraftItemTypes2["TurtleEgg"] = "minecraft:turtle_egg";
  MinecraftItemTypes2["TurtleHelmet"] = "minecraft:turtle_helmet";
  MinecraftItemTypes2["TurtleScute"] = "minecraft:turtle_scute";
  MinecraftItemTypes2["TurtleSpawnEgg"] = "minecraft:turtle_spawn_egg";
  MinecraftItemTypes2["TwistingVines"] = "minecraft:twisting_vines";
  MinecraftItemTypes2["UndyedShulkerBox"] = "minecraft:undyed_shulker_box";
  MinecraftItemTypes2["Vault"] = "minecraft:vault";
  MinecraftItemTypes2["VerdantFroglight"] = "minecraft:verdant_froglight";
  MinecraftItemTypes2["VexArmorTrimSmithingTemplate"] = "minecraft:vex_armor_trim_smithing_template";
  MinecraftItemTypes2["VexSpawnEgg"] = "minecraft:vex_spawn_egg";
  MinecraftItemTypes2["VillagerSpawnEgg"] = "minecraft:villager_spawn_egg";
  MinecraftItemTypes2["VindicatorSpawnEgg"] = "minecraft:vindicator_spawn_egg";
  MinecraftItemTypes2["Vine"] = "minecraft:vine";
  MinecraftItemTypes2["WanderingTraderSpawnEgg"] = "minecraft:wandering_trader_spawn_egg";
  MinecraftItemTypes2["WardArmorTrimSmithingTemplate"] = "minecraft:ward_armor_trim_smithing_template";
  MinecraftItemTypes2["WardenSpawnEgg"] = "minecraft:warden_spawn_egg";
  MinecraftItemTypes2["WarpedButton"] = "minecraft:warped_button";
  MinecraftItemTypes2["WarpedDoor"] = "minecraft:warped_door";
  MinecraftItemTypes2["WarpedFence"] = "minecraft:warped_fence";
  MinecraftItemTypes2["WarpedFenceGate"] = "minecraft:warped_fence_gate";
  MinecraftItemTypes2["WarpedFungus"] = "minecraft:warped_fungus";
  MinecraftItemTypes2["WarpedFungusOnAStick"] = "minecraft:warped_fungus_on_a_stick";
  MinecraftItemTypes2["WarpedHangingSign"] = "minecraft:warped_hanging_sign";
  MinecraftItemTypes2["WarpedHyphae"] = "minecraft:warped_hyphae";
  MinecraftItemTypes2["WarpedNylium"] = "minecraft:warped_nylium";
  MinecraftItemTypes2["WarpedPlanks"] = "minecraft:warped_planks";
  MinecraftItemTypes2["WarpedPressurePlate"] = "minecraft:warped_pressure_plate";
  MinecraftItemTypes2["WarpedRoots"] = "minecraft:warped_roots";
  MinecraftItemTypes2["WarpedSign"] = "minecraft:warped_sign";
  MinecraftItemTypes2["WarpedSlab"] = "minecraft:warped_slab";
  MinecraftItemTypes2["WarpedStairs"] = "minecraft:warped_stairs";
  MinecraftItemTypes2["WarpedStem"] = "minecraft:warped_stem";
  MinecraftItemTypes2["WarpedTrapdoor"] = "minecraft:warped_trapdoor";
  MinecraftItemTypes2["WarpedWartBlock"] = "minecraft:warped_wart_block";
  MinecraftItemTypes2["WaterBucket"] = "minecraft:water_bucket";
  MinecraftItemTypes2["Waterlily"] = "minecraft:waterlily";
  MinecraftItemTypes2["WaxedChiseledCopper"] = "minecraft:waxed_chiseled_copper";
  MinecraftItemTypes2["WaxedCopper"] = "minecraft:waxed_copper";
  MinecraftItemTypes2["WaxedCopperBulb"] = "minecraft:waxed_copper_bulb";
  MinecraftItemTypes2["WaxedCopperDoor"] = "minecraft:waxed_copper_door";
  MinecraftItemTypes2["WaxedCopperGrate"] = "minecraft:waxed_copper_grate";
  MinecraftItemTypes2["WaxedCopperTrapdoor"] = "minecraft:waxed_copper_trapdoor";
  MinecraftItemTypes2["WaxedCutCopper"] = "minecraft:waxed_cut_copper";
  MinecraftItemTypes2["WaxedCutCopperSlab"] = "minecraft:waxed_cut_copper_slab";
  MinecraftItemTypes2["WaxedCutCopperStairs"] = "minecraft:waxed_cut_copper_stairs";
  MinecraftItemTypes2["WaxedExposedChiseledCopper"] = "minecraft:waxed_exposed_chiseled_copper";
  MinecraftItemTypes2["WaxedExposedCopper"] = "minecraft:waxed_exposed_copper";
  MinecraftItemTypes2["WaxedExposedCopperBulb"] = "minecraft:waxed_exposed_copper_bulb";
  MinecraftItemTypes2["WaxedExposedCopperDoor"] = "minecraft:waxed_exposed_copper_door";
  MinecraftItemTypes2["WaxedExposedCopperGrate"] = "minecraft:waxed_exposed_copper_grate";
  MinecraftItemTypes2["WaxedExposedCopperTrapdoor"] = "minecraft:waxed_exposed_copper_trapdoor";
  MinecraftItemTypes2["WaxedExposedCutCopper"] = "minecraft:waxed_exposed_cut_copper";
  MinecraftItemTypes2["WaxedExposedCutCopperSlab"] = "minecraft:waxed_exposed_cut_copper_slab";
  MinecraftItemTypes2["WaxedExposedCutCopperStairs"] = "minecraft:waxed_exposed_cut_copper_stairs";
  MinecraftItemTypes2["WaxedOxidizedChiseledCopper"] = "minecraft:waxed_oxidized_chiseled_copper";
  MinecraftItemTypes2["WaxedOxidizedCopper"] = "minecraft:waxed_oxidized_copper";
  MinecraftItemTypes2["WaxedOxidizedCopperBulb"] = "minecraft:waxed_oxidized_copper_bulb";
  MinecraftItemTypes2["WaxedOxidizedCopperDoor"] = "minecraft:waxed_oxidized_copper_door";
  MinecraftItemTypes2["WaxedOxidizedCopperGrate"] = "minecraft:waxed_oxidized_copper_grate";
  MinecraftItemTypes2["WaxedOxidizedCopperTrapdoor"] = "minecraft:waxed_oxidized_copper_trapdoor";
  MinecraftItemTypes2["WaxedOxidizedCutCopper"] = "minecraft:waxed_oxidized_cut_copper";
  MinecraftItemTypes2["WaxedOxidizedCutCopperSlab"] = "minecraft:waxed_oxidized_cut_copper_slab";
  MinecraftItemTypes2["WaxedOxidizedCutCopperStairs"] = "minecraft:waxed_oxidized_cut_copper_stairs";
  MinecraftItemTypes2["WaxedWeatheredChiseledCopper"] = "minecraft:waxed_weathered_chiseled_copper";
  MinecraftItemTypes2["WaxedWeatheredCopper"] = "minecraft:waxed_weathered_copper";
  MinecraftItemTypes2["WaxedWeatheredCopperBulb"] = "minecraft:waxed_weathered_copper_bulb";
  MinecraftItemTypes2["WaxedWeatheredCopperDoor"] = "minecraft:waxed_weathered_copper_door";
  MinecraftItemTypes2["WaxedWeatheredCopperGrate"] = "minecraft:waxed_weathered_copper_grate";
  MinecraftItemTypes2["WaxedWeatheredCopperTrapdoor"] = "minecraft:waxed_weathered_copper_trapdoor";
  MinecraftItemTypes2["WaxedWeatheredCutCopper"] = "minecraft:waxed_weathered_cut_copper";
  MinecraftItemTypes2["WaxedWeatheredCutCopperSlab"] = "minecraft:waxed_weathered_cut_copper_slab";
  MinecraftItemTypes2["WaxedWeatheredCutCopperStairs"] = "minecraft:waxed_weathered_cut_copper_stairs";
  MinecraftItemTypes2["WayfinderArmorTrimSmithingTemplate"] = "minecraft:wayfinder_armor_trim_smithing_template";
  MinecraftItemTypes2["WeatheredChiseledCopper"] = "minecraft:weathered_chiseled_copper";
  MinecraftItemTypes2["WeatheredCopper"] = "minecraft:weathered_copper";
  MinecraftItemTypes2["WeatheredCopperBulb"] = "minecraft:weathered_copper_bulb";
  MinecraftItemTypes2["WeatheredCopperDoor"] = "minecraft:weathered_copper_door";
  MinecraftItemTypes2["WeatheredCopperGrate"] = "minecraft:weathered_copper_grate";
  MinecraftItemTypes2["WeatheredCopperTrapdoor"] = "minecraft:weathered_copper_trapdoor";
  MinecraftItemTypes2["WeatheredCutCopper"] = "minecraft:weathered_cut_copper";
  MinecraftItemTypes2["WeatheredCutCopperSlab"] = "minecraft:weathered_cut_copper_slab";
  MinecraftItemTypes2["WeatheredCutCopperStairs"] = "minecraft:weathered_cut_copper_stairs";
  MinecraftItemTypes2["Web"] = "minecraft:web";
  MinecraftItemTypes2["WeepingVines"] = "minecraft:weeping_vines";
  MinecraftItemTypes2["Wheat"] = "minecraft:wheat";
  MinecraftItemTypes2["WheatSeeds"] = "minecraft:wheat_seeds";
  MinecraftItemTypes2["WhiteCandle"] = "minecraft:white_candle";
  MinecraftItemTypes2["WhiteCarpet"] = "minecraft:white_carpet";
  MinecraftItemTypes2["WhiteConcrete"] = "minecraft:white_concrete";
  MinecraftItemTypes2["WhiteConcretePowder"] = "minecraft:white_concrete_powder";
  MinecraftItemTypes2["WhiteDye"] = "minecraft:white_dye";
  MinecraftItemTypes2["WhiteGlazedTerracotta"] = "minecraft:white_glazed_terracotta";
  MinecraftItemTypes2["WhiteShulkerBox"] = "minecraft:white_shulker_box";
  MinecraftItemTypes2["WhiteStainedGlass"] = "minecraft:white_stained_glass";
  MinecraftItemTypes2["WhiteStainedGlassPane"] = "minecraft:white_stained_glass_pane";
  MinecraftItemTypes2["WhiteTerracotta"] = "minecraft:white_terracotta";
  MinecraftItemTypes2["WhiteTulip"] = "minecraft:white_tulip";
  MinecraftItemTypes2["WhiteWool"] = "minecraft:white_wool";
  MinecraftItemTypes2["WildArmorTrimSmithingTemplate"] = "minecraft:wild_armor_trim_smithing_template";
  MinecraftItemTypes2["WindCharge"] = "minecraft:wind_charge";
  MinecraftItemTypes2["WitchSpawnEgg"] = "minecraft:witch_spawn_egg";
  MinecraftItemTypes2["WitherRose"] = "minecraft:wither_rose";
  MinecraftItemTypes2["WitherSkeletonSpawnEgg"] = "minecraft:wither_skeleton_spawn_egg";
  MinecraftItemTypes2["WitherSpawnEgg"] = "minecraft:wither_spawn_egg";
  MinecraftItemTypes2["WolfArmor"] = "minecraft:wolf_armor";
  MinecraftItemTypes2["WolfSpawnEgg"] = "minecraft:wolf_spawn_egg";
  MinecraftItemTypes2["WoodenAxe"] = "minecraft:wooden_axe";
  MinecraftItemTypes2["WoodenButton"] = "minecraft:wooden_button";
  MinecraftItemTypes2["WoodenDoor"] = "minecraft:wooden_door";
  MinecraftItemTypes2["WoodenHoe"] = "minecraft:wooden_hoe";
  MinecraftItemTypes2["WoodenPickaxe"] = "minecraft:wooden_pickaxe";
  MinecraftItemTypes2["WoodenPressurePlate"] = "minecraft:wooden_pressure_plate";
  MinecraftItemTypes2["WoodenShovel"] = "minecraft:wooden_shovel";
  MinecraftItemTypes2["WoodenSword"] = "minecraft:wooden_sword";
  MinecraftItemTypes2["WritableBook"] = "minecraft:writable_book";
  MinecraftItemTypes2["YellowCandle"] = "minecraft:yellow_candle";
  MinecraftItemTypes2["YellowCarpet"] = "minecraft:yellow_carpet";
  MinecraftItemTypes2["YellowConcrete"] = "minecraft:yellow_concrete";
  MinecraftItemTypes2["YellowConcretePowder"] = "minecraft:yellow_concrete_powder";
  MinecraftItemTypes2["YellowDye"] = "minecraft:yellow_dye";
  MinecraftItemTypes2["YellowGlazedTerracotta"] = "minecraft:yellow_glazed_terracotta";
  MinecraftItemTypes2["YellowShulkerBox"] = "minecraft:yellow_shulker_box";
  MinecraftItemTypes2["YellowStainedGlass"] = "minecraft:yellow_stained_glass";
  MinecraftItemTypes2["YellowStainedGlassPane"] = "minecraft:yellow_stained_glass_pane";
  MinecraftItemTypes2["YellowTerracotta"] = "minecraft:yellow_terracotta";
  MinecraftItemTypes2["YellowWool"] = "minecraft:yellow_wool";
  MinecraftItemTypes2["ZoglinSpawnEgg"] = "minecraft:zoglin_spawn_egg";
  MinecraftItemTypes2["ZombieHorseSpawnEgg"] = "minecraft:zombie_horse_spawn_egg";
  MinecraftItemTypes2["ZombiePigmanSpawnEgg"] = "minecraft:zombie_pigman_spawn_egg";
  MinecraftItemTypes2["ZombieSpawnEgg"] = "minecraft:zombie_spawn_egg";
  MinecraftItemTypes2["ZombieVillagerSpawnEgg"] = "minecraft:zombie_villager_spawn_egg";
  return MinecraftItemTypes2;
})(MinecraftItemTypes || {});
var MinecraftPotionEffectTypes = ((MinecraftPotionEffectTypes2) => {
  MinecraftPotionEffectTypes2["FireResistance"] = "FireResistance";
  MinecraftPotionEffectTypes2["Harming"] = "Harming";
  MinecraftPotionEffectTypes2["Healing"] = "Healing";
  MinecraftPotionEffectTypes2["Infested"] = "Infested";
  MinecraftPotionEffectTypes2["Invisibility"] = "Invisibility";
  MinecraftPotionEffectTypes2["Leaping"] = "Leaping";
  MinecraftPotionEffectTypes2["NightVision"] = "NightVision";
  MinecraftPotionEffectTypes2["None"] = "None";
  MinecraftPotionEffectTypes2["Oozing"] = "Oozing";
  MinecraftPotionEffectTypes2["Poison"] = "Poison";
  MinecraftPotionEffectTypes2["SlowFalling"] = "SlowFalling";
  MinecraftPotionEffectTypes2["Slowing"] = "Slowing";
  MinecraftPotionEffectTypes2["Strength"] = "Strength";
  MinecraftPotionEffectTypes2["Swiftness"] = "Swiftness";
  MinecraftPotionEffectTypes2["TurtleMaster"] = "TurtleMaster";
  MinecraftPotionEffectTypes2["WaterBreath"] = "WaterBreath";
  MinecraftPotionEffectTypes2["Weakness"] = "Weakness";
  MinecraftPotionEffectTypes2["Weaving"] = "Weaving";
  MinecraftPotionEffectTypes2["WindCharged"] = "WindCharged";
  MinecraftPotionEffectTypes2["Wither"] = "Wither";
  return MinecraftPotionEffectTypes2;
})(MinecraftPotionEffectTypes || {});
var MinecraftPotionLiquidTypes = ((MinecraftPotionLiquidTypes2) => {
  MinecraftPotionLiquidTypes2["Lingering"] = "Lingering";
  MinecraftPotionLiquidTypes2["Regular"] = "Regular";
  MinecraftPotionLiquidTypes2["Splash"] = "Splash";
  return MinecraftPotionLiquidTypes2;
})(MinecraftPotionLiquidTypes || {});
var MinecraftPotionModifierTypes = ((MinecraftPotionModifierTypes2) => {
  MinecraftPotionModifierTypes2["Long"] = "Long";
  MinecraftPotionModifierTypes2["Normal"] = "Normal";
  MinecraftPotionModifierTypes2["Strong"] = "Strong";
  return MinecraftPotionModifierTypes2;
})(MinecraftPotionModifierTypes || {});

// data/system_template_esbuild/subscripts/fly.ts
var DEBUG4 = false;
var INTERVAL = 1;
var HOVER_ANGLE = 15;
var STATIONARY_VELOCITY = 0.05;
var MAX_IMPULSE_UP = 3;
var IMPULSE_UP_STEP = 0.5;
var MAX_IMPULSE_DOWN = 4;
var IMPULSE_DOWN_STEP = 0.5;
var DIVE_THRESHOLD = 0.75;
var SPEED_MODIFIER_STEP_POSTIIVE = 0.04;
var SPEED_MODIFIER_STEP_NEGATIVE = 0.02;
var BASE_VERTICAL_IMPULSE = 0.08;
var playerDragonPairs = /* @__PURE__ */ new Map();
system26.afterEvents.scriptEventReceive.subscribe((event) => {
  if (event.sourceEntity == void 0) {
    throw new Error(`Failed to get source entity from the called script event. Are you calling this from the console?`);
  }
  if (event.id == "shapescape_dra:dragon_ride") {
    if (event.message === "NULL") {
      const pairData = playerDragonPairs.get(event.sourceEntity.id);
      if (pairData)
        pairData.player.camera.clear();
      playerDragonPairs.delete(event.sourceEntity.id);
    } else {
      const rideable = event.sourceEntity.getComponent(EntityRideableComponent2.componentId);
      if (rideable) {
        const riders = rideable.getRiders();
        if (riders.length > rideable.controllingSeat) {
          const rider = riders[rideable.controllingSeat];
          if (rider && rider instanceof Player18) {
            if (event.sourceEntity.getDynamicProperty(`fancy_riding_camera`) ?? false) {
              rider.camera.setCamera(MinecraftCameraPresetsTypes.FollowOrbit);
            }
            playerDragonPairs.set(event.sourceEntity.id, {
              player: rider,
              dragon: event.sourceEntity,
              impulseUp: 0,
              impulseDown: 0,
              endingDiveImpulse: 0
            });
          }
        }
      }
    }
  }
});
world25.beforeEvents.playerLeave.subscribe((event) => {
  for (const dragon of playerDragonPairs) {
    if (dragon[1].player.id === event.player.id) {
      playerDragonPairs.delete(dragon[0]);
      return;
    }
  }
});
function verticalForce(dragonID) {
  let pairData = playerDragonPairs.get(dragonID);
  const { player, dragon } = pairData;
  let { impulseUp, impulseDown, endingDiveImpulse } = pairData;
  const isMovingHorizontally = Math.abs(dragon.getVelocity().x) > STATIONARY_VELOCITY || Math.abs(dragon.getVelocity().z) > STATIONARY_VELOCITY;
  const playerHeadRot = player.getRotation().x;
  const upDownHover = Math.abs(playerHeadRot) > HOVER_ANGLE ? playerHeadRot > 0 ? -1 : 1 : 0;
  const angleFactor = Math.sqrt(Math.abs(playerHeadRot) / 90);
  if (upDownHover === 1 && isMovingHorizontally) {
    impulseUp = lerp(impulseUp, MAX_IMPULSE_UP * angleFactor, IMPULSE_UP_STEP);
  } else {
    impulseUp = lerp(impulseUp, 0, IMPULSE_UP_STEP);
  }
  if (upDownHover === -1) {
    impulseDown = lerp(impulseDown, MAX_IMPULSE_DOWN * angleFactor, IMPULSE_DOWN_STEP);
  } else {
    impulseDown = lerp(impulseDown, 0, IMPULSE_DOWN_STEP);
    if (impulseDown > MAX_IMPULSE_DOWN * DIVE_THRESHOLD) {
      endingDiveImpulse = impulseDown * 0.1;
    }
  }
  endingDiveImpulse = lerp(endingDiveImpulse, 0, IMPULSE_DOWN_STEP * 2);
  const finalImpulseUp = BASE_VERTICAL_IMPULSE * impulseUp;
  const finalImpulseDown = -BASE_VERTICAL_IMPULSE * impulseDown;
  const verticalImpulse = (finalImpulseUp + finalImpulseDown) * (isMovingHorizontally ? 1 : 0);
  playerDragonPairs.set(dragon.id, {
    player,
    dragon,
    impulseUp,
    impulseDown,
    endingDiveImpulse
  });
  if (DEBUG4) {
    world25.sendMessage(
      `===================
Impulse Up: ${impulseUp.toFixed(4)}
Impulse Down: ${impulseDown.toFixed(
        4
      )}
Vertical impulse: ${verticalImpulse.toFixed(4)}
Vertical impulse Up: ${finalImpulseUp.toFixed(
        4
      )}
Vertical impulse Down: ${finalImpulseDown.toFixed(4)}
is moving horizontally: ${isMovingHorizontally}`
    );
    world25.sendMessage(`ending dive impulse: ${endingDiveImpulse.toFixed(4)}`);
  }
  return verticalImpulse;
}
function endDiveFlyDownForce(dragonID, verticalImpulse) {
  let pairData = playerDragonPairs.get(dragonID);
  const { dragon, endingDiveImpulse, impulseDown } = pairData;
  let impulseX = 0;
  let impulseY = 0;
  let impulseZ = 0;
  const viewDir = dragon.getViewDirection();
  const flyDown = verticalImpulse < 0;
  const diving = impulseDown > MAX_IMPULSE_DOWN * DIVE_THRESHOLD;
  if (Number(endingDiveImpulse.toFixed(4)) > 0) {
    impulseX = viewDir.x * endingDiveImpulse;
    impulseZ = viewDir.z * endingDiveImpulse;
    impulseY = endingDiveImpulse * 0.75;
  } else if (flyDown && !diving) {
    impulseX = viewDir.x * (-verticalImpulse / 8);
    impulseZ = viewDir.z * (-verticalImpulse / 8);
  } else if (diving) {
    impulseX = viewDir.x * (verticalImpulse / 3);
    impulseZ = viewDir.z * (verticalImpulse / 3);
  }
  return { x: impulseX, y: impulseY, z: impulseZ };
}
function setMovementSpeed(dragonID) {
  let pairData = playerDragonPairs.get(dragonID);
  const { dragon } = pairData;
  const isMoving = pairData.player.inputInfo.getMovementVector().y !== 0;
  const movementComp = dragon.getComponent(EntityComponentTypes9.Movement);
  if (!movementComp)
    return;
  let newSpeed = movementComp.currentValue;
  const stepPositive = SPEED_MODIFIER_STEP_POSTIIVE + movementComp.defaultValue / 100;
  const stepNegative = SPEED_MODIFIER_STEP_NEGATIVE;
  if (isMoving) {
    newSpeed = lerp(movementComp.currentValue, movementComp.defaultValue, stepPositive);
  } else {
    newSpeed = lerp(movementComp.currentValue, 0, stepNegative);
  }
  movementComp.setCurrentValue(newSpeed);
  if (DEBUG4) {
    world25.sendMessage(`Current speed: ${newSpeed.toFixed(4)}`);
    world25.sendMessage(`Natural speed: ${movementComp.currentValue.toFixed(4)}`);
    world25.sendMessage(`Step modified positive: ${stepPositive.toFixed(4)}`);
  }
}
function moveDragon(dragonID) {
  let pairData = playerDragonPairs.get(dragonID);
  const dragon = pairData.dragon;
  const player = pairData.player;
  if (dragon === void 0 || player === void 0 || !dragon.isValid || !player.isValid) {
    playerDragonPairs.delete(dragonID);
    return;
  }
  const verticalImpulse = verticalForce(dragonID);
  setMovementSpeed(dragonID);
  let { x: diveForceX, y: diveForceY, z: diveForceZ } = endDiveFlyDownForce(dragonID, verticalImpulse);
  const finalVector = {
    x: diveForceX,
    y: verticalImpulse + diveForceY,
    z: diveForceZ
  };
  dragon.applyImpulse(finalVector);
  dragon.setProperty(`shapescape_dra:fly_x_rotation`, vector3ToXRotation(dragon.getVelocity()));
  if (DEBUG4) {
    world25.sendMessage(`fly x rotation: ${vector3ToXRotation(dragon.getVelocity())}`);
    world25.sendMessage(`dive force X: ${diveForceX.toFixed(4)}`);
    world25.sendMessage(`dive force Z: ${diveForceZ.toFixed(4)}`);
    world25.sendMessage(`dive force Y: ${diveForceY.toFixed(4)}`);
  }
}
system26.runInterval(() => {
  const array = Array.from(playerDragonPairs.entries());
  for (const pair of array) {
    moveDragon(pair[0]);
  }
}, INTERVAL);
function lerp(start, end, zeroToOne) {
  return start + (end - start) * zeroToOne;
}
function vector3ToXRotation(vector) {
  vector = Vec3.from(vector).isZero() ? vector : Vec3.from(vector).normalize();
  const y = Math.max(-1, Math.min(1, vector.y));
  const pitchRad = Math.asin(-y);
  return pitchRad * (180 / Math.PI);
}

// data/system_template_esbuild/subscripts/dragon_heads.ts
import { EntityTypeFamilyComponent, ItemStack as ItemStack2, system as system27, world as world26 } from "@minecraft/server";
function onDragonDeath(event) {
  if (randInt(1, 100) > 25)
    return;
  const entity = event.deadEntity;
  const player = event.damageSource.damagingEntity;
  if (!player || player.typeId !== "minecraft:player")
    return;
  const typeFamily = entity.getComponent(EntityTypeFamilyComponent.componentId);
  if (!typeFamily || !typeFamily.hasTypeFamily("shapescape_dra_head_dropper"))
    return;
  const item = getItemInMainHand(player);
  if (!item)
    return;
  if (!item.hasTag("shapescape_dra:is_dragon_sword") && !player.hasTag("shapescape_dra_debug"))
    return;
  const shiny = entity.getProperty("shapescape_dra:shiny");
  let itemHeadType = "";
  if (entity.typeId.includes("fire")) {
    itemHeadType = "fire";
  } else if (entity.typeId.includes("poison")) {
    itemHeadType = "poison";
  } else if (entity.typeId.includes("thunder")) {
    itemHeadType = "thunder";
  } else if (entity.typeId.includes("crystal")) {
    itemHeadType = "crystal";
  } else if (entity.typeId.includes("ice")) {
    itemHeadType = "ice";
  } else if (entity.typeId.includes("fae")) {
    itemHeadType = "fae";
  }
  if (shiny) {
    itemHeadType = itemHeadType + "_shiny";
  }
  const itemHead = new ItemStack2(`shapescape_dra:${itemHeadType}_dragon_head_item`, 1);
  if (itemHead) {
    const location = new Vec3(entity.location.x, entity.location.y, entity.location.z);
    const dimension = entity.dimension;
    system27.runTimeout(() => {
      dimension.spawnItem(itemHead, location);
    }, 60);
  }
}
world26.afterEvents.entityDie.subscribe(onDragonDeath);

// data/system_template_esbuild/subscripts/dragon_horn_properties.ts
import { world as world27, system as system28, EntityComponentTypes as EntityComponentTypes10 } from "@minecraft/server";
var DEBUG5 = false;
function saveDragon(dragon) {
  const tameableComp = dragon.getComponent(EntityComponentTypes10.Tameable);
  if (!tameableComp)
    return;
  const ownerID = tameableComp.tamedToPlayerId;
  if (!ownerID)
    return;
  const type = dragon.typeId.replace("shapescape_dra:", "").replace("_tamed", "").split("_")[0];
  const stage = dragon.typeId.replace("shapescape_dra:", "").replace("_tamed", "").split("_")[1];
  const dragonData = {
    id: dragon.id,
    ownerID,
    name: dragon.nameTag,
    type,
    stage: Number(stage),
    shiny: dragon.getProperty(`shapescape_dra:shiny`),
    dimension: dragon.dimension.id,
    location: dragon.location
  };
  world27.setDynamicProperty(`dragon_horn_data_${dragon.id}`, JSON.stringify(dragonData));
}
function removeDragon2(dragonId) {
  world27.setDynamicProperty(`dragon_horn_data_${dragonId}`, void 0);
}
function getDragons(ownerID) {
  let dragons = [];
  const propertyIDs = world27.getDynamicPropertyIds();
  for (const propertyID of propertyIDs) {
    if (!propertyID.includes(`dragon_horn_data_`))
      continue;
    const dragonData = JSON.parse(world27.getDynamicProperty(propertyID));
    if (dragonData.ownerID === ownerID) {
      dragons.push(dragonData);
    }
  }
  return dragons;
}
world27.afterEvents.entityDie.subscribe((event) => {
  const { deadEntity } = event;
  removeDragon2(deadEntity.id);
});
system28.afterEvents.scriptEventReceive.subscribe((event) => {
  const { id, message, sourceEntity } = event;
  if (id === "shapescape_dra:dragon_base" && message === "save_dragon" && sourceEntity !== void 0 && sourceEntity.isValid) {
    saveDragon(sourceEntity);
  }
  if (id === "shapescape_dra:dragon_base" && message === "unsave_dragon" && sourceEntity !== void 0 && sourceEntity.isValid) {
    removeDragon2(sourceEntity.id);
  }
});
system28.runInterval(() => {
  if (DEBUG5) {
    const players = world27.getPlayers();
    for (const player of players) {
      const ownerID = player.id;
      let dragonsList = getDragons(ownerID);
      world27.sendMessage(JSON.stringify(dragonsList));
    }
  }
}, 40);
system28.afterEvents.scriptEventReceive.subscribe((event) => {
  const { id, message, sourceEntity } = event;
  if (id === "shapescape_dra:dragon_horn_debug" && message === "reset") {
    const propertyIDs = world27.getDynamicPropertyIds();
    for (const propertyID of propertyIDs) {
      if (!propertyID.includes(`dragon_horn_data_`))
        continue;
      world27.setDynamicProperty(propertyID, void 0);
    }
  }
});

// data/system_template_esbuild/subscripts/dragon_horn_ui.ts
import {
  world as world29,
  Player as Player22
} from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

// data/system_template_esbuild/subscripts/dragon_horn_teleport.ts
import { world as world28, system as system29, Player as Player21, TicksPerSecond as TicksPerSecond3 } from "@minecraft/server";
var SEARCH_TIME = 5 * TicksPerSecond3;
function callDragon(player, dragonData) {
  player.playSound(`shapescape_dra.dragon_horn.horn`, { volume: 0.6 });
  world28.setDynamicProperty(`dragon_horn_location_${player.id}`, player.location);
  const property = world28.getDynamicProperty(`dragon_horn_location_${player.id}`);
  const BLACKOUT_TIME = 10;
  const FADE_COLOR = {
    red: 0,
    blue: 0,
    green: 0
  };
  player.camera.fade({
    fadeColor: FADE_COLOR,
    fadeTime: {
      fadeInTime: 0.5,
      holdTime: 0.5,
      fadeOutTime: 0
    }
  });
  let name = dragonData.name;
  if (name === "") {
    name = `entity.shapescape_dra:${dragonData.type}_${dragonData.stage}_tamed.name`;
  }
  system29.runTimeout(() => {
    if (!player.isValid)
      return;
    let index = 0;
    const runID = system29.runInterval(() => {
      if (!player.isValid) {
        system29.clearRun(runID);
        return;
      }
      player.teleport(dragonData.location);
      player.addEffect(`resistance`, 5, { amplifier: 255, showParticles: false });
      player.addEffect(`fire_resistance`, 5, { amplifier: 255, showParticles: false });
      player.camera.fade({
        fadeColor: FADE_COLOR,
        fadeTime: {
          fadeInTime: 0,
          holdTime: 0.5,
          fadeOutTime: 0.5
        }
      });
      try {
        const dragonEntity = world28.getEntity(dragonData.id);
        if (dragonEntity !== void 0) {
          player.teleport(property);
          dragonEntity.teleport(property);
          world28.setDynamicProperty(`dragon_horn_location_${player.id}`, void 0);
          system29.runTimeout(() => {
            if (!player.isValid)
              return;
            player.sendMessage({
              rawtext: [
                { translate: `${name}` },
                { text: ` ` },
                { translate: `shapescape_dra.ui.dragon_horn.dragon_found` }
              ]
            });
            player.playSound(`note.bell`, { volume: 1, pitch: 1 });
          }, 20);
          system29.clearRun(runID);
        }
      } catch {
      }
      index++;
      if (index >= SEARCH_TIME) {
        system29.clearRun(runID);
        player.teleport(property);
        system29.runTimeout(() => {
          if (!player.isValid)
            return;
          player.sendMessage({
            rawtext: [
              { translate: `${name}` },
              { text: ` ` },
              { translate: `shapescape_dra.ui.dragon_horn.no_dragon_found` }
            ]
          });
          player.playSound(`note.bass`, { volume: 1, pitch: 1 });
        }, 20);
        world28.setDynamicProperty(`dragon_horn_location_${player.id}`, void 0);
        removeDragon2(dragonData.id);
      }
    }, 1);
  }, BLACKOUT_TIME);
}
world28.afterEvents.entityDie.subscribe((event) => {
  const { deadEntity } = event;
  if (deadEntity instanceof Player21) {
    const player = deadEntity;
    world28.setDynamicProperty(`dragon_horn_location_${player.id}`, void 0);
  }
});
world28.afterEvents.playerSpawn.subscribe((event) => {
  const { player, initialSpawn } = event;
  const property = world28.getDynamicProperty(`dragon_horn_location_${player.id}`);
  if (initialSpawn && property !== void 0) {
    player.teleport(property);
    world28.setDynamicProperty(`dragon_horn_location_${player.id}`, void 0);
  }
});

// data/system_template_esbuild/subscripts/dragon_horn_ui.ts
var ICON_PATH = `textures/shapescape/dra/ui`;
var DIMENSIONS_LANGS = /* @__PURE__ */ new Map([
  ["minecraft:overworld", "dimension.dimensionName0"],
  ["minecraft:nether", "dimension.dimensionName1"],
  ["minecraft:the_end", "dimension.dimensionName2"]
]);
var DIMENSIONS_COLORS = /* @__PURE__ */ new Map([
  ["minecraft:overworld", "\xA7a"],
  ["minecraft:nether", "\xA7c"],
  ["minecraft:the_end", "\xA7d"]
]);
world29.afterEvents.itemUse.subscribe((event) => {
  const { itemStack, source } = event;
  if (!(source instanceof Player22) || itemStack.typeId !== "shapescape_dra:dragon_horn")
    return;
  mainMenu(source);
});
function mainMenu(player) {
  const form = new ActionFormData().title({
    translate: "shapescape_dra.ui.dragon_horn.title"
  }).body({
    translate: "shapescape_dra.ui.dragon_horn.body"
  });
  const dragonsMap = getDragons(player.id);
  const buttons = [];
  for (const dragonData of dragonsMap) {
    let name = dragonData.name;
    if (name === "") {
      name = `entity.shapescape_dra:${dragonData.type}_${dragonData.stage}_tamed.name`;
    }
    const icon = dragonData.shiny ? ICON_PATH + `/${dragonData.type}_${dragonData.stage}_shiny.png` : ICON_PATH + `/${dragonData.type}_${dragonData.stage}.png`;
    buttons.push({
      name,
      iconPath: icon,
      callback: () => {
        if (player.dimension.id === dragonData.dimension) {
          confirmTeleportMenu(player, dragonData);
        } else {
          wrongDimensionMenu(player, dragonData);
        }
      }
    });
  }
  for (const button of buttons) {
    form.button({ translate: `${button.name}` }, button.iconPath);
  }
  form.show(player).then((response) => {
    if (response.selection !== void 0) {
      let button = buttons[response.selection];
      button.callback();
    }
  });
}
function confirmTeleportMenu(player, dragonData) {
  const form = new ActionFormData().title({
    translate: "shapescape_dra.ui.dragon_horn.confirm_teleport.title"
  }).body({
    translate: "shapescape_dra.ui.dragon_horn.confirm_teleport.body"
  }).button({
    translate: "shapescape_dra.ui.dragon_horn.confirm"
  }).button({
    translate: "shapescape_dra.ui.dragon_horn.cancel"
  });
  form.show(player).then((response) => {
    if (response.selection === 0) {
      callDragon(player, dragonData);
    } else {
      mainMenu(player);
    }
  });
}
function wrongDimensionMenu(player, dragonData) {
  const form = new ActionFormData().title({
    translate: "shapescape_dra.ui.dragon_horn.wrong_dimension.title"
  }).body({
    rawtext: [
      {
        translate: "shapescape_dra.ui.dragon_horn.wrong_dimension.body_1"
      },
      {
        text: `
`
      },
      {
        text: `${DIMENSIONS_COLORS.get(player.dimension.id)}\xA7l`
      },
      {
        translate: `${DIMENSIONS_LANGS.get(player.dimension.id)}`
      },
      {
        text: `\xA7r

`
      },
      {
        translate: "shapescape_dra.ui.dragon_horn.wrong_dimension.body_2"
      },
      {
        text: `
`
      },
      {
        text: `${DIMENSIONS_COLORS.get(dragonData.dimension)}\xA7l`
      },
      {
        translate: `${DIMENSIONS_LANGS.get(dragonData.dimension)}`
      }
    ]
  }).button({
    translate: "shapescape_dra.ui.dragon_horn.back"
  });
  form.show(player).then((response) => {
    if (response.selection === void 0 || response.canceled) {
    } else {
      mainMenu(player);
    }
  });
}

// data/system_template_esbuild/subscripts/dragon_hunter_net.ts
import {
  world as world30,
  system as system31,
  TicksPerSecond as TicksPerSecond4,
  EntityComponentTypes as EntityComponentTypes12
} from "@minecraft/server";
var TAG = `shapescape_dra_SHOT`;
world30.afterEvents.entitySpawn.subscribe((event) => {
  const { entity } = event;
  if (entity.typeId === `shapescape_dra:dragon_hunter_net_proj` && !entity.hasTag(TAG)) {
    const dimension = entity.dimension;
    const location = entity.location;
    entity.addTag(TAG);
    const shooter = dimension.getEntities({
      location,
      maxDistance: 2,
      closest: 1,
      type: "shapescape_dra:dragon_hunter_net"
    })[0];
    let impulse = Vec3.from(shooter.getViewDirection()).setX(0).setY(0.09).setZ(0);
    const stepY = 1e-3;
    let index = 0;
    entity.applyImpulse(impulse);
    const runID = system31.runInterval(() => {
      index++;
      if (!entity.isValid || index > 3 * TicksPerSecond4) {
        system31.clearRun(runID);
        return;
      }
      if (entity.getVelocity().y > 0.3)
        return;
      if (entity.typeId !== "minecraft:player") {
        entity.applyImpulse(impulse.setY(impulse.y - stepY * index));
      }
    }, 1);
  }
});
world30.afterEvents.projectileHitEntity.subscribe((event) => {
  const EFFECT_TIME = 5 * TicksPerSecond4;
  const projectile3 = event.projectile;
  const entity = event.getEntityHit().entity;
  if (entity === void 0 || !entity.isValid)
    return;
  const families = entity.getComponent(EntityComponentTypes12.TypeFamily)?.getTypeFamilies();
  if (families === void 0)
    return;
  if (projectile3.typeId === `shapescape_dra:dragon_hunter_net_proj` && entity !== void 0) {
    projectile3.remove();
    entity.addEffect(`slowness`, EFFECT_TIME, { amplifier: 1, showParticles: true });
    let index = 0;
    const runID = system31.runInterval(() => {
      index++;
      if (!entity.isValid || index > EFFECT_TIME) {
        system31.clearRun(runID);
        return;
      }
      if (entity.typeId !== "minecraft:player") {
        entity.applyImpulse({ x: 0, y: -0.03, z: 0 });
      }
    }, 1);
  }
});

// data/system_template_esbuild/subscripts/net_crossbow.ts
import {
  world as world31,
  Player as Player24,
  system as system32,
  TicksPerSecond as TicksPerSecond5,
  EntityComponentTypes as EntityComponentTypes13,
  ItemComponentTypes,
  EquipmentSlot as EquipmentSlot3
} from "@minecraft/server";
var TAG_LOADING = `shapescape_dra_NET_CROSSBOW_LOADING`;
system32.afterEvents.scriptEventReceive.subscribe((event) => {
  const { message, id, sourceEntity } = event;
  if (sourceEntity && id === "shapescape_dra:net_crossbow_proj" && message === "hit") {
    const EFFECT_TIME = 5 * TicksPerSecond5;
    const location = sourceEntity.location;
    const dimension = sourceEntity.dimension;
    const entities = dimension.getEntities({
      location,
      maxDistance: 0.8 * 2 * 1.2,
      // 0.8 is radius in behaviors
      excludeFamilies: ["inanimate", "projectile"],
      excludeTypes: ["minecraft:item", "shapescape_dra:net_crossbow_proj"]
    });
    for (const entity of entities) {
      if (entity.isValid) {
        if (sourceEntity.getComponent(EntityComponentTypes13.TameMount)?.tamedToPlayerId === entity.id)
          continue;
        entity.applyDamage(3);
        entity.addEffect(`slowness`, EFFECT_TIME, { amplifier: 1, showParticles: true });
        let index = 0;
        const runID = system32.runInterval(() => {
          index++;
          if (!entity.isValid || index > EFFECT_TIME) {
            system32.clearRun(runID);
            return;
          }
          if (entity.typeId !== "minecraft:player") {
            entity.applyImpulse({ x: 0, y: -0.03, z: 0 });
          }
        }, 1);
      }
    }
    sourceEntity.remove();
  }
});
world31.afterEvents.entitySpawn.subscribe((event) => {
  const { entity } = event;
  if (entity.typeId === `shapescape_dra:net_crossbow_proj_dummy`) {
    const dimension = entity.dimension;
    const location = entity.location;
    const entityToShoot = entity.dimension.spawnEntity(`shapescape_dra:net_crossbow_proj`, location);
    const player = dimension.getEntities({
      location,
      maxDistance: 2,
      closest: 1,
      type: "minecraft:player"
    })[0];
    entity.remove();
    if (player !== void 0 && player.isValid) {
      entityToShoot.getComponent(EntityComponentTypes13.TameMount)?.tameToPlayer(true, player);
      shoot(player, entityToShoot);
    }
  }
});
function shoot(player, projectile3) {
  player.dimension.playSound(`crossbow.shoot`, player.location);
  const viewDir = Vec3.from(player.getViewDirection());
  const location = viewDir.multiply(1.25).add(player.getHeadLocation());
  projectile3.teleport(location);
  let impulse = Vec3.from(viewDir).multiply(3);
  projectile3.applyImpulse(impulse);
}
world31.afterEvents.itemReleaseUse.subscribe((event) => {
  const { itemStack, source } = event;
  if (itemStack !== void 0 && itemStack.typeId === `shapescape_dra:net_crossbow` && source instanceof Player24) {
    const player = source;
    durability(itemStack, player, 1);
    player.removeTag(TAG_LOADING);
  }
});
world31.afterEvents.itemCompleteUse.subscribe((event) => {
  const { itemStack, source } = event;
  if (itemStack !== void 0 && itemStack.typeId === `shapescape_dra:net_crossbow` && source instanceof Player24) {
    const player = source;
    player.playAnimation(`animation.player.crossbow_hold`, {
      blendOutTime: 0,
      nextState: `default`,
      stopExpression: `q.distance_from_camera < 0.5 || !q.is_item_name_any('slot.weapon.mainhand', 'shapescape_dra:net_crossbow') || (query.item_remaining_use_duration <= 0.0 && !query.item_is_charged)`
    });
  }
});
world31.afterEvents.itemStartUse.subscribe((event) => {
  const { itemStack, source } = event;
  if (itemStack !== void 0 && itemStack.typeId === `shapescape_dra:net_crossbow` && source instanceof Player24) {
    source.addTag(TAG_LOADING);
    system32.runTimeout(() => {
      if (!source.isValid || !source.hasTag(TAG_LOADING))
        return;
      source.dimension.playSound(`crossbow.quick_charge.start`, source.location);
    }, 3);
    system32.runTimeout(() => {
      if (!source.isValid || !source.hasTag(TAG_LOADING))
        return;
      source.dimension.playSound(`crossbow.quick_charge.middle`, source.location);
    }, 13);
    system32.runTimeout(() => {
      if (!source.isValid || !source.hasTag(TAG_LOADING))
        return;
      source.dimension.playSound(`crossbow.quick_charge.end`, source.location);
    }, 23);
  }
});
world31.afterEvents.playerSpawn.subscribe((event) => {
  const { player } = event;
  player.removeTag(TAG_LOADING);
});
function durability(itemStack, player, amount) {
  let durabilityComponent = itemStack.getComponent(ItemComponentTypes.Durability);
  let playerEquippableComp = player.getComponent(EntityComponentTypes13.Equippable);
  if (durabilityComponent.damage + amount >= durabilityComponent.maxDurability) {
    player.playSound("random.break");
    playerEquippableComp.setEquipment(EquipmentSlot3.Mainhand, void 0);
  } else {
    let currentDur = durabilityComponent.damage;
    durabilityComponent.damage = currentDur + amount;
    playerEquippableComp.setEquipment(EquipmentSlot3.Mainhand, itemStack);
  }
}

// data/system_template_esbuild/subscripts/dragon_hunter_spear.ts
import {
  world as world32,
  system as system33,
  EntityDamageCause as EntityDamageCause10,
  TicksPerSecond as TicksPerSecond6
} from "@minecraft/server";
var dragonHunterSpearHit = /* @__PURE__ */ new Map();
var HIT_RESET_DELAY = 5 * TicksPerSecond6;
var HIT_AMOUNT = 4;
world32.afterEvents.entityHurt.subscribe((event) => {
  const { hurtEntity, damageSource } = event;
  if (hurtEntity.typeId === "shapescape_dra:dragon_hunter_spear" && (damageSource.cause === EntityDamageCause10.entityAttack || damageSource.cause === EntityDamageCause10.projectile || damageSource.cause === EntityDamageCause10.charging || damageSource.cause === EntityDamageCause10.entityExplosion || damageSource.cause === EntityDamageCause10.maceSmash || damageSource.cause === EntityDamageCause10.ramAttack)) {
    const hitData = dragonHunterSpearHit.get(hurtEntity.id) ?? { hitAmount: 0, timestamp: system33.currentTick };
    const newHitAmount = hitData.hitAmount + 1;
    if (newHitAmount > HIT_AMOUNT) {
      dragonHunterSpearHit.set(hurtEntity.id, { hitAmount: HIT_AMOUNT, timestamp: system33.currentTick });
      if (hurtEntity.getProperty(`shapescape_dra:shield_up`) === true) {
        hurtEntity.dimension.playSound(`item.shield.block`, hurtEntity.location);
      }
      hurtEntity.triggerEvent(`shapescape_dra:shield_up`);
      hurtEntity.addEffect(`resistance`, HIT_RESET_DELAY, {
        amplifier: 3,
        showParticles: false
      });
      hurtEntity.addEffect(`slowness`, HIT_RESET_DELAY, {
        amplifier: 0,
        showParticles: false
      });
    } else {
      dragonHunterSpearHit.set(hurtEntity.id, { hitAmount: newHitAmount, timestamp: system33.currentTick });
    }
  }
});
system33.runInterval(() => {
  for (const [id, hitData] of dragonHunterSpearHit) {
    if (system33.currentTick - hitData.timestamp > HIT_RESET_DELAY) {
      let shieldDown = dragonHunterSpearHit.delete(id);
      const entity = world32.getEntity(id);
      if (shieldDown && entity)
        entity.triggerEvent(`shapescape_dra:shield_down`);
    }
  }
}, 10);

// data/system_template_esbuild/subscripts/drag_hunt_spawner_block.ts
import { system as system34, TicksPerSecond as TicksPerSecond7, world as world33 } from "@minecraft/server";
var lastEventLocation = new Vec3(0, 0, 0);
var DEBUG6 = false;
var DRAGON_HUNTERS_ID = [
  "shapescape_dra:dragon_hunter_sword",
  "shapescape_dra:dragon_hunter_spear",
  "shapescape_dra:dragon_hunter_net"
];
function placeSpawnerBlockAndDespawn(event) {
  const dimension = event.dimension;
  const location = event.block.location;
  const scoreboard = world33.scoreboard.getObjective("shapescape_dra_drag_hunt_spawner_block");
  if (scoreboard !== void 0)
    return;
  if (lastEventLocation.equals(location)) {
    return;
  }
  try {
    dimension.setBlockType(location, "minecraft:air");
  } catch {
    return;
  }
  lastEventLocation = Vec3.from(location);
  dimension.runCommand(
    `summon shapescape_dra:drag_hunt_spawner_entity ${location.x} ${location.y} ${location.z} ~~ shapescape_dra:structure`
  );
}
system34.beforeEvents.startup.subscribe((event) => {
  event.blockComponentRegistry.registerCustomComponent("shapescape_dra:drag_hunt_spawner_block", {
    onTick: (event2) => {
      placeSpawnerBlockAndDespawn(event2);
    }
  });
});
system34.afterEvents.scriptEventReceive.subscribe((event) => {
  const { message, id, sourceEntity: spawner } = event;
  if (spawner && id === "shapescape_dra:drag_hunt_spawner_entity" && message === "check_for_summon_structure") {
    const MAX_HUNTERS_NUM = 5;
    const HUNTERS_PER_SPAWN = 3;
    const RADIUS3 = 25;
    const COOLDOWN3 = 5 * 60 * TicksPerSecond7;
    const location = spawner.location;
    const dimension = spawner.dimension;
    let timeStamp = spawner.getDynamicProperty("spawner_timestamp");
    let canSpawn = false;
    if (timeStamp === void 0) {
      timeStamp = world33.getAbsoluteTime() - COOLDOWN3;
      spawner.setDynamicProperty("spawner_timestamp", timeStamp);
    }
    if (timeStamp > world33.getAbsoluteTime()) {
      canSpawn = true;
    } else {
      canSpawn = Math.abs(world33.getAbsoluteTime() - timeStamp) >= COOLDOWN3;
    }
    if (DEBUG6) {
      world33.sendMessage(`timestamp: ${timeStamp}`);
      world33.sendMessage(`getAbsoluteTime: ${world33.getAbsoluteTime()}`);
      world33.sendMessage(`total: ${Math.abs(world33.getAbsoluteTime() - timeStamp)}`);
    }
    if (canSpawn) {
      for (let index = 0; index < HUNTERS_PER_SPAWN; index++) {
        const currentHunters = dimension.getEntities({
          location,
          maxDistance: RADIUS3,
          families: ["shapescape_dra_dragon_hunter"]
        });
        if (currentHunters.length >= MAX_HUNTERS_NUM) {
          spawner.setDynamicProperty("spawner_timestamp", world33.getAbsoluteTime());
          break;
        } else {
          const randomIndex = Math.floor(Math.random() * DRAGON_HUNTERS_ID.length);
          try {
            dimension.spawnEntity(DRAGON_HUNTERS_ID[randomIndex], spawner.location, {
              spawnEvent: "shapescape_dra:spawned_in_outpost"
            });
            spawner.setDynamicProperty("spawner_timestamp", world33.getAbsoluteTime());
          } catch {
          }
        }
      }
    }
  }
});

// data/system_template_esbuild/subscripts/drag_hunt_dragon_spawner_block.ts
import { system as system35, world as world34 } from "@minecraft/server";
var lastEventLocation2 = new Vec3(0, 0, 0);
var DRAGONS = [
  "shapescape_dra:cave_1_trader",
  "shapescape_dra:crystal_1_trader",
  "shapescape_dra:fire_1_trader",
  "shapescape_dra:fae_1_trader",
  "shapescape_dra:thunder_1_trader",
  "shapescape_dra:poison_1_trader",
  "shapescape_dra:ice_1_trader"
];
function placeSpawnerBlockAndDespawn2(event) {
  const dimension = event.dimension;
  const location = event.block.location;
  const scoreboard = world34.scoreboard.getObjective("shapescape_dra_drag_hunt_spawner_block");
  if (scoreboard !== void 0)
    return;
  if (lastEventLocation2.equals(location)) {
    return;
  }
  try {
    dimension.setBlockType(location, "minecraft:air");
  } catch {
    return;
  }
  lastEventLocation2 = Vec3.from(location);
  const randomIndex = Math.floor(Math.random() * DRAGONS.length);
  dimension.spawnEntity(DRAGONS[randomIndex], location);
}
system35.beforeEvents.startup.subscribe((event) => {
  event.blockComponentRegistry.registerCustomComponent("shapescape_dra:drag_hunt_dragon_spawner_block", {
    onTick: (event2) => {
      placeSpawnerBlockAndDespawn2(event2);
    }
  });
});

// data/system_template_esbuild/subscripts/dragon_shedding.ts
import { world as world35, system as system36, ItemStack as ItemStack4 } from "@minecraft/server";
var COOLDOWN2 = 8 * 60 * 20;
var INTERVAL2 = 10 * 20;
var DIMENSION_IDS = ["overworld", "nether", "the_end"];
var DEBUG7 = false;
system36.runInterval(() => {
  for (const dimensionID of DIMENSION_IDS) {
    const dimension = world35.getDimension(dimensionID);
    const entities = dimension.getEntities();
    const dragons = entities.filter(
      (entity) => entity.typeId.includes("shapescape") && (entity.typeId.includes("_1_tamed") || entity.typeId.includes("_2_tamed") || entity.typeId.includes("_3_tamed"))
    );
    for (const dragon of dragons) {
      let timeStamp = dragon.getDynamicProperty("dragon_shedding");
      let canBeShedded = false;
      if (timeStamp === void 0) {
        timeStamp = world35.getAbsoluteTime();
        dragon.setDynamicProperty("dragon_shedding", timeStamp);
      }
      if (timeStamp > world35.getAbsoluteTime()) {
        canBeShedded = true;
      } else {
        canBeShedded = Math.abs(world35.getAbsoluteTime() - timeStamp) >= COOLDOWN2;
      }
      if (DEBUG7) {
        world35.sendMessage(`Absolute time - time stamp: ${Math.abs(world35.getAbsoluteTime() - timeStamp)}`);
      }
      if (canBeShedded) {
        const dragonType = dragon.typeId.replace("_tamed", "").replace("shapescape_dra:", "").replace("_1", "").replace("_2", "").replace("_3", "");
        const newItemStack = new ItemStack4(`shapescape_dra:${dragonType}_dragon_scale`);
        try {
          dragon.dimension.spawnItem(newItemStack, dragon.location);
          dragon.dimension.playSound("random.pop", dragon.location);
          dragon.setDynamicProperty("dragon_shedding", world35.getAbsoluteTime());
        } catch {
        }
      }
    }
  }
}, INTERVAL2);

// data/system_template_esbuild/subscripts/custom_sword_effects.ts
import {
  world as world36,
  EntityComponentTypes as EntityComponentTypes14,
  EquipmentSlot as EquipmentSlot4,
  EntityDamageCause as EntityDamageCause11,
  Player as Player27,
  system as system37
} from "@minecraft/server";
world36.afterEvents.entityHitEntity.subscribe((event) => {
  const damagingEntityEquipment = event.damagingEntity.getComponent(EntityComponentTypes14.Equippable);
  if (damagingEntityEquipment === void 0)
    return;
  const damagingEntityMainhand = damagingEntityEquipment.getEquipmentSlot(EquipmentSlot4.Mainhand);
  if (!event.hitEntity || !event.hitEntity.isValid)
    return;
  const damagingEntity = event.damagingEntity;
  switch (damagingEntityMainhand.getItem()?.typeId) {
    case "shapescape_dra:fire_dragon_sword":
      if (randInt(0, 100) < 25 || damagingEntity.isFalling && !damagingEntity.isClimbing && !damagingEntity.isSwimming && !damagingEntity.isSneaking) {
        event.hitEntity.dimension.spawnParticle("shapescape_dra:swords_fire", event.hitEntity.location);
        event.hitEntity.dimension.playSound("custom.shapescape_dra.swords.fire", event.hitEntity.location, {
          volume: 0.75
        });
        event.hitEntity.setOnFire(3);
      }
      break;
    case "shapescape_dra:poison_dragon_sword":
      if (randInt(0, 100) < 25 || damagingEntity.isFalling && !damagingEntity.isClimbing && !damagingEntity.isSwimming && !damagingEntity.isSneaking) {
        event.hitEntity.dimension.spawnParticle("shapescape_dra:swords_poison", event.hitEntity.location);
        event.hitEntity.dimension.playSound("custom.shapescape_dra.swords.poison", event.hitEntity.location, {
          volume: 0.75
        });
        event.hitEntity.addEffect(MinecraftEffectTypes.Poison, 150, {
          showParticles: true,
          amplifier: 0
        });
      }
      break;
    case "shapescape_dra:ice_dragon_sword":
      if (randInt(0, 100) < 25 || damagingEntity.isFalling && !damagingEntity.isClimbing && !damagingEntity.isSwimming && !damagingEntity.isSneaking) {
        event.hitEntity.dimension.spawnParticle("shapescape_dra:swords_ice", event.hitEntity.location);
        event.hitEntity.dimension.playSound("custom.shapescape_dra.swords.ice", event.hitEntity.location, { volume: 0.75 });
        event.hitEntity.addEffect(MinecraftEffectTypes.Slowness, 60, {
          showParticles: true,
          amplifier: 0
        });
      }
      break;
    case "shapescape_dra:thunder_dragon_axe":
      if (randInt(0, 100) < 25 || damagingEntity.isFalling && !damagingEntity.isClimbing && !damagingEntity.isSwimming && !damagingEntity.isSneaking) {
        event.hitEntity.dimension.spawnParticle("shapescape_dra:swords_thunder", event.hitEntity.location);
        event.hitEntity.dimension.playSound("custom.shapescape_dra.swords.thunder", event.hitEntity.location, {
          volume: 0.75
        });
        event.hitEntity.applyDamage(3, {
          damagingEntity,
          cause: EntityDamageCause11.lightning
        });
      }
      break;
    case "shapescape_dra:crystal_dragon_sword":
      if (randInt(0, 100) < 25 || damagingEntity.isFalling && !damagingEntity.isClimbing && !damagingEntity.isSwimming && !damagingEntity.isSneaking) {
        event.hitEntity.dimension.spawnParticle("shapescape_dra:swords_crystal", event.hitEntity.location);
        event.hitEntity.dimension.playSound("custom.shapescape_dra.swords.crystal", event.hitEntity.location, {
          volume: 0.75
        });
        event.hitEntity.dimension.playSound("break.amethyst_cluster", event.hitEntity.location, { volume: 0.75 });
        event.hitEntity.dimension.playSound("resonate.amethyst_block", event.hitEntity.location, { volume: 0.75 });
        event.hitEntity.addEffect(MinecraftEffectTypes.Blindness, 50, {
          showParticles: false,
          amplifier: 0
        });
        event.hitEntity.addEffect(MinecraftEffectTypes.Weakness, 50, {
          showParticles: true,
          amplifier: 0
        });
      }
      break;
    default:
      return;
  }
});
world36.afterEvents.itemStartUse.subscribe((event) => {
  let itemStack = event.itemStack;
  let player = event.source;
  if (player !== void 0 && itemStack !== void 0 && itemStack.typeId === "shapescape_dra:fae_dragon_sword") {
    faeSword(player);
  }
  if (player !== void 0 && itemStack !== void 0 && itemStack.typeId === "shapescape_dra:cave_dragon_sword") {
    caveSword(player);
  }
});
function faeSword(player) {
  const FAE_RAINBOW_DAMAGE = 10;
  const FAE_RAINBOW_DISTANCE = 20;
  player.dimension.playSound("custom.shapescape_dra.swords.thunder", player.location, {
    volume: 0.65,
    pitch: 1.5
  });
  player.dimension.playSound("custom.shapescape_dra.swords.fire", player.location, {
    volume: 0.65,
    pitch: 1.5
  });
  system37.runTimeout(() => {
    if (!player)
      return;
    let entities = player.getEntitiesFromViewDirection({
      maxDistance: FAE_RAINBOW_DISTANCE,
      excludeFamilies: ["inanimate", "projectile"],
      excludeTypes: ["minecraft:item", "minecraft:arrow"]
    });
    for (const entity of entities) {
      if (!entity.entity)
        continue;
      entity.entity.applyDamage(FAE_RAINBOW_DAMAGE, {
        cause: EntityDamageCause11.magic
      });
      entity.entity.setOnFire(5);
    }
  }, 3);
}
function caveSword(player) {
  const ATTACK_DELAY4 = 5;
  const radius = 5;
  const DAMAGE7 = 2;
  const DURATION = 40;
  let index = 0;
  system37.runTimeout(() => {
    const runID = system37.runInterval(() => {
      index++;
      if (index > DURATION || !player.isValid) {
        system37.clearRun(runID);
        return;
      }
      const location = player.location;
      const entities = player.dimension.getEntities({
        maxDistance: radius,
        location,
        excludeFamilies: ["inanimate", "projectile"],
        excludeTypes: ["minecraft:item", "minecraft:arrow"]
      });
      if (system37.currentTick % 5 === 0)
        player.dimension.spawnParticle("shapescape_dra:swords_cave", player.location);
      for (const entity of entities) {
        if (checkIfTamed5(entity, player) || entity.id === player.id)
          continue;
        const substractionVector = Vec3.from(entity.location).subtract(player.location);
        if (substractionVector.isZero())
          continue;
        const impulseVector = substractionVector.normalize().multiply(5e-3).setY(0);
        if (entity instanceof Player27) {
          entity.applyKnockback({ x: impulseVector.x, z: impulseVector.z }, 0);
        } else {
          entity.applyImpulse(impulseVector);
        }
        entity.applyDamage(DAMAGE7, {
          cause: EntityDamageCause11.magic,
          damagingEntity: player
        });
      }
    }, 1);
  }, ATTACK_DELAY4);
}
function checkIfTamed5(entity, player) {
  if (entity.hasComponent(EntityComponentTypes14.Tameable)) {
    let entityTame = entity.getComponent(EntityComponentTypes14.Tameable);
    return entityTame.tamedToPlayer == player;
  } else {
    return false;
  }
}

// data/system_template_esbuild/subscripts/dragon_trader_tamer.ts
import {
  EntityInitializationCause as EntityInitializationCause4,
  EntityIsTamedComponent,
  EntityLeashableComponent,
  EntityTypeFamilyComponent as EntityTypeFamilyComponent2,
  world as world37
} from "@minecraft/server";
function onEntityTransform(event) {
  if (event.cause == EntityInitializationCause4.Transformed) {
    const entity = event.entity;
    const familyType = entity.getComponent(EntityTypeFamilyComponent2.componentId);
    if (!familyType || !familyType.hasTypeFamily("shapescape_dra_dragon"))
      return;
    const leashable = entity.getComponent(EntityLeashableComponent.componentId);
    const isTamed = entity.getComponent(EntityIsTamedComponent.componentId);
    if (leashable && leashable.isLeashed && isTamed) {
      if (leashable.leashHolder && leashable.leashHolder.typeId === "shapescape_dra:dragon_trader") {
        leashable.unleash();
      }
    }
  }
}
world37.afterEvents.entitySpawn.subscribe(onEntityTransform);

// data/system_template_esbuild/subscripts/dragon_ui.ts
import {
  world as world39,
  system as system39,
  Player as Player29,
  EntityComponentTypes as EntityComponentTypes16
} from "@minecraft/server";
import { ActionFormData as ActionFormData3, ModalFormData as ModalFormData3, MessageFormData as MessageFormData2 } from "@minecraft/server-ui";

// data/system_template_esbuild/subscripts/dragon_ui_dragon_ownership.ts
import {
  EntityComponentTypes as EntityComponentTypes15,
  world as world38
} from "@minecraft/server";
import { ActionFormData as ActionFormData2, MessageFormData, ModalFormData as ModalFormData2 } from "@minecraft/server-ui";
var recentOwnershipProperties = /* @__PURE__ */ new Map();
function loadOwnershipProperties(dragon) {
  const tamable = dragon.getComponent(EntityComponentTypes15.Tameable);
  if (tamable === void 0) {
    return;
  }
  const ownerId = tamable.tamedToPlayerId;
  if (ownerId === void 0) {
    return;
  }
  const recentData = recentOwnershipProperties.get(ownerId);
  if (recentData !== void 0) {
    const data2 = JSON.stringify(recentData);
    dragon.setDynamicProperty("owners", data2);
    return;
  }
  const player = tamable.tamedToPlayer;
  if (player === void 0) {
    const data2 = JSON.stringify(
      DragonOwners.fromJson({
        owner: [ownerId, "???"],
        caretakers: [],
        riders: []
      })
    );
    dragon.setDynamicProperty("owners", data2);
    return;
  }
  const data = JSON.stringify(
    DragonOwners.fromJson({
      owner: [player.id, player.name],
      caretakers: [],
      riders: []
    })
  );
  dragon.setDynamicProperty("owners", data);
}
function saveOwnershipProperties(dragon) {
  const ownersProperty = dragon.getDynamicProperty("owners");
  if (ownersProperty === void 0 || typeof ownersProperty !== "string") {
    return;
  }
  const owners = DragonOwners.fromJson(JSON.parse(ownersProperty));
  let owner = owners.owner;
  const tamable = dragon.getComponent(EntityComponentTypes15.Tameable);
  const tamedToPlayer = tamable?.tamedToPlayer;
  if (tamedToPlayer !== void 0) {
    owner = [tamedToPlayer.id, tamedToPlayer.name];
    owners.owner = owner;
  }
  recentOwnershipProperties.set(owner[0], owners);
}
function getPlayerById(id) {
  for (const player of world38.getAllPlayers()) {
    if (player.id === id) {
      return player;
    }
  }
  return void 0;
}
function getOwnerFromTamableComponent(dragon) {
  const tameableCompoenent = dragon.getComponent(EntityComponentTypes15.Tameable);
  if (tameableCompoenent === void 0) {
    return void 0;
  }
  return tameableCompoenent.tamedToPlayer;
}
function isOwner(player, dragon) {
  const tameableCompoenent = dragon.getComponent(EntityComponentTypes15.Tameable);
  if (tameableCompoenent === void 0) {
    return false;
  }
  return player.id === tameableCompoenent.tamedToPlayerId;
}
function isOwnerOrCareTaker(player, dragon) {
  const owners = DragonOwners.fromDragon(dragon, player);
  return isOwner(player, dragon) || owners.caretakers.some((caretaker) => caretaker[0] === player.id);
}
function isOwnerOrRider(player, dragon) {
  const owners = DragonOwners.fromDragon(dragon, player);
  return isOwner(player, dragon) || owners.riders.some((rider) => rider[0] === player.id);
}
function getKnownPlayersList() {
  const knownPlayersProperty = world38.getDynamicProperty("known_players");
  let knownPlayers = {};
  if (typeof knownPlayersProperty === "string") {
    knownPlayers = JSON.parse(knownPlayersProperty);
    if (typeof knownPlayers !== "object") {
      knownPlayers = {};
    }
  }
  let knownPlayersMap = new Map(Object.entries(knownPlayers));
  for (const player of world38.getAllPlayers()) {
    knownPlayersMap.set(player.id, player.name);
  }
  world38.setDynamicProperty("known_players", JSON.stringify(Object.fromEntries(knownPlayersMap)));
  return knownPlayersMap;
}
var DragonOwners = class _DragonOwners {
  constructor() {
    __publicField(this, "owner");
    // [id, name]
    __publicField(this, "caretakers");
    // [[id, name], ...]
    __publicField(this, "riders");
  }
  // [[id, name], ...]
  /**
   * New CarOwners object form the JSON data. The data is assumed to be
   * correctly formatted.
   */
  static fromJson(json) {
    const result = new _DragonOwners();
    result.owner = json["owner"];
    result.caretakers = json["caretakers"];
    result.riders = json["riders"];
    return result;
  }
  /**
   * Returns the DragonOwners object from the entity property. If the property
   * is not set, it will return a new DragonOwners object with the player as the
   * owner and assign the property to the entity.
   *
   * This code does a lot of safety checks to make sure that the owner saved
   * in the dynamic property is the same as the owner saved in the Tameable
   * component. Using the Tameable component is the ultimate source of truth.
   *
   * @param dragon The dragon entity
   * @param defaultOwner The player that will be the owner if the property
   * is not set. This can happen only if the dragon has no property set and
   * the game is unable to get the player from the Tameable component.
   * @returns DragonOwners object
   */
  static fromDragon(dragon, defaultOwner) {
    const ownersProperty = dragon.getDynamicProperty("owners");
    const ownerFromTamable = getOwnerFromTamableComponent(dragon);
    if (ownersProperty === void 0 || !(typeof ownersProperty === "string")) {
      let result;
      if (ownerFromTamable !== void 0) {
        result = _DragonOwners.fromJson({
          owner: [ownerFromTamable.id, ownerFromTamable.name],
          caretakers: [],
          riders: []
        });
        result.saveToEntity(dragon, void 0);
      } else {
        result = _DragonOwners.fromJson({
          owner: [defaultOwner.id, defaultOwner.name],
          caretakers: [],
          riders: []
        });
        result.saveToEntity(dragon, defaultOwner);
      }
      return result;
    }
    const dragonProperties = JSON.parse(ownersProperty);
    if (ownerFromTamable !== void 0 && ownerFromTamable.id !== dragonProperties.owner[0]) {
      dragonProperties.owner = [ownerFromTamable.id, ownerFromTamable.name];
      const result = _DragonOwners.fromJson(dragonProperties);
      result.saveToEntity(dragon, void 0);
      return result;
    }
    return _DragonOwners.fromJson(dragonProperties);
  }
  saveToEntity(dragon, newOwner) {
    this.caretakers = this.caretakers.filter((caretaker) => caretaker[0] !== this.owner[0]);
    this.riders = this.riders.filter((rider) => rider[0] !== this.owner[0]);
    if (newOwner !== void 0) {
      const tameableCompoenent = dragon.getComponent(EntityComponentTypes15.Tameable);
      if (tameableCompoenent === void 0) {
        return;
      }
      tameableCompoenent.tame(newOwner);
    }
    dragon.setDynamicProperty("owners", JSON.stringify(this));
  }
};
var OwnershipManager = class {
  constructor(dragon, player, onCancel) {
    __publicField(this, "player");
    __publicField(this, "dragon");
    /** Action to perform when the player cancels the main form. In most cases
     * it should be opening some other UI.
     */
    __publicField(this, "onCancel");
    this.dragon = dragon;
    this.player = player;
    this.onCancel = onCancel;
  }
  /**
   * Opens the main menu of the permissions manager.
   */
  show() {
    if (!this.player.isValid || !this.dragon.isValid) {
      return;
    }
    if (!isOwner(this.player, this.dragon)) {
      this.showDialogNotOwner();
    }
    const formHandlers = [];
    const form = new ActionFormData2().title({
      translate: "shapescape_dra:dragon_ui.manage.dialog.title"
    });
    form.button(
      { translate: "shapescape_dra:dragon_ui.manage.dialog.transfer.button" },
      "textures/shapescape/dra/ui/transfer_ownership"
    );
    formHandlers.push(() => this.showTransferOwnershipForm());
    form.button(
      { translate: "shapescape_dra:dragon_ui.manage.dialog.caretakers.button" },
      "textures/shapescape/dra/ui/manage_caretakers"
    );
    formHandlers.push(() => this.showManagePermissionsForm("caretakers"));
    if (this.dragon.matches({ excludeFamilies: ["baby"] })) {
      form.button(
        { translate: "shapescape_dra:dragon_ui.manage.dialog.riders.button" },
        "textures/shapescape/dra/ui/manage_riders"
      );
      formHandlers.push(() => this.showManagePermissionsForm("riders"));
    }
    form.show(this.player).then((result) => {
      if (result.canceled || result.selection === void 0) {
        this.onCancel();
        return;
      }
      formHandlers[result.selection]();
    });
  }
  /**
   * Opens a dialog that informs the player that they are not the owner of the
   * dragon and cannot manage the permissions.
   */
  showDialogNotOwner() {
    if (!this.player.isValid || !this.dragon.isValid) {
      return;
    }
    const owners = DragonOwners.fromDragon(this.dragon, this.player);
    const ownerName = owners.owner[1];
    new ActionFormData2().title({
      translate: "shapescape_dra:dragon_ui.you_cant_modify_that.dialog.title"
    }).body({
      translate: "shapescape_dra:dragon_ui.you_cant_modify_that.dialog.body",
      with: [ownerName]
    }).button({
      translate: "shapescape_dra:dragon_ui.you_cant_modify_that.dialog.ok"
    }).show(this.player);
  }
  /**
   * Opens a menu for transferring the ownership of the dragon to another
   * player. If there is not enough players in the game, it will display
   * a dialog.
   */
  showTransferOwnershipForm() {
    if (!this.player.isValid || !this.dragon.isValid) {
      return;
    }
    const owners = DragonOwners.fromDragon(this.dragon, this.player);
    const onlinePlayers = [];
    for (const onlinePlayer of world38.getAllPlayers()) {
      if (onlinePlayer.id === this.player.id) {
        continue;
      }
      onlinePlayers.push(onlinePlayer);
    }
    if (onlinePlayers.length === 0) {
      this.showDialogNotEnoughPlayers();
      return;
    }
    const form = new ActionFormData2().title({
      translate: "shapescape_dra:dragon_ui.transfer.dialog.title"
    });
    for (const playerData of onlinePlayers) {
      form.button(playerData.name);
    }
    form.show(this.player).then((result) => {
      if (result.canceled || result.selection === void 0) {
        this.show();
        return;
      }
      const selectedPlayer = onlinePlayers[result.selection];
      this.showTransferOwnershipConfirmationDialog(owners, selectedPlayer);
    });
  }
  /**
   * Opens a menu for managing the permissions of the dragon. One checkox for
   * each player that is online or already in the list.
   * @param permission The permission to manage
   */
  showManagePermissionsForm(permission) {
    if (!this.player.isValid || !this.dragon.isValid) {
      return;
    }
    const allPlayers = /* @__PURE__ */ new Map();
    const dragonOwners = DragonOwners.fromDragon(this.dragon, this.player);
    for (const [playerId, playerName] of dragonOwners[permission]) {
      if (!allPlayers.has(playerId)) {
        allPlayers.set(playerId, playerName);
      }
    }
    for (const [onlinePlayerId, onlinePlayerName] of getKnownPlayersList()) {
      if (onlinePlayerId === this.player.id) {
        continue;
      }
      allPlayers.set(onlinePlayerId, onlinePlayerName);
    }
    if (allPlayers.size === 0) {
      this.showDialogNotEnoughPlayers();
      return;
    }
    const allPlayersArray = Array.from(allPlayers.entries());
    let formTitle = "";
    switch (permission) {
      case "riders":
        formTitle = {
          translate: "shapescape_dra:dragon_ui.manage_riders.title"
        };
        break;
      case "caretakers":
        formTitle = {
          translate: "shapescape_dra:dragon_ui.manage_caretakers.title"
        };
        break;
      default:
        return;
    }
    const form = new ModalFormData2().title(formTitle);
    for (const [playerId, playerName] of allPlayersArray) {
      let isMember = false;
      for (const [memberId, _] of dragonOwners[permission]) {
        if (memberId === playerId) {
          isMember = true;
          break;
        }
      }
      form.toggle(playerName, {
        defaultValue: isMember
      });
    }
    form.show(this.player).then((result) => {
      if (result.canceled || result.formValues === void 0) {
        this.show();
        return;
      }
      dragonOwners[permission] = [];
      for (let i = 0; i < result.formValues.length; i++) {
        if (result.formValues[i] === true) {
          dragonOwners[permission].push(allPlayersArray[i]);
        }
      }
      dragonOwners.saveToEntity(this.dragon, void 0);
      this.show();
    });
  }
  /**
   * Opens a dialog that informs the player that there are not enough players
   * to manage the permissions or transfer the ownership.
   */
  showDialogNotEnoughPlayers() {
    if (!this.player.isValid) {
      return;
    }
    new ActionFormData2().title({
      translate: "shapescape_dra:dragon_ui.not_enough_players_to_manage.title"
    }).body({
      translate: "shapescape_dra:dragon_ui.not_enough_players_to_manage.body"
    }).button({
      translate: "shapescape_dra:dragon_ui.not_enough_players_to_manage.ok"
    }).show(this.player).then(() => {
      this.show();
    });
  }
  /**
   * Opens a dialog that asks the player to confirm the transfer of the
   * ownership to the new owner.
   */
  showTransferOwnershipConfirmationDialog(owners, newOwnerPlayer) {
    if (!this.player.isValid || !this.dragon.isValid) {
      return;
    }
    new MessageFormData().title({
      translate: "shapescape_dra:dragon_ui.transfer_confirmation.dialog.title"
    }).body({
      translate: "shapescape_dra:dragon_ui.transfer_confirmation.dialog.body",
      with: [newOwnerPlayer.name]
    }).button1({
      translate: "shapescape_dra:dragon_ui.transfer_confirmation.dialog.deny"
    }).button2({
      translate: "shapescape_dra:dragon_ui.transfer_confirmation.dialog.confirm"
    }).show(this.player).then((result) => {
      if (result.selection === 1) {
        const oldOwnerPlayer = getPlayerById(owners.owner[0]);
        owners.owner = [newOwnerPlayer.id, newOwnerPlayer.name];
        owners.saveToEntity(this.dragon, newOwnerPlayer);
        if (oldOwnerPlayer === void 0) {
          return;
        }
        const messageToOldOwner = {
          translate: "shapescape_dra:dragon_ui.transfer.message.you_gave_dragon",
          with: [newOwnerPlayer.name]
        };
        oldOwnerPlayer.sendMessage(messageToOldOwner);
        const messageToNewOwner = {
          translate: "shapescape_dra:dragon_ui.transfer.message.someone_gave_dragon_to_you",
          with: [oldOwnerPlayer.name]
        };
        newOwnerPlayer.sendMessage(messageToNewOwner);
      }
    });
  }
};

// data/system_template_esbuild/subscripts/dragon_ui.ts
var DIMENSION_INDEX = ["overworld", "nether", "the_end"];
function titleCase(str) {
  return str.toLowerCase().split(" ").map(function(word) {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(" ");
}
system39.afterEvents.scriptEventReceive.subscribe((event) => {
  if (event.sourceEntity == void 0)
    return;
  if (event.id == "shapescape_dra:dragon_ui_trigger") {
    update_scoreboard(event.sourceEntity);
    openSceneMain(event.sourceEntity, getPlayersByName8(event.message));
  }
});
system39.afterEvents.scriptEventReceive.subscribe((event) => {
  const dragon = event.sourceEntity;
  if (dragon === void 0 || event.id !== "shapescape_dra:check_dragon_riders") {
    return;
  }
  const rideableComponent = dragon.getComponent(EntityComponentTypes16.Rideable);
  if (rideableComponent === void 0) {
    return;
  }
  let ownerOrRiderIsRiding = false;
  const riders = rideableComponent.getRiders();
  for (const rider of riders) {
    if (rider instanceof Player29) {
      ownerOrRiderIsRiding = isOwnerOrRider(rider, dragon);
    }
  }
  if (!ownerOrRiderIsRiding) {
    for (const rider of rideableComponent.getRiders()) {
      if (rider instanceof Player29) {
        rider.sendMessage({
          translate: "shapescape_dra:dragon_ui.riding.message.not_owner_dismount"
        });
        rider.playSound("note.bass", { volume: 1, pitch: 0.75 });
      }
    }
    rideableComponent.ejectRiders();
  }
});
world39.afterEvents.dataDrivenEntityTrigger.subscribe(
  (event) => {
    const entity = event.entity;
    const isDragon = entity.matches({ families: ["shapescape_dra_dragon"] });
    if (!isDragon) {
      return;
    }
    saveOwnershipProperties(entity);
  },
  {
    eventTypes: ["transform"]
  }
);
world39.afterEvents.dataDrivenEntityTrigger.subscribe(
  (event) => {
    const entity = event.entity;
    const isDragon = entity.matches({
      families: ["shapescape_dra_dragon"],
      excludeFamilies: ["baby"]
      // Stage 1 dragon evolving from egg
    });
    if (!isDragon) {
      return;
    }
    loadOwnershipProperties(entity);
  },
  {
    eventTypes: ["minecraft:entity_transformed"]
  }
);
function getPlayersByName8(player_name) {
  let players = world39.getPlayers({ name: player_name });
  if (players.length == 1) {
    return players[0];
  }
  throw new Error(`Could not get a player by that name: ${player_name}.`);
}
function update_scoreboard(dragon) {
  let format_version;
  try {
    format_version = dragon.getDynamicProperty("format_version");
    if (format_version != void 0) {
      world39.sendMessage(format_version.toString());
    }
  } catch (error) {
    let scoreboard = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
    if (scoreboard == void 0) {
      world39.scoreboard.addObjective("shapescape_dra_dragon_UI_homes");
      scoreboard = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
      dragon.setDynamicProperty("format_version", 1);
    } else {
      let scores = scoreboard.getScores();
      scores.forEach((element) => {
        if (String(element.participant.displayName).startsWith(dragon.id)) {
          let score_string = String(element.participant.displayName).substring(dragon.id.length + 1).split("_");
          if (score_string.length == 4) {
            let dimension_index = DIMENSION_INDEX.indexOf(dragon.dimension.id.split(":")[1]);
            let fake_player = dragon.id + "_" + score_string[0] + "_" + score_string[1] + "_" + score_string[2] + "_" + score_string[3] + "_" + dimension_index;
            scoreboard?.addScore(fake_player, 0);
            scoreboard?.removeParticipant(element.participant.displayName);
          }
        }
      });
      dragon.setDynamicProperty("format_version", 1);
    }
  }
}
function openSceneMain(dragon, player_source) {
  const ownershipManager = new OwnershipManager(dragon, player_source, () => {
    openSceneMain(dragon, player_source);
  });
  if (!isOwnerOrCareTaker(player_source, dragon)) {
    ownershipManager.showDialogNotOwner();
    return;
  }
  let dragon_identifier = dragon.typeId;
  let dragon_name = dragon.nameTag;
  let dragon_stage = parseInt(dragon_identifier.split(":")[1].split("_")[1]);
  let dragon_element = dragon_identifier.split(":")[1].split("_")[0];
  if (dragon_name.length == 0) {
    dragon_name = titleCase(dragon_element) + " Dragon";
  }
  const homeButtonHandlers = [];
  let form = new ActionFormData3();
  form.title(dragon_name);
  if (dragon_stage == 3) {
    form.button("shapescape_dra:dragon_ui.fast_travel", "textures/shapescape/dra/ui/fast_travel");
    homeButtonHandlers.push(() => {
      openSceneFastTravel(dragon, player_source);
    });
  }
  if (dragon_stage >= 2) {
    form.button("shapescape_dra:dragon_ui.scavenge", "textures/shapescape/dra/ui/scavenge");
    homeButtonHandlers.push(() => {
      openSceneScavenge(dragon, player_source);
    });
  }
  form.button("shapescape_dra:dragon_ui.customize", "textures/shapescape/dra/ui/customize");
  homeButtonHandlers.push(() => {
    openSceneCustomize(dragon, player_source);
  });
  if (dragon_stage >= 2) {
    form.button("shapescape_dra:dragon_ui.sleep", "textures/shapescape/dra/ui/sleep");
    homeButtonHandlers.push(() => {
      dragon.triggerEvent("sleeping");
    });
  }
  if (isOwner(player_source, dragon)) {
    form.button("shapescape_dra:dragon_ui.manage.button", "textures/shapescape/dra/ui/manage_ownership");
    homeButtonHandlers.push(() => ownershipManager.show());
  }
  form.button("shapescape_dra:dragon_ui.sit", "textures/shapescape/dra/ui/sit");
  homeButtonHandlers.push(() => {
    if (dragon_stage > 1) {
      dragon.triggerEvent("remove_sleeping");
      dragon.removeEffect("regeneration");
    }
  });
  form.show(player_source).then((r) => {
    if (r.canceled) {
      return;
    }
    let response = r.selection;
    if (response == void 0) {
      return;
    }
    homeButtonHandlers[response]();
  });
}
function getHomes(dragon) {
  const homes = {
    Overworld: [],
    Nether: [],
    End: []
  };
  let scoreboard = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
  if (scoreboard == void 0) {
    world39.scoreboard.addObjective("shapescape_dra_dragon_UI_homes");
    scoreboard = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
    return homes;
  } else {
    let scores = scoreboard.getScores();
    scores.forEach((element) => {
      if (String(element.participant.displayName).startsWith(dragon.id)) {
        const home = { name: "", position: [], dimension: "overworld" };
        let score_string = String(element.participant.displayName).substring(dragon.id.length + 1).split("_");
        home.name = score_string[0].replaceAll("-", " ");
        home.position = [score_string[1], score_string[2], score_string[3]];
        home.dimension = DIMENSION_INDEX[score_string[4]];
        if (home.dimension == "overworld") {
          homes.Overworld.push(home);
        } else if (home.dimension == "nether") {
          homes.Nether.push(home);
        } else if (home.dimension == "the_end") {
          homes.End.push(home);
        }
      }
    });
    return homes;
  }
}
function setHome(home_name, dragon) {
  let home_name_evaluated = home_name.replaceAll(/[-_]/g, "");
  home_name_evaluated = home_name_evaluated.replaceAll(/\s+/g, "-");
  let fake_player = dragon.id + "_" + home_name_evaluated + "_" + Math.round(dragon.location.x) + "_" + Math.round(dragon.location.y) + "_" + Math.round(dragon.location.z) + "_" + DIMENSION_INDEX.indexOf(dragon.dimension.id.split(":")[1]);
  let objective = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
  objective?.addScore(fake_player, 0);
}
function removeHome(home_name, dragon) {
  let fake_player = dragon.id + "_" + home_name.replaceAll(" ", "-");
  let objective = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
  if (objective == void 0) {
    return;
  }
  let scores = objective.getScores();
  scores.forEach((element) => {
    if (String(element.participant.displayName).startsWith(fake_player)) {
      objective?.removeParticipant(element.participant.displayName);
      return;
    }
  });
}
function teleportWithDragon(dragon, player_source, coords, dimension) {
  const camera_fade_in = 1;
  const camera_fade_hold = 0.7;
  const camera_fade_out = 1;
  const camera_fade_color = { red: 0, blue: 0, green: 0 };
  player_source.camera.fade({
    fadeColor: camera_fade_color,
    fadeTime: {
      fadeInTime: camera_fade_in,
      holdTime: camera_fade_hold,
      fadeOutTime: camera_fade_out
    }
  });
  let dragon_identifier = dragon.typeId.split(":")[1];
  system39.runTimeout(() => {
    let teleportOptions = {
      keepVelocity: false,
      checkForBlocks: false,
      dimension
    };
    dragon.dimension.spawnParticle(`shapescape_dra:${dragon_identifier}_scavenging_appear`, dragon.location);
    const teleportLocation = {
      x: Number(coords[0]),
      y: Number(coords[1]),
      z: Number(coords[2])
    };
    dragon.teleport(teleportLocation, teleportOptions);
    system39.runTimeout(() => {
      player_source.teleport(teleportLocation, teleportOptions);
    }, 1);
    system39.runTimeout(() => {
      player_source.playSound("custom.shapescape_dra.dragon_3_wing_flap_down");
    }, 2);
  }, (camera_fade_in + camera_fade_hold / 2) * 20);
}
function openSceneFastTravel(dragon, player_source) {
  let form = new ActionFormData3();
  let homes = getHomes(dragon);
  form.title("shapescape_dra:dragon_ui.fast_travel");
  let current_dimension = player_source.dimension.id;
  const homeButtonHandlers = [];
  if (homes != void 0) {
    homes.Overworld.forEach((element, index) => {
      form.button(element["name"], `textures/shapescape/dra/ui/home_${index + 1}`);
      homeButtonHandlers.push(() => {
        if (dragon.dimension.id === "minecraft:overworld") {
          openSceneFastTravelTeleportConfirm(dragon, player_source, element);
        } else {
          openSceneFastTravelTeleportWrongDimension(dragon, player_source, element);
        }
      });
    });
    homes.Nether.forEach((element, index) => {
      form.button(element["name"], `textures/shapescape/dra/ui/nether_home_${index + 1}`);
      homeButtonHandlers.push(() => {
        if (dragon.dimension.id === "minecraft:nether") {
          openSceneFastTravelTeleportConfirm(dragon, player_source, element);
        } else {
          openSceneFastTravelTeleportWrongDimension(dragon, player_source, element);
        }
      });
    });
    homes.End.forEach((element, index) => {
      form.button(element["name"], `textures/shapescape/dra/ui/end_home_${index + 1}`);
      homeButtonHandlers.push(() => {
        if (dragon.dimension.id === "minecraft:the_end") {
          openSceneFastTravelTeleportConfirm(dragon, player_source, element);
        } else {
          openSceneFastTravelTeleportWrongDimension(dragon, player_source, element);
        }
      });
    });
    let dimension = current_dimension.split(":")[1];
    let dimensionMap = {
      overworld: homes.Overworld,
      nether: homes.Nether,
      the_end: homes.End
    };
    if (dimension in dimensionMap) {
      let currentHomes = dimensionMap[dimension];
      if (currentHomes.length < 5) {
        form.button("shapescape_dra:dragon_ui.fast_travel.set_home", "textures/shapescape/dra/ui/set_home");
        homeButtonHandlers.push(() => {
          openSceneFastTravelSetHome(dragon, player_source);
        });
      }
      if (currentHomes.length > 0) {
        form.button("shapescape_dra:dragon_ui.fast_travel.delete_home", "textures/shapescape/dra/ui/remove_home");
        homeButtonHandlers.push(() => {
          openSceneFastTravelRemoveHome(dragon, player_source);
        });
      }
    }
  }
  form.button("shapescape_dra:dragon_ui.back", "textures/shapescape/dra/ui/back");
  homeButtonHandlers.push(() => {
    openSceneMain(dragon, player_source);
  });
  form.show(player_source).then((r) => {
    if (r.canceled) {
      return;
    }
    let response = r.selection;
    homeButtonHandlers[response]();
  });
}
function openSceneFastTravelTeleportConfirm(dragon, player_source, home) {
  let form = new MessageFormData2();
  form.title(`Travel to ${home["name"]}`);
  form.body(`shapescape_dra:dragon_ui_fast_travel_confirm_message`);
  form.button1("Cancel");
  form.button2("Confirm");
  form.show(player_source).then((r) => {
    if (!r.selection) {
      openSceneFastTravel(dragon, player_source);
      return;
    }
    teleportWithDragon(dragon, player_source, home["position"], world39.getDimension("minecraft:" + home["dimension"]));
  }).catch((e) => {
    console.error(e, e.stack);
  });
}
function openSceneFastTravelTeleportWrongDimension(dragon, player_source, home) {
  let form = new ActionFormData3();
  form.title(`Wrong dimension!`);
  form.body(`shapescape_dra:dragon_ui_fast_travel_wrong_dimension_message`);
  form.button("Back");
  form.show(player_source).then((response) => {
    if (response.canceled) {
      return;
    } else {
      openSceneFastTravel(dragon, player_source);
    }
  });
}
function openSceneFastTravelSetHome(dragon, player_source) {
  let form = new ModalFormData3();
  form.title("Set New Home Name");
  form.textField("Home Name", "This is my home");
  form.show(player_source).then((r) => {
    if (r.canceled) {
      return;
    }
    if (r.formValues != void 0) {
      if (String(r.formValues[0]).length == 0) {
        return;
      }
      setHome(r.formValues[0], dragon);
      openSceneFastTravel(dragon, player_source);
    }
  });
}
function openSceneFastTravelRemoveHome(dragon, player_source) {
  let form = new ActionFormData3();
  let homes = getHomes(dragon);
  form.title("shapescape_dra:dragon_ui.fast_travel.remove");
  const homeButtonHandlers = [];
  if (homes != void 0) {
    homes.Overworld.forEach((element, index) => {
      form.button(element["name"], `textures/shapescape/dra/ui/home_${index + 1}`);
      homeButtonHandlers.push(() => {
        openSceneFastTravelRemoveConfirm(dragon, player_source, element["name"]);
      });
    });
    homes.Nether.forEach((element, index) => {
      form.button(element["name"], `textures/shapescape/dra/ui/nether_home_${index + 1}`);
      homeButtonHandlers.push(() => {
        openSceneFastTravelRemoveConfirm(dragon, player_source, element["name"]);
      });
    });
    homes.End.forEach((element, index) => {
      form.button(element["name"], `textures/shapescape/dra/ui/end_home_${index + 1}`);
      homeButtonHandlers.push(() => {
        openSceneFastTravelRemoveConfirm(dragon, player_source, element["name"]);
      });
    });
  }
  form.button("shapescape_dra:dragon_ui.back", "textures/shapescape/dra/ui/back");
  homeButtonHandlers.push(() => {
    openSceneFastTravel(dragon, player_source);
  });
  form.show(player_source).then((r) => {
    if (r.canceled) {
      return;
    }
    let response = r.selection;
    homeButtonHandlers[response]();
  });
}
function openSceneFastTravelRemoveConfirm(dragon, player_source, home_name) {
  let form = new MessageFormData2();
  form.title(`Delete ${home_name}`);
  form.body("shapescape_dra:dragon_ui_fast_travel_remove_confirm_message");
  form.button1("Cancel");
  form.button2("Confirm");
  form.show(player_source).then((r) => {
    if (r.selection === 1) {
      removeHome(home_name, dragon);
    }
    openSceneFastTravel(dragon, player_source);
  }).catch((e) => {
    console.error(e, e.stack);
  });
}
function openSceneScavenge(dragon, player_source) {
  let dragon_identifier = dragon.typeId;
  let dragon_name = dragon.nameTag;
  let dragon_stage = parseInt(dragon_identifier.split(":")[1].split("_")[1]);
  let dragon_element = dragon_identifier.split(":")[1].split("_")[0];
  if (dragon_name.length == 0) {
    dragon_name = titleCase(dragon_element) + " Dragon";
  }
  let form = new ActionFormData3();
  form.title("shapescape_dra:dragon_ui.scavenge");
  form.button("shapescape_dra:dragon_ui.scavenge.meat", "textures/shapescape/dra/ui/scavenge_meat");
  form.button("shapescape_dra:dragon_ui.scavenge.wood", "textures/shapescape/dra/ui/scavenge_wood");
  if (dragon_stage == 3) {
    form.button("shapescape_dra:dragon_ui.scavenge.ores", "textures/shapescape/dra/ui/scavenge_ores");
    form.button("shapescape_dra:dragon_ui.scavenge.mobs", "textures/shapescape/dra/ui/scavenge_mobs");
  }
  form.button("shapescape_dra:dragon_ui.back", "textures/shapescape/dra/ui/back");
  form.show(player_source).then((r) => {
    if (r.canceled) {
      return;
    }
    let response = r.selection;
    if (response == void 0) {
      return;
    }
    if (dragon_stage == 3) {
      if (response == 4) {
        openSceneMain(dragon, player_source);
      } else {
        openSceneScavengeConfirm(dragon, player_source, response);
      }
    } else {
      if (response == 2) {
        openSceneMain(dragon, player_source);
      } else {
        openSceneScavengeConfirm(dragon, player_source, response);
      }
    }
  });
}
function openSceneScavengeConfirm(dragon, player_source, scavenge_mode) {
  let dragon_identifier = dragon.typeId;
  let form = new MessageFormData2();
  form.title("Confirm Scavenge");
  form.body("shapescape_dra:dragon_ui_scavenge_confirm_message");
  form.button1("Cancel");
  form.button2("Confirm");
  form.show(player_source).then((r) => {
    if (!r.selection) {
      openSceneScavenge(dragon, player_source);
      return;
    }
    switch (scavenge_mode) {
      case 0:
        dragon.runCommand(`/function shapescape/dra/${dragon_identifier.split(":")[1]}/start_meat`);
        break;
      case 1:
        dragon.runCommand(`/function shapescape/dra/${dragon_identifier.split(":")[1]}/start_wood`);
        break;
      case 2:
        dragon.runCommand(`/function shapescape/dra/${dragon_identifier.split(":")[1]}/start_ore`);
        break;
      case 3:
        dragon.runCommand(`/function shapescape/dra/${dragon_identifier.split(":")[1]}/start_mob`);
        break;
      default:
    }
  }).catch((e) => {
    console.error(e, e.stack);
  });
}
function getDragonColor(dragon) {
  let variant = (
    /** @type {any} */
    dragon.getComponent("minecraft:mark_variant")
  );
  if (variant?.isValid) {
    return variant.value;
  } else {
    return 0;
  }
}
function openSceneCustomize(dragon, player_source) {
  let color_list = [
    "None",
    "item.dye.black_new.name",
    "item.dye.blue_new.name",
    "item.dye.brown_new.name",
    "item.dye.cyan.name",
    "item.dye.gray.name",
    "item.dye.green.name",
    "item.dye.lightBlue.name",
    "item.dye.lime.name",
    "item.dye.magenta.name",
    "item.dye.orange.name",
    "item.dye.pink.name",
    "item.dye.purple.name",
    "item.dye.red.name",
    "item.dye.silver.name",
    "item.dye.white_new.name",
    "item.dye.yellow.name"
  ];
  let dragon_identifier = dragon.typeId;
  let dragon_name = dragon.nameTag;
  let dragon_stage = parseInt(dragon_identifier.split(":")[1].split("_")[1]);
  let dragon_element = dragon_identifier.split(":")[1].split("_")[0];
  if (dragon_name.length == 0) {
    dragon_name = titleCase(dragon_element) + " Dragon";
  }
  const homeButtonHandlers = [];
  let form = new ModalFormData3();
  form.title("Customize " + dragon_name);
  if (dragon_stage <= 2) {
    form.toggle("Activate Evolution", {
      defaultValue: dragon.getProperty("shapescape_dra:allow_levelup")
    });
    homeButtonHandlers.push((value) => {
      if (value) {
        dragon.triggerEvent("allow_levelup");
      } else {
        dragon.triggerEvent("deny_levelup");
      }
    });
  } else if (dragon_stage == 3) {
    form.toggle("Activate Laying Eggs", {
      defaultValue: dragon.getProperty("shapescape_dra:allow_breeding")
    });
    homeButtonHandlers.push((value) => {
      if (value) {
        dragon.triggerEvent("allow_breeding");
      } else {
        dragon.triggerEvent("deny_breeding");
      }
    });
  }
  if (dragon_stage >= 2) {
    form.toggle("Fancy camera while riding", {
      tooltip: `Toggling this option on will apply a camera perspective similar to the one used when riding the Happy Ghast. However, the camera cannot be changed while riding.`,
      defaultValue: dragon.getDynamicProperty(`fancy_riding_camera`) ?? false
    });
    homeButtonHandlers.push((value) => {
      dragon.setDynamicProperty(`fancy_riding_camera`, value);
    });
  }
  form.dropdown("Select Pattern", color_list, {
    defaultValueIndex: getDragonColor(dragon)
  });
  homeButtonHandlers.push((value) => {
    let event = "pattern_" + String(value);
    dragon.triggerEvent(event);
    dragon.dimension.playSound("bucket.empty_water", dragon.location);
  });
  form.show(player_source).then((r) => {
    if (r.canceled) {
      return;
    }
    if (r.formValues != void 0) {
      let index = 0;
      for (const button of homeButtonHandlers) {
        button(r.formValues[index]);
        index++;
      }
    }
  });
}
function initializeScoreboard() {
  let scoreboard = world39.scoreboard.getObjective("shapescape_dra_dragon_UI_homes");
  if (scoreboard == void 0) {
    world39.scoreboard.addObjective("shapescape_dra_dragon_UI_homes", "Homes");
  }
  let scoreboard_2 = world39.scoreboard.getObjective("shapescape_dra_grow_up_random");
  if (scoreboard_2 == void 0) {
    world39.scoreboard.addObjective("shapescape_dra_grow_up_random");
  }
}
world39.afterEvents.worldLoad.subscribe((event) => {
  initializeScoreboard();
});

// data/system_template_esbuild/subscripts/dragons_nest_feature.ts
import { system as system40, world as world40 } from "@minecraft/server";
var lastEventLocation3 = new Vec3(0, 0, 0);
function placeDragonsNestAndDespawn(event) {
  const dimension = event.dimension;
  const location = event.block.location;
  const blockTypeId = event.block.typeId;
  const scoreboard = world40.scoreboard.getObjective("shapescape_dra_feature_nest_block");
  if (scoreboard !== void 0)
    return;
  if (lastEventLocation3.equals(location)) {
    return;
  }
  try {
    dimension.setBlockType(location, "minecraft:air");
  } catch {
    return;
  }
  lastEventLocation3 = Vec3.from(location);
  const dragonType = blockTypeId.replace("shapescape_dra:", "").replace(`_feature_nest_block`, "");
  dimension.runCommand(
    `summon shapescape_dra:dragon_egg_summoner ${location.x} ${location.y} ${location.z} ~~ ${dragonType}`
  );
  const entity = dimension.getEntities({
    location,
    type: "shapescape_dra:dragon_egg_summoner",
    maxDistance: 1,
    closest: 1
  })[0];
  entity.setProperty("shapescape_dra:spawned_from_feature", true);
}
system40.beforeEvents.startup.subscribe((event) => {
  event.blockComponentRegistry.registerCustomComponent("shapescape_dra:dragons_nest_feature", {
    onTick: (event2) => {
      placeDragonsNestAndDespawn(event2);
    }
  });
});

// data/system_template_esbuild/subscripts/menu_item.ts
import {
  world as world41,
  Player as Player30,
  PlayerPermissionLevel
} from "@minecraft/server";
import { ActionFormData as ActionFormData4, ModalFormData as ModalFormData4 } from "@minecraft/server-ui";
var ENTITIES_SPAWNING = [
  // If you add entities here, you must make sure they're invisible during first two ticks of their existance, so once they spawn and despawn, they're not visible. Check scripts for the creatures.
  "shapescape_dra:dragon_trader",
  "shapescape_dra:fat_creature",
  "shapescape_dra:longneck_creature",
  "shapescape_dra:puffer_creature",
  "shapescape_dra:pyrobat_creature",
  "shapescape_dra:twin_dragon_creature",
  "shapescape_dra:woolly_creature"
];
world41.afterEvents.itemUse.subscribe((event) => {
  const { itemStack, source } = event;
  if (!(source instanceof Player30) || itemStack.typeId !== "shapescape_dra:menu_item")
    return;
  if (source.typeId !== "minecraft:player")
    return;
  if (source.playerPermissionLevel !== PlayerPermissionLevel.Operator) {
    source.sendMessage({
      rawtext: [{ translate: "shapescape_dra.menu.use_message.not_operator" }]
    });
    return;
  }
  mainMenu2(source);
});
function mainMenu2(player) {
  const form = new ActionFormData4().title({
    translate: "shapescape_dra.ui.menu_item.main_menu.title"
  }).body({
    translate: "shapescape_dra.ui.menu_item.main_menu.body"
  });
  const buttons = [];
  buttons.push({
    name: `shapescape_dra.ui.menu_item.main_menu.spawning`,
    iconPath: void 0,
    callback: () => {
      spawningMenu(player);
    }
  });
  for (const button of buttons) {
    form.button({ translate: `${button.name}` }, button.iconPath);
  }
  form.show(player).then((response) => {
    if (response.selection !== void 0) {
      let button = buttons[response.selection];
      button.callback();
    }
  });
}
function spawningMenu(player) {
  const form = new ModalFormData4().title({
    translate: "shapescape_dra.ui.menu_item.spawning_menu.title"
  });
  const toggles = [];
  let property = world41.getDynamicProperty(`despawning_system`);
  let propertyArray;
  if (property === void 0) {
    propertyArray = [];
  } else {
    propertyArray = JSON.parse(property);
  }
  for (const entityTypeID of ENTITIES_SPAWNING) {
    toggles.push({
      name: `entity.${entityTypeID}.name`,
      iconPath: void 0,
      callback: (response) => {
        let property2 = world41.getDynamicProperty(`despawning_system`);
        let propertyArray2;
        if (property2 === void 0) {
          propertyArray2 = [];
        } else {
          propertyArray2 = JSON.parse(property2);
        }
        if (response === true) {
          if (!propertyArray2.includes(entityTypeID)) {
            propertyArray2.push(entityTypeID);
          }
        } else {
          const index = propertyArray2.indexOf(entityTypeID);
          if (index !== -1) {
            propertyArray2.splice(index, 1);
          }
        }
        world41.setDynamicProperty(`despawning_system`, JSON.stringify(propertyArray2));
      }
    });
  }
  for (const toggle of toggles) {
    form.toggle(
      { translate: `${toggle.name}` },
      {
        defaultValue: !propertyArray.includes(toggle.name.replace(`entity.`, ``).replace(`.name`, ``))
      }
    );
  }
  form.show(player).then((response) => {
    if (response.formValues !== void 0) {
      for (const [index, value] of response.formValues.entries()) {
        let toggle = toggles[index];
        toggle.callback(!value);
      }
    }
  });
}

// data/system_template_esbuild/subscripts/starting_book.ts
import { world as world42 } from "@minecraft/server";
var DEBUG8 = false;
var NAMESPACE = "shapescape_dra_1_5:";
var PATH_NAMESPACE = "shapescape/dra/";
world42.afterEvents.playerSpawn.subscribe((event) => {
  givePlayerBook(event.player);
});
function givePlayerBook(player) {
  player.runCommand(
    `execute as @s[tag=!${NAMESPACE.substring(
      0,
      NAMESPACE.length - 1
    )}] at @s run loot spawn ~ ~ ~ loot "${PATH_NAMESPACE}starting_book"`
  );
  if (DEBUG8) {
    world42.sendMessage(`Given Player Book`);
  }
  player.runCommand(
    `execute as @s[tag=!${NAMESPACE.substring(
      0,
      NAMESPACE.length - 1
    )}] at @s run loot spawn ~ ~ ~ loot "${PATH_NAMESPACE}starting_menu"`
  );
  if (DEBUG8) {
    world42.sendMessage(`Given Player Book`);
  }
  player.runCommand(
    `tag @s[tag=!${NAMESPACE.substring(0, NAMESPACE.length - 1)}] add ${NAMESPACE.substring(
      0,
      NAMESPACE.length - 1
    )}`
  );
}
